"use strict";
var CDE = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/index.ts
  var index_exports = {};
  __export(index_exports, {
    ALL_IDS: () => ALL_IDS,
    ALL_TILES: () => ALL_TILES,
    BOOK_TABLE_81: () => BOOK_TABLE_81,
    C: () => C,
    DEFAULT_CONFIG: () => DEFAULT_CONFIG,
    HAND_SIZE: () => HAND_SIZE,
    MAX_PIP: () => MAX_PIP,
    NUMBERS: () => NUMBERS,
    PLAYERS: () => PLAYERS,
    PROTOCOL_VERSION: () => PROTOCOL_VERSION,
    Rng: () => Rng,
    RuleError: () => RuleError,
    T: () => T,
    TEMPO: () => TEMPO,
    TILES_WITH: () => TILES_WITH,
    TOTAL_HANDS: () => TOTAL_HANDS,
    absSeat: () => absSeat,
    analyze: () => analyze,
    answerSignal: () => answerSignal,
    apply: () => apply,
    applyHandMut: () => applyHandMut,
    applyMut: () => applyMut,
    bestLead: () => bestLead,
    blockOutcome: () => blockOutcome,
    blockQuality: () => blockQuality,
    botStep: () => botStep,
    canHold: () => canHold,
    canPlay: () => canPlay,
    canon: () => canon,
    clone: () => clone,
    complementFactor: () => complementFactor,
    dealHand: () => dealHand,
    decide: () => decide,
    finish: () => finish,
    formatEvent: () => formatEvent,
    formatHand: () => formatHand,
    handle: () => handle,
    handsWithDoubles: () => handsWithDoubles,
    handsWithExactlyNOf: () => handsWithExactlyNOf,
    handsWithFallos: () => handsWithFallos,
    handsWithMaxDataAtMost: () => handsWithMaxDataAtMost,
    has: () => has,
    heuristicBlock: () => heuristicBlock,
    idOf: () => idOf,
    leadOptions: () => leadOptions,
    leadStrength: () => leadStrength,
    legalMoves: () => legalMoves,
    newHandFromDeal: () => newHandFromDeal,
    newMatch: () => newMatch,
    nextLead: () => nextLead,
    nextSeat: () => nextSeat,
    numLabel: () => numLabel,
    openingSignal: () => openingSignal,
    other: () => other,
    pHasAny: () => pHasAny,
    pairOf: () => pairOf,
    pairStats: () => pairStats,
    parsePlays: () => parsePlays,
    partnerOf: () => partnerOf,
    pips: () => pips,
    placeTile: () => placeTile,
    playMatch: () => playMatch,
    playNotation: () => playNotation,
    profile: () => profile,
    ratio: () => ratio,
    relSeat: () => relSeat,
    sampleDeal: () => sampleDeal,
    scenarioView: () => scenarioView,
    scoreMove: () => scoreMove,
    scoreResult: () => scoreResult,
    seatsOf: () => seatsOf,
    statsByDate: () => statsByDate,
    sumPips: () => sumPips,
    syntheticView: () => syntheticView,
    table81: () => table81,
    tableMinMax: () => tableMinMax,
    toAction: () => toAction,
    trueCount: () => trueCount,
    viewOf: () => viewOf,
    viewOfHandState: () => viewOfHandState,
    withDefaults: () => withDefaults
  });

  // src/tiles.ts
  var MAX_PIP = 9;
  var NUMBERS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  var numLabel = (n) => n === 0 ? "B" : String(n);
  function parseNum(s) {
    const t = s.trim().toUpperCase();
    if (t === "B" || t === "0") return 0;
    const n = Number(t);
    if (!Number.isInteger(n) || n < 0 || n > MAX_PIP) throw new Error(`Bad number "${s}"`);
    return n;
  }
  var CACHE = {};
  var ALL_TILES = (() => {
    const out = [];
    for (let hi = MAX_PIP; hi >= 0; hi--) {
      for (let lo = hi; lo >= 0; lo--) {
        const id = `${numLabel(hi)}-${numLabel(lo)}`;
        const t = Object.freeze({ id, hi, lo, pips: hi + lo, double: hi === lo });
        CACHE[id] = t;
        out.push(t);
      }
    }
    return Object.freeze(out);
  })();
  var ALL_IDS = ALL_TILES.map((t) => t.id);
  function idOf(a, b) {
    return `${numLabel(Math.max(a, b))}-${numLabel(Math.min(a, b))}`;
  }
  function T(idOrText) {
    const hit = CACHE[idOrText];
    if (hit) return hit;
    const parts = String(idOrText).split(/[-/|:]/);
    if (parts.length !== 2) throw new Error(`Bad tile "${idOrText}"`);
    return CACHE[idOf(parseNum(parts[0]), parseNum(parts[1]))];
  }
  var canon = (s) => T(s).id;
  function has(id, n) {
    const t = T(id);
    return t.hi === n || t.lo === n;
  }
  function other(id, n) {
    const t = T(id);
    if (t.hi === n) return t.lo;
    if (t.lo === n) return t.hi;
    throw new Error(`Tile ${id} has no ${n}`);
  }
  var pips = (id) => T(id).pips;
  var sumPips = (ids) => ids.reduce((s, x) => s + T(x).pips, 0);
  var TILES_WITH = NUMBERS.map((n) => ALL_IDS.filter((id) => has(id, n)));
  var playNotation = (tile, matched) => `${numLabel(matched)}-${numLabel(other(tile, matched))}`;

  // src/config.ts
  var DEFAULT_CONFIG = {
    targetPoints: 100,
    scoring: "losingPair",
    redealOnDoubles: null,
    firstLead: "draw",
    tieNextLead: "nonLeadingPair",
    matchPoints: { win: 1, pollona: 1, viajera: 1 },
    leadNegotiation: "signals"
  };
  function withDefaults(c) {
    return {
      ...DEFAULT_CONFIG,
      ...c ?? {},
      matchPoints: { ...DEFAULT_CONFIG.matchPoints, ...c?.matchPoints ?? {} }
    };
  }
  var HAND_SIZE = 10;
  var PLAYERS = 4;
  var pairOf = (seat) => seat % 2;
  var partnerOf = (seat) => (seat + 2) % 4;
  var nextSeat = (seat) => (seat + 1) % 4;
  var seatsOf = (pair) => [pair, pair + 2];
  var relSeat = (observer, seat) => ["J1", "J2", "J3", "J4"][(seat - observer + 4) % 4];
  function absSeat(observer, rel) {
    const k = ["J1", "J2", "J3", "J4"].indexOf(rel.toUpperCase());
    if (k < 0) throw new Error(`Bad relative seat ${rel}`);
    return (observer + k) % 4;
  }

  // src/rng.ts
  var Rng = class {
    state;
    constructor(seed) {
      this.state = seed >>> 0;
    }
    next() {
      let t = this.state = this.state + 1831565813 >>> 0;
      t = Math.imul(t ^ t >>> 15, t | 1);
      t ^= t + Math.imul(t ^ t >>> 7, t | 61);
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    }
    int(n) {
      return Math.floor(this.next() * n);
    }
    shuffle(arr) {
      for (let i = arr.length - 1; i > 0; i--) {
        const j = this.int(i + 1);
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      return arr;
    }
    /** Approximate standard normal (Irwin–Hall), used for bot noise. */
    gauss() {
      let s = 0;
      for (let i = 0; i < 6; i++) s += this.next();
      return (s - 3) * Math.SQRT2;
    }
  };

  // src/hand.ts
  var RuleError = class extends Error {
    constructor(code, message) {
      super(message);
      this.code = code;
    }
  };
  function dealHand(rng, handNo, leadingPair, firstSpeaker, config) {
    let redeals = 0;
    for (; ; ) {
      const deck = rng.shuffle([...ALL_IDS]);
      const hands = [0, 1, 2, 3].map((s) => deck.slice(s * HAND_SIZE, (s + 1) * HAND_SIZE));
      const undealt = deck.slice(4 * HAND_SIZE);
      const thr = config.redealOnDoubles;
      if (thr != null && hands.some((h) => h.filter((t) => T(t).double).length >= thr) && redeals < 50) {
        redeals++;
        continue;
      }
      return newHandFromDeal(hands, undealt, handNo, leadingPair, firstSpeaker, config, redeals);
    }
  }
  function newHandFromDeal(hands, undealt, handNo, leadingPair, firstSpeaker, config, redeals = 0) {
    if (pairOf(firstSpeaker) !== leadingPair) throw new RuleError("BAD_SPEAKER", "First speaker must belong to the leading pair");
    const all = [...hands.flat(), ...undealt].map((t) => T(t).id);
    if (hands.length !== 4 || hands.some((h2) => h2.length !== HAND_SIZE)) throw new RuleError("BAD_DEAL", "Each seat needs exactly 10 tiles");
    if (new Set(all).size !== 55 || all.length !== 55) throw new RuleError("BAD_DEAL", "Deal must use all 55 tiles exactly once");
    const h = hands.map((x) => x.map((t) => T(t).id));
    return {
      handNo,
      dealt: h.map((x) => [...x]),
      hands: h,
      undealt: undealt.map((t) => T(t).id),
      leadingPair,
      firstSpeaker,
      leaderSeat: null,
      phase: "negotiating",
      toAct: firstSpeaker,
      turn: 0,
      ends: null,
      events: [],
      result: null,
      redeals
    };
  }
  function legalMoves(hand, ends) {
    if (!ends) return hand.map((tile) => ({ tile, side: null }));
    const out = [];
    for (const tile of hand) {
      if (has(tile, ends.L.value)) out.push({ tile, side: "L" });
      if (has(tile, ends.R.value)) out.push({ tile, side: "R" });
    }
    return out;
  }
  var canPlay = (hand, ends) => !ends || hand.some((t) => has(t, ends.L.value) || has(t, ends.R.value));
  function applyHandMut(s, a, config) {
    if (s.phase === "over") throw new RuleError("HAND_OVER", "The hand is over");
    const out = dispatch(s, a, config);
    if (out.phase === "over" && out.result) scoreResult(out, config);
    return out;
  }
  function dispatch(s, a, config) {
    switch (a.type) {
      case "signal":
        return doSignal(s, a.seat, a.signal, config);
      case "setLeader":
        return doSetLeader(s, a.seat, config);
      case "play":
        return doPlay(s, a.seat, a.tile, a.side, a.thinkMs);
      case "pass":
        return doPass(s, a.seat, a.thinkMs);
      default:
        throw new RuleError("BAD_ACTION", `Unknown action ${a.type}`);
    }
  }
  function doSignal(s, seat, signal, config) {
    if (config.leadNegotiation !== "signals") throw new RuleError("NO_SIGNALS", "Lead signals are disabled (leadNegotiation=direct)");
    if (s.phase !== "negotiating") throw new RuleError("NOT_NEGOTIATING", "Lead already decided");
    if (seat !== s.toAct) throw new RuleError("NOT_YOUR_TURN", `Seat ${s.toAct} must speak`);
    const second = partnerOf(s.firstSpeaker);
    const sigs = s.events.filter((e) => e.kind === "signal");
    s.events.push({ kind: "signal", seat, signal });
    if (sigs.length === 0) {
      if (signal === "voy") return setLeader(s, seat);
      if (signal === "ven") return setLeader(s, second);
      if (signal === "dime") {
        s.toAct = second;
        return s;
      }
      throw new RuleError("BAD_SIGNAL", "First speaker may say voy, dime or ven");
    }
    if (signal === "voy") return setLeader(s, seat);
    if (signal === "sal") return setLeader(s, s.firstSpeaker);
    throw new RuleError("BAD_SIGNAL", "Answer to dime must be voy or sal");
  }
  function doSetLeader(s, seat, config) {
    if (s.phase !== "negotiating") throw new RuleError("NOT_NEGOTIATING", "Lead already decided");
    if (config.leadNegotiation !== "direct") throw new RuleError("USE_SIGNALS", "Use signal actions (leadNegotiation=signals)");
    if (pairOf(seat) !== s.leadingPair) throw new RuleError("WRONG_PAIR", "Leader must belong to the leading pair");
    return setLeader(s, seat);
  }
  function setLeader(s, seat) {
    s.leaderSeat = seat;
    s.events.push({ kind: "leader", seat });
    s.phase = "playing";
    s.toAct = seat;
    return s;
  }
  function doPlay(s, seat, rawTile, side, thinkMs) {
    if (s.phase !== "playing") throw new RuleError("NOT_PLAYING", "Not in play phase");
    if (seat !== s.toAct) throw new RuleError("NOT_YOUR_TURN", `It is seat ${s.toAct}'s turn`);
    const tile = T(rawTile).id;
    const hand = s.hands[seat];
    const idx = hand.indexOf(tile);
    if (idx < 0) throw new RuleError("NOT_IN_HAND", `Seat ${seat} does not hold ${tile}`);
    placeTile(s, seat, tile, side, thinkMs);
    hand.splice(idx, 1);
    return afterPlay(s, seat);
  }
  function placeTile(s, seat, rawTile, side, thinkMs) {
    const tile = T(rawTile).id;
    const tm = thinkMs != null ? { thinkMs } : {};
    if (!s.ends) {
      const t = T(tile);
      const mk = (value) => ({ value, seat, owner: seat, turn: s.turn, tile });
      s.ends = { L: mk(t.hi), R: mk(t.lo) };
      s.events.push({ kind: "play", seat, tile, side: null, matched: null, exposed: t.hi, otherEnd: null, turn: s.turn, ...tm });
      return;
    }
    const fitsL = has(tile, s.ends.L.value);
    const fitsR = has(tile, s.ends.R.value);
    if (!fitsL && !fitsR) throw new RuleError("FORRO", `${tile} does not match ${s.ends.L.value}/${s.ends.R.value}`);
    let chosen;
    if (side) {
      if (side === "L" && !fitsL || side === "R" && !fitsR) throw new RuleError("FORRO", `${tile} does not fit end ${side}`);
      chosen = side;
    } else if (fitsL && fitsR && s.ends.L.value !== s.ends.R.value) {
      throw new RuleError("SIDE_REQUIRED", `${tile} fits both ends; specify side`);
    } else chosen = fitsL ? "L" : "R";
    const end = s.ends[chosen];
    const matched = end.value;
    const exposed = other(tile, matched);
    const otherEnd = s.ends[chosen === "L" ? "R" : "L"].value;
    const isDouble = T(tile).double;
    s.ends[chosen] = { value: exposed, seat, owner: isDouble ? end.owner : seat, turn: s.turn, tile };
    s.events.push({ kind: "play", seat, tile, side: chosen, matched, exposed, otherEnd, turn: s.turn, ...tm });
  }
  function afterPlay(s, seat) {
    s.turn++;
    if (s.hands[seat].length === 0) return finish(s, "domino", seat);
    if (s.hands.every((h) => !canPlay(h, s.ends))) return finish(s, "block", null);
    s.toAct = nextSeat(seat);
    return s;
  }
  function doPass(s, seat, thinkMs) {
    if (s.phase !== "playing") throw new RuleError("NOT_PLAYING", "Not in play phase");
    if (seat !== s.toAct) throw new RuleError("NOT_YOUR_TURN", `It is seat ${s.toAct}'s turn`);
    if (!s.ends || canPlay(s.hands[seat], s.ends)) throw new RuleError("PASS_WITH_TILE", "You hold a playable tile");
    s.events.push({ kind: "pass", seat, ends: [s.ends.L.value, s.ends.R.value], turn: s.turn, ...thinkMs != null ? { thinkMs } : {} });
    s.turn++;
    s.toAct = nextSeat(seat);
    return s;
  }
  function finish(s, reason, dominoSeat, config) {
    const pips2 = s.hands.map((h) => sumPips(h));
    let winnerPair;
    let winnerSeat = null;
    let lowestSeats = [];
    if (reason === "domino") {
      winnerPair = pairOf(dominoSeat);
      winnerSeat = dominoSeat;
      lowestSeats = [dominoSeat];
    } else {
      const min = Math.min(...pips2);
      lowestSeats = [0, 1, 2, 3].filter((i) => pips2[i] === min);
      const pairs = new Set(lowestSeats.map(pairOf));
      winnerPair = pairs.size === 1 ? lowestSeats.map(pairOf)[0] : null;
      winnerSeat = lowestSeats.length === 1 ? lowestSeats[0] : null;
    }
    s.phase = "over";
    s.toAct = null;
    s.result = { reason, winnerPair, points: 0, pips: pips2, winnerSeat, lowestSeats };
    if (config) scoreResult(s, config);
    return s;
  }
  function scoreResult(s, config) {
    const r = s.result;
    if (r.winnerPair == null) {
      r.points = 0;
      return;
    }
    const loser = 1 - r.winnerPair;
    r.points = config.scoring === "allHands" ? r.pips.reduce((a, b) => a + b, 0) : r.pips[loser] + r.pips[loser + 2];
  }

  // src/match.ts
  function newMatch(opts = {}) {
    const config = withDefaults(opts.config);
    const rng = new Rng(opts.seed ?? Math.floor(Math.random() * 2 ** 32));
    let leadingPair;
    let firstLeadDraw = null;
    if (opts.leadingPair != null) leadingPair = opts.leadingPair;
    else if (config.firstLead === "pair0") leadingPair = 0;
    else if (config.firstLead === "pair1") leadingPair = 1;
    else {
      const draws = [];
      for (; ; ) {
        const deck = rng.shuffle([...Array(55).keys()]);
        const a = idxTile(deck[0]), b = idxTile(deck[1]);
        draws.push([a, b]);
        if (T(a).pips !== T(b).pips) {
          leadingPair = T(a).pips > T(b).pips ? 0 : 1;
          break;
        }
      }
      firstLeadDraw = { draws, pair: leadingPair };
    }
    const firstSpeaker = opts.firstSpeaker ?? seatsOf(leadingPair)[0];
    const hand = opts.deal ? newHandFromDeal(opts.deal.hands, opts.deal.undealt, 1, leadingPair, firstSpeaker, config) : dealHand(rng, 1, leadingPair, firstSpeaker, config);
    return {
      version: 1,
      config,
      rng: rng.state,
      scores: [0, 0],
      history: [],
      hand,
      status: "playing",
      winnerPair: null,
      pollona: false,
      viajera: false,
      matchPoints: 0,
      firstLeadDraw
    };
  }
  var idxTile = (i) => ALL_IDS[i];
  var clone = (x) => structuredClone(x);
  function apply(m, action) {
    return applyMut(clone(m), action);
  }
  function applyMut(m, action) {
    if (m.status === "over") throw new RuleError("MATCH_OVER", "The match is over");
    if (action.type === "nextHand") return startNextHand(m);
    const wasOver = m.hand.phase === "over";
    applyHandMut(m.hand, action, m.config);
    if (!wasOver && m.hand.phase === "over") recordHand(m);
    return m;
  }
  function recordHand(m) {
    const h = m.hand;
    const r = h.result;
    if (r.winnerPair != null) m.scores[r.winnerPair] += r.points;
    m.history.push({
      handNo: h.handNo,
      leadingPair: h.leadingPair,
      leaderSeat: h.leaderSeat,
      reason: r.reason,
      winnerPair: r.winnerPair,
      winnerSeat: r.winnerSeat,
      points: r.points,
      pips: [...r.pips],
      scoresAfter: [m.scores[0], m.scores[1]]
    });
    const target = m.config.targetPoints;
    const winner = m.scores[0] >= target ? 0 : m.scores[1] >= target ? 1 : null;
    if (winner != null) {
      m.status = "over";
      m.winnerPair = winner;
      m.pollona = m.scores[1 - winner] === 0;
      m.viajera = m.history.length === 1;
      const mp = m.config.matchPoints;
      m.matchPoints = m.viajera ? mp.viajera : m.pollona ? mp.pollona : mp.win;
    }
  }
  function nextLead(m) {
    const last = m.history[m.history.length - 1];
    if (last.winnerPair != null) {
      const pair2 = last.winnerPair;
      const speaker = last.winnerSeat != null && pairOf(last.winnerSeat) === pair2 ? last.winnerSeat : seatsOf(pair2)[0];
      return { pair: pair2, firstSpeaker: speaker };
    }
    const pair = m.config.tieNextLead === "nonLeadingPair" ? 1 - last.leadingPair : last.leadingPair;
    return { pair, firstSpeaker: seatsOf(pair)[0] };
  }
  function startNextHand(m) {
    if (m.hand.phase !== "over") throw new RuleError("HAND_IN_PROGRESS", "Finish the current hand first");
    const rng = new Rng(m.rng);
    const { pair, firstSpeaker } = nextLead(m);
    m.hand = dealHand(rng, m.hand.handNo + 1, pair, firstSpeaker, m.config);
    m.rng = rng.state;
    return m;
  }

  // src/knowledge.ts
  function viewOf(m, seat) {
    return viewOfHandState(m.hand, seat, m.config, m.scores, true);
  }
  function viewOfHandState(h, seat, config, scores = [0, 0], copy = false) {
    return {
      seat,
      hand: [...h.hands[seat]],
      config,
      scores: [scores[0], scores[1]],
      handNo: h.handNo,
      leadingPair: h.leadingPair,
      firstSpeaker: h.firstSpeaker,
      leaderSeat: h.leaderSeat,
      phase: h.phase,
      toAct: h.toAct,
      turn: h.turn,
      ends: h.ends ? copy ? structuredClone(h.ends) : { L: { ...h.ends.L }, R: { ...h.ends.R } } : null,
      events: copy ? structuredClone(h.events) : h.events,
      tileCounts: h.hands.map((x) => x.length)
    };
  }
  var TEMPO = { instantMs: 1e3, pauseMs: 4e3 };
  function analyze(v) {
    const seat = v.seat;
    const played = /* @__PURE__ */ new Set();
    const playedBy = /* @__PURE__ */ new Map();
    const voids = [0, 1, 2, 3].map(() => NUMBERS.map(() => false));
    const likelihood = [0, 1, 2, 3].map(() => NUMBERS.map(() => 1));
    const numberOwner2 = NUMBERS.map(() => null);
    const firstNumber = [null, null, null, null];
    const exposedBy = [0, 1, 2, 3].map(() => /* @__PURE__ */ new Set());
    const playsBy = [0, 0, 0, 0];
    const passesBy = [0, 0, 0, 0];
    const pausedOn = [];
    const playedNum = [0, 1, 2, 3].map(() => NUMBERS.map(() => 0));
    const seenBy = [0, 1, 2, 3].map(() => /* @__PURE__ */ new Set());
    const tileL = [0, 1, 2, 3].map(() => /* @__PURE__ */ new Map());
    const mulTile = (s2, id, f) => tileL[s2].set(id, (tileL[s2].get(id) ?? 1) * f);
    const declinedLead = [false, false, false, false];
    const partnerOpened = [];
    const handLeft = [10, 10, 10, 10];
    let curEnds = null;
    const lastExposed = [0, 1, 2, 3].map(() => NUMBERS.map(() => -1));
    const signals = [];
    let leadTile = null;
    let lastPlay = null;
    let lastEndTurn = [-1, -1];
    for (const e of v.events) {
      if (e.kind === "signal") {
        signals.push({ seat: e.seat, signal: e.signal });
        if (e.signal === "ven" && e.seat !== seat) for (let d = 0; d <= 9; d++) mulTile(e.seat, `${d === 0 ? "B" : d}-${d === 0 ? "B" : d}`, 1.4);
        if (e.signal === "sal" || e.signal === "ven") declinedLead[e.seat] = true;
      }
      if (e.kind === "leader") {
        for (const sg of signals) if (sg.seat !== e.seat && pairOf(sg.seat) === pairOf(e.seat)) declinedLead[sg.seat] = true;
      }
      if (e.kind === "pass") {
        seenBy[e.seat].add(e.ends[0]).add(e.ends[1]);
        passesBy[e.seat]++;
        voids[e.seat][e.ends[0]] = true;
        voids[e.seat][e.ends[1]] = true;
      }
      if (e.kind !== "play") continue;
      if (e.matched != null && e.otherEnd != null) seenBy[e.seat].add(e.matched).add(e.otherEnd);
      if (e.seat !== seat && e.matched != null && e.otherEnd != null) {
        const a = e.matched, b = e.otherEnd;
        const lbl = (n) => n === 0 ? "B" : String(n);
        for (const d of /* @__PURE__ */ new Set([a, b])) {
          const dd = `${lbl(d)}-${lbl(d)}`;
          if (dd !== e.tile) mulTile(e.seat, dd, 0.7);
        }
        if (a !== b) {
          const link = `${lbl(Math.max(a, b))}-${lbl(Math.min(a, b))}`;
          if (link !== e.tile) mulTile(e.seat, link, 0.8);
        }
        const tt = T(e.tile);
        const ownA = numberOwner2[a];
        if (tt.pips <= 4 && !tt.double && ownA != null && pairOf(ownA) !== pairOf(e.seat)) {
          likelihood[e.seat][b] *= 0.7;
          for (const u of TILES_WITH[a]) if (T(u).pips > tt.pips && u !== e.tile) mulTile(e.seat, u, 0.7);
        }
        if (!tt.double) likelihood[e.seat][e.exposed] *= 1.15;
        const ownX = numberOwner2[e.exposed];
        if (e.otherEnd === e.exposed && ownX != null && pairOf(ownX) !== pairOf(e.seat) && pairOf(e.seat) !== pairOf(seat)) likelihood[e.seat][e.exposed] *= 1.6;
      }
      const before = handLeft[e.seat]--;
      if (e.seat !== seat && e.matched != null && e.otherEnd != null && e.otherEnd !== e.matched && before <= 2) {
        likelihood[e.seat][e.otherEnd] *= 0.35;
      }
      if (e.seat === partnerOf(seat) && e.matched != null && before <= 3 && numberOwner2[e.matched] != null && pairOf(numberOwner2[e.matched]) === pairOf(seat) && !T(e.tile).double) {
        partnerOpened.push(e.exposed);
        likelihood[e.seat][e.exposed] *= 0.5;
      }
      playsBy[e.seat]++;
      {
        const tt = T(e.tile);
        playedNum[e.seat][tt.hi]++;
        if (!tt.double) playedNum[e.seat][tt.lo]++;
      }
      played.add(e.tile);
      playedBy.set(e.tile, e.seat);
      const t = T(e.tile);
      if (e.matched == null) {
        leadTile = e.tile;
        numberOwner2[t.hi] = e.seat;
        numberOwner2[t.lo] = e.seat;
        firstNumber[e.seat] = t.hi;
        exposedBy[e.seat].add(t.hi).add(t.lo);
        lastEndTurn = [e.turn, e.turn];
        lastExposed[e.seat][t.hi] = e.turn;
        lastExposed[e.seat][t.lo] = e.turn;
        if (signals.some((s) => s.seat === e.seat && s.signal === "voy") && e.seat !== seat) {
          likelihood[e.seat][t.hi] *= 2;
        }
      } else {
        const x = e.exposed;
        lastExposed[e.seat][x] = e.turn;
        if (!t.double) {
          if (numberOwner2[x] == null) numberOwner2[x] = e.seat;
          if (firstNumber[e.seat] == null) firstNumber[e.seat] = x;
          exposedBy[e.seat].add(x);
        }
        if (e.otherEnd === x) {
          const ow = numberOwner2[x];
          if (ow == null || pairOf(ow) !== pairOf(e.seat)) numberOwner2[x] = e.seat;
        }
        if (e.seat !== seat) {
          const sideIdx = e.side === "L" ? 0 : 1;
          const otherIdx = 1 - sideIdx;
          if (lastEndTurn[otherIdx] > lastEndTurn[sideIdx] && e.otherEnd != null && e.otherEnd !== e.matched) {
            likelihood[e.seat][e.otherEnd] *= 0.55;
          } else if (e.otherEnd != null && e.otherEnd !== e.matched) {
            const ow = numberOwner2[e.otherEnd];
            if (ow == null || pairOf(ow) !== pairOf(e.seat)) likelihood[e.seat][e.otherEnd] *= 0.75;
          }
          if (e.thinkMs != null) {
            if (e.thinkMs <= TEMPO.instantMs && !t.double) likelihood[e.seat][e.matched] *= 0.6;
            if (e.thinkMs >= TEMPO.pauseMs) {
              likelihood[e.seat][e.matched] *= 1.8;
              pausedOn.push({ seat: e.seat, number: e.matched, turn: e.turn });
            }
          }
        }
        if (e.side === "L") lastEndTurn[0] = e.turn;
        else lastEndTurn[1] = e.turn;
      }
      lastPlay = e;
    }
    const handSet = new Set(v.hand);
    const unknown = ALL_IDS.filter((id) => !played.has(id) && !handSet.has(id));
    const myCount = NUMBERS.map((n) => v.hand.filter((t) => has(t, n)).length);
    const playedCount = NUMBERS.map((n) => TILES_WITH[n].filter((t) => played.has(t)).length);
    const tableTotal = NUMBERS.map((n) => myCount[n] + playedCount[n]);
    return {
      seat,
      events: v.events,
      partner: partnerOf(seat),
      j2: (seat + 1) % 4,
      j4: (seat + 3) % 4,
      hand: [...v.hand],
      played,
      playedBy,
      unknown,
      myCount,
      playedCount,
      tableTotal,
      voids,
      likelihood,
      counts: [...v.tileCounts],
      numberOwner: numberOwner2,
      firstNumber,
      exposedBy,
      leadTile,
      leaderSeat: v.leaderSeat,
      playsBy,
      passesBy,
      pausedOn,
      playedNum,
      lastExposed,
      seenBy,
      partnerOpened,
      tileL,
      declinedLead,
      signals,
      lastPlay
    };
  }
  function canHold(k, seat, id) {
    if (seat === k.seat) return k.hand.includes(id);
    const t = T(id);
    return !k.voids[seat][t.hi] && !k.voids[seat][t.lo] && k.unknown.includes(id);
  }
  function pHasAny(k, seat, numbers) {
    if (seat === k.seat) return k.hand.some((t) => numbers.some((n) => has(t, n))) ? 1 : 0;
    if (k.counts[seat] === 0) return 0;
    const uniq = [...new Set(numbers)];
    if (uniq.some((n) => k.voids[seat][n])) {
      const rest = uniq.filter((n) => !k.voids[seat][n]);
      if (rest.length === 0) return 0;
      return pHasAny(k, seat, rest);
    }
    let pNone = 1;
    const Lt = (s2, t) => Math.max(0.1, Math.min(2, k.likelihood[s2][t.hi] * (t.double ? 1 : k.likelihood[s2][t.lo]) * complementFactor(k, s2, t) * (k.tileL[s2].get(t.id) ?? 1)));
    for (const id of k.unknown) {
      const t = T(id);
      if (!uniq.some((n) => t.hi === n || t.lo === n)) continue;
      if (k.voids[seat][t.hi] || k.voids[seat][t.lo]) continue;
      let cap = 15;
      for (let s2 = 0; s2 < 4; s2++) {
        if (s2 === k.seat) continue;
        if (!k.voids[s2][t.hi] && !k.voids[s2][t.lo]) cap += k.counts[s2] * Lt(s2, t);
      }
      const q = Math.min(1, k.counts[seat] * Lt(seat, t) / Math.max(1, cap));
      pNone *= 1 - q;
    }
    return 1 - pNone;
  }
  function complementFactor(k, seat, t) {
    let f = 1;
    for (let y = 0; y <= 9; y++) {
      const kk = k.playedNum[seat][y];
      if (kk < 3) continue;
      if (t.hi === y || t.lo === y) f *= 1 + 0.15 * (kk - 2);
      else f *= Math.max(0.5, 1 - 0.08 * (kk - 2));
    }
    return f;
  }
  function sampleDeal(k, rng, maxTries = 200) {
    const others = [0, 1, 2, 3].filter((s) => s !== k.seat);
    for (let attempt = 0; attempt < maxTries; attempt++) {
      const cap = [...k.counts];
      cap[k.seat] = 0;
      let pileCap = 15;
      const hands2 = [[], [], [], []];
      hands2[k.seat] = [...k.hand];
      const undealt = [];
      const tiles2 = rng.shuffle([...k.unknown]);
      const allowed = (id) => {
        const t = T(id);
        return others.filter((s) => !k.voids[s][t.hi] && !k.voids[s][t.lo]);
      };
      tiles2.sort((a, b) => allowed(a).length - allowed(b).length);
      let ok = true;
      for (const id of tiles2) {
        const al = allowed(id).filter((s) => cap[s] > 0);
        const total = al.reduce((s, x) => s + cap[x], 0) + pileCap;
        if (total === 0) {
          ok = false;
          break;
        }
        let r = rng.next() * total;
        let placed = false;
        for (const s of al) {
          r -= cap[s];
          if (r < 0) {
            hands2[s].push(id);
            cap[s]--;
            placed = true;
            break;
          }
        }
        if (!placed) {
          undealt.push(id);
          pileCap--;
        }
      }
      if (!ok || others.some((s) => cap[s] !== 0)) continue;
      let weight = 1;
      for (const s of others) {
        for (const n of NUMBERS) {
          const L = k.likelihood[s][n];
          if (L !== 1 && hands2[s].some((t) => has(t, n))) weight *= L;
          const kk = k.playedNum[s][n];
          if (kk >= 3) weight *= Math.pow(1 + 0.15 * (kk - 2), hands2[s].filter((t) => has(t, n)).length);
        }
        for (const t of hands2[s]) {
          const f = k.tileL[s].get(t);
          if (f != null) weight *= f;
        }
      }
      return { hands: hands2, undealt, weight };
    }
    const tiles = rng.shuffle([...k.unknown]);
    const hands = [[], [], [], []];
    hands[k.seat] = [...k.hand];
    for (const s of others) hands[s] = tiles.splice(0, k.counts[s]);
    return { hands, undealt: tiles, weight: 1e-6 };
  }
  function trueCount(k) {
    return NUMBERS.map((n) => {
      const unknown = k.unknown.filter((u) => has(u, n)).length;
      const voidSeats = [0, 1, 2, 3].filter((s2) => s2 !== k.seat && k.voids[s2][n]);
      const expectedBySeat = [0, 1, 2, 3].map((s2) => s2 === k.seat ? k.myCount[n] : Math.round(pHasAny(k, s2, [n]) * 100) / 100);
      return { number: n, played: k.playedCount[n], mine: k.myCount[n], unknown, voidSeats, expectedBySeat };
    });
  }

  // src/evaluate.ts
  function profile(hand) {
    const counts = NUMBERS.map((n) => hand.filter((t) => has(t, n)).length);
    const doubles = hand.filter((t) => T(t).double);
    const fallos = NUMBERS.filter((n) => counts[n] === 0);
    const fallas = hand.filter((t) => {
      const x = T(t);
      return !x.double && (counts[x.hi] === 1 || counts[x.lo] === 1);
    });
    const doubleFallas = hand.filter((t) => {
      const x = T(t);
      return !x.double && counts[x.hi] === 1 && counts[x.lo] === 1;
    });
    const longestData = Math.max(...counts);
    const dataNumbers = NUMBERS.filter((n) => counts[n] === longestData);
    const pips2 = hand.reduce((s, t) => s + T(t).pips, 0);
    let klass = "NORMAL";
    if (doubles.length > 3 || fallos.length > 2) klass = "BAD";
    else if (fallos.length === 0 || longestData >= 5) klass = "GOOD";
    const strategy = klass === "GOOD" ? "favorOwn" : klass === "BAD" ? "supportPartner" : "adapt";
    return { counts, doubles, fallos, fallas, doubleFallas, longestData, dataNumbers, pips: pips2, klass, strategy };
  }
  function leadOptions(hand) {
    const p = profile(hand);
    const c = p.counts;
    const out = [];
    const otherDoubleOrHeavy = (tile) => hand.some((t) => t !== tile && (T(t).double ? T(t).hi >= 4 : T(t).pips >= 13));
    for (const tile of hand) {
      const t = T(tile);
      const why = [];
      let s;
      if (t.double) {
        const backing = c[t.hi] - 1;
        s = 14 + t.hi + 3 * Math.min(backing, 4);
        why.push(`double ${tile} backed by ${backing}`);
        if (backing < 2) {
          s -= 6;
          why.push("under-backed double (\xA73.1 needs \u22652)");
        }
        if (t.hi >= 7) {
          s += 4;
          why.push("high double: dump the awkward tile (p.42)");
        }
        if (t.hi < 4 && backing < 3) {
          s -= 8;
          why.push("low double needs \u22653 backing");
        }
        if (t.hi <= 1) {
          s -= 6;
          why.push("B-B/1-1 only as last resort");
        }
        if (hand.some((h) => h !== tile && has(h, t.hi) && !T(h).double && c[other(h, t.hi)] >= 4)) {
          s += 3;
          why.push("its backing tile links to a data of 4+ (E-3.6)");
        }
        if (backing >= 4 && otherDoubleOrHeavy(tile)) {
          s -= 8;
          why.push("very good data double: keep it, lead another tile (\xA73.1)");
        }
      } else {
        s = t.pips + 1.5 * (c[t.hi] + c[t.lo]);
        why.push(`capic\xFAa ${tile}: ${t.pips} pips, numbers held ${c[t.hi]}+${c[t.lo]}`);
        if (Math.min(c[t.hi], c[t.lo]) < 3) {
          s -= 4;
          why.push("a number backed <3");
        }
        if (t.pips < 10) {
          s -= 15;
          why.push("never lead a capic\xFAa under 10 pips");
        }
      }
      out.push({ tile, score: s, why });
    }
    return out.sort((a, b) => b.score - a.score);
  }
  var bestLead = (hand) => leadOptions(hand)[0];
  function leadStrength(hand) {
    const p = profile(hand);
    let s = bestLead(hand).score;
    if (p.fallos.length >= 2) s += 4;
    return s;
  }
  function openingSignal(hand) {
    const p = profile(hand);
    if (p.doubles.length > 3) return "ven";
    return leadStrength(hand) >= 27 ? "voy" : "dime";
  }
  function answerSignal(hand) {
    return leadStrength(hand) >= 22 ? "voy" : "sal";
  }

  // src/block.ts
  var SORTED = [...ALL_TILES].map((t) => t.pips).sort((a, b) => a - b);
  function tableMinMax(n) {
    const min = SORTED.slice(0, n).reduce((a, b) => a + b, 0);
    const max = SORTED.slice(-n).reduce((a, b) => a + b, 0);
    return { min, max };
  }
  function heuristicBlock(myPips, myTiles, oppTiles) {
    const avg = myTiles === 0 ? 0 : myPips / myTiles;
    const minOpp = Math.min(...oppTiles);
    const fewer = minOpp - myTiles;
    if (fewer < 0) {
      const ok = avg <= 3;
      return { ok, avg, reason: `more tiles than an opponent: needs avg \u22643 (have ${avg.toFixed(1)})` };
    }
    if (fewer === 0) {
      const ok = avg <= 5;
      return { ok, avg, reason: `equal tiles: avg \u22645 contests the block (have ${avg.toFixed(1)})` };
    }
    const limit = Math.min(10, 5 + 1.5 * fewer);
    return { ok: avg <= limit, avg, reason: `${fewer} fewer tiles: avg \u2264${limit.toFixed(1)} acceptable (have ${avg.toFixed(1)})` };
  }
  function blockQuality(points, won) {
    if (won) return points <= 25 ? "acceptable" : points <= 50 ? "good" : points <= 99 ? "very good" : "winning";
    return points <= 25 ? "bad" : points <= 50 ? "very bad" : points <= 99 ? "terrible" : "losing";
  }
  function blockOutcome(handsAfter, seat, scoring = "losingPair") {
    const pips2 = handsAfter.map((h) => sumPips(h));
    const min = Math.min(...pips2);
    const low = [0, 1, 2, 3].filter((i) => pips2[i] === min);
    const pairs = new Set(low.map(pairOf));
    if (pairs.size !== 1) return 0;
    const winner = low.map(pairOf)[0];
    const loser = 1 - winner;
    const pts = scoring === "allHands" ? pips2.reduce((a, b) => a + b, 0) : pips2[loser] + pips2[loser + 2];
    return winner === pairOf(seat) ? pts : -pts;
  }

  // src/probability.ts
  function C(n, k) {
    if (k < 0 || k > n) return 0n;
    k = Math.min(k, n - k);
    let r = 1n;
    for (let i = 1; i <= k; i++) r = r * BigInt(n - k + i) / BigInt(i);
    return r;
  }
  var N_NUM = 10;
  var TILES = 55;
  var HAND = 10;
  var tilesOn = (m) => m * (m + 1) / 2;
  var TOTAL_HANDS = C(TILES, HAND);
  var ratio = (num, den = TOTAL_HANDS) => {
    const scale = 10n ** 15n;
    return Number(num * scale / den) / 1e15;
  };
  var handsWithDoubles = (k) => C(10, k) * C(45, HAND - k);
  function handsWithFallos(k) {
    let total = 0n;
    for (let j = k; j <= N_NUM; j++) {
      const term = C(j, k) * C(N_NUM, j) * C(tilesOn(N_NUM - j), HAND);
      total += (j - k) % 2 === 0 ? term : -term;
    }
    return total;
  }
  var handsWithExactlyNOf = (n) => 10n * C(10, n) * C(45, HAND - n);
  function handsWithMaxDataAtMost(m) {
    const key = (degs, edges) => degs.join(",") + "|" + edges;
    let states = /* @__PURE__ */ new Map([[key(Array(N_NUM).fill(0), 0), 1n]]);
    for (let step = 0; step < N_NUM; step++) {
      const next = /* @__PURE__ */ new Map();
      for (const [k, ways] of states) {
        const [dPart, ePart] = k.split("|");
        const degs = dPart === "" ? [] : dPart.split(",").map(Number);
        const edges = Number(ePart);
        const c = degs[0];
        const rest = degs.slice(1);
        const groups = /* @__PURE__ */ new Map();
        for (const d of rest) groups.set(d, (groups.get(d) ?? 0) + 1);
        const gl = [...groups.entries()];
        for (const loop of [0, 1]) {
          const rec = (gi, chosen, mult) => {
            if (gi === gl.length) {
              const add = chosen.reduce((a, b) => a + b, 0);
              const deg = c + loop + add;
              const e2 = edges + loop + add;
              if (deg > m || e2 > HAND) return;
              const nd = [];
              gl.forEach(([d, cnt2], i) => {
                for (let x = 0; x < cnt2 - chosen[i]; x++) nd.push(d);
                for (let x = 0; x < chosen[i]; x++) nd.push(d + 1);
              });
              if (nd.some((d) => d > m)) return;
              nd.sort((a, b) => a - b);
              const kk = key(nd, e2);
              next.set(kk, (next.get(kk) ?? 0n) + ways * mult);
              return;
            }
            const [, cnt] = gl[gi];
            for (let j = 0; j <= cnt; j++) rec(gi + 1, [...chosen, j], mult * C(cnt, j));
          };
          rec(0, [], 1n);
        }
      }
      states = next;
    }
    let total = 0n;
    for (const [k, ways] of states) if (Number(k.split("|")[1]) === HAND) total += ways;
    return total;
  }
  var cachedTable = null;
  function table81() {
    if (cachedTable) return cachedTable;
    const rows = [];
    for (let k = 0; k <= 6; k++) rows.push({ formation: "doubles", count: k, hands: handsWithDoubles(k), probability: ratio(handsWithDoubles(k)) });
    for (let k = 0; k <= 4; k++) rows.push({ formation: "fallos", count: k, hands: handsWithFallos(k), probability: ratio(handsWithFallos(k)) });
    const atMost = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((m) => handsWithMaxDataAtMost(m));
    for (let m = 2; m <= 8; m++) {
      const h = atMost[m] - atMost[m - 1];
      rows.push({ formation: "data", count: m, hands: h, probability: ratio(h) });
    }
    cachedTable = rows;
    return rows;
  }
  var BOOK_TABLE_81 = {
    doubles: [0.10907, 0.30298, 0.33164, 0.18618, 0.05848, 0.01053, 10697e-7],
    fallos: [0.25383, 0.450601, 0.249036, 0.044099, 2403e-6],
    data: { 3: 0.40558, 4: 0.47264, 5: 0.10431, 6: 0.010698, 7: 58218e-8, 8: 15231e-9 }
  };

  // src/notation.ts
  function parsePlays(text) {
    const out = [];
    for (const raw of text.split(/[,;\n]+/)) {
      const tok = raw.trim().replace(/^\d+\.\s*/, "");
      if (!tok) continue;
      const m = tok.match(/^(J[1-4])\s+(pass(?:es)?|[0-9B]-[0-9B])(?:\s*@([LR]))?$/i);
      if (!m) throw new Error(`Cannot parse play "${raw.trim()}"`);
      const rel = m[1].toUpperCase();
      if (/^pass/i.test(m[2])) out.push({ rel, tile: null, first: null });
      else {
        const [a] = m[2].toUpperCase().split("-");
        out.push({ rel, tile: T(m[2]).id, first: a === "B" ? 0 : Number(a), side: m[3]?.toUpperCase() });
      }
    }
    return out;
  }
  function toAction(h, p, observer) {
    const seat = absSeat(observer, p.rel);
    if (p.tile == null) return { type: "pass", seat };
    if (!h.ends) return { type: "play", seat, tile: p.tile };
    if (p.side) return { type: "play", seat, tile: p.tile, side: p.side };
    const { L, R } = h.ends;
    const t = T(p.tile);
    const fits = (v) => t.hi === v || t.lo === v;
    let side;
    if (p.first != null && (L.value === p.first || R.value === p.first) && fits(p.first)) {
      side = L.value === p.first ? "L" : "R";
    } else side = fits(L.value) ? "L" : "R";
    return { type: "play", seat, tile: p.tile, side };
  }
  function formatEvent(e, observer) {
    const who = relSeat(observer, e.seat);
    switch (e.kind) {
      case "signal":
        return `${who} ${e.signal}`;
      case "leader":
        return `${who} leads`;
      case "pass":
        return `${who} pass`;
      case "play":
        return e.matched == null ? `${who} ${e.tile}` : `${who} ${numLabel(e.matched)}-${numLabel(other(e.tile, e.matched))}`;
    }
  }
  var formatHand = (h, observer) => h.events.filter((e) => e.kind === "play" || e.kind === "pass").map((e, i) => `${i + 1}.${formatEvent(e, observer)}`).join(", ");

  // src/scenario.ts
  function scenarioView(sc) {
    const observer = sc.observer ?? 0;
    const leaderSeat = absSeat(observer, sc.leader);
    const config = withDefaults(sc.config);
    const s = {
      handNo: 1,
      dealt: [[], [], [], []],
      hands: [[], [], [], []],
      undealt: [],
      leadingPair: pairOf(leaderSeat),
      firstSpeaker: leaderSeat,
      leaderSeat,
      phase: "playing",
      toAct: leaderSeat,
      turn: 0,
      ends: null,
      events: [],
      result: null,
      redeals: 0
    };
    const counts = [10, 10, 10, 10];
    const plays = parsePlays(sc.plays);
    plays.forEach((p, i) => {
      const a = toAction(s, p, observer);
      if (a.type === "pass") {
        s.events.push({ kind: "pass", seat: a.seat, ends: [s.ends.L.value, s.ends.R.value], turn: s.turn, ...sc.thinkMs?.[i] != null ? { thinkMs: sc.thinkMs[i] } : {} });
      } else {
        placeTile(s, a.seat, a.tile, a.side, sc.thinkMs?.[i]);
        counts[a.seat]--;
      }
      s.turn++;
    });
    const hand = sc.hand.map((t) => T(t).id);
    const onTable = new Set(s.events.flatMap((e) => e.kind === "play" ? [e.tile] : []));
    for (const t of hand) if (onTable.has(t)) throw new Error(`Scenario: ${t} is both in hand and on the table`);
    if (new Set(hand).size !== hand.length) throw new Error("Scenario: duplicate tile in hand");
    counts[observer] = hand.length;
    return {
      seat: observer,
      hand,
      config,
      scores: sc.scores ?? [0, 0],
      handNo: 1,
      leadingPair: s.leadingPair,
      firstSpeaker: s.firstSpeaker,
      leaderSeat,
      phase: "playing",
      toAct: observer,
      turn: s.turn,
      ends: s.ends,
      events: s.events,
      tileCounts: counts
    };
  }

  // src/strategy/bot.ts
  function decide(v, opts = {}) {
    const level = opts.level ?? "high";
    const rng = new Rng(opts.seed ?? hashView(v));
    if (v.phase === "negotiating") return negotiate(v);
    if (v.phase !== "playing" || v.toAct !== v.seat) throw new Error("Not this seat's turn");
    const moves = legalMoves(v.hand, v.ends);
    if (moves.length === 0) {
      return { action: { type: "pass", seat: v.seat }, reasons: [{ criterion: "no legal tile: pass", delta: 0 }], candidates: [], suggestedDelayMs: 0, phase: phaseOf(v, analyze(v)) };
    }
    if (!v.ends) {
      const lead = bestLead(v.hand);
      return {
        action: { type: "play", seat: v.seat, tile: lead.tile },
        reasons: lead.why.map((w) => ({ criterion: w, delta: 0 })),
        candidates: [],
        suggestedDelayMs: 0,
        phase: "LEAD"
      };
    }
    const k = analyze(level === "low" ? forgetPasses(v) : v);
    const ctx = buildCtx(v, k, level, rng, opts);
    const distinct = dedupe(moves, v.ends);
    let scored = distinct.map((m) => scoreMove(ctx, m));
    if (level === "low" || level === "medium") {
      const sigma = level === "low" ? 9 : 3;
      scored = scored.map((s) => ({ ...s, score: s.score + sigma * rng.gauss() }));
    }
    scored.sort((a, b) => b.score - a.score);
    if (scored.length > 1) {
      const harm = (c) => -c.reasons.filter((r) => r.delta < 0 && /partner|J3|linking tile/.test(r.criterion)).reduce((a, r) => a + r.delta, 0);
      const near = scored.filter((c) => c.score >= scored[0].score - 1.5);
      if (near.length > 1) {
        const pick = near.reduce((a, b) => harm(b) < harm(a) ? b : a);
        if (pick !== scored[0] && harm(pick) < harm(scored[0])) {
          pick.reasons = [{ criterion: "near-tie: least harm to the partner (note 85)", delta: 0 }, ...pick.reasons];
          scored = [pick, ...scored.filter((c) => c !== pick)];
        }
      }
    }
    if (level === "expert" && scored.length > 1 && v.hand.length > 1) {
      scored = rolloutRank(ctx, scored, rng, opts.rollouts ?? 24);
    }
    const best = scored[0];
    const delay = opts.tempo === "uniform" ? 0 : suggestDelay(ctx, scored);
    return {
      action: { type: "play", seat: v.seat, tile: best.move.tile, side: best.move.side ?? void 0, thinkMs: delay || void 0 },
      reasons: best.reasons,
      candidates: scored,
      suggestedDelayMs: delay,
      phase: ctx.phase
    };
  }
  function negotiate(v) {
    const signals = v.events.filter((e) => e.kind === "signal");
    if (v.config.leadNegotiation === "direct") {
      const me = leadStrength(v.hand) >= 22;
      const seat = me ? v.seat : partnerOf(v.seat);
      return { action: { type: "setLeader", seat }, reasons: [{ criterion: me ? "I want to lead" : "partner leads", delta: 0 }], candidates: [], suggestedDelayMs: 0, phase: "NEGOTIATION" };
    }
    const signal = signals.length === 0 ? openingSignal(v.hand) : answerSignal(v.hand);
    const why = signal === "ven" ? ">3 doubles: Ven, partner leads (\xA73.1)" : signal === "voy" ? "strong lead available: Voy (\xA73.1)" : signal === "dime" ? "ask partner: Dime (\xA73.1)" : "partner should lead: Sal (\xA73.1)";
    return { action: { type: "signal", seat: v.seat, signal }, reasons: [{ criterion: why, delta: leadStrength(v.hand) }], candidates: [], suggestedDelayMs: 0, phase: "NEGOTIATION" };
  }
  function phaseOf(v, k) {
    if (!v.ends) return "LEAD";
    const avg = v.tileCounts.reduce((a, b) => a + b, 0) / 4;
    if (avg <= 4 || Math.min(...v.tileCounts) <= 2) return "ENDING";
    const mine = k.playsBy[v.seat];
    if (mine === 0) return "FIRST";
    if (mine === 1) return "SECOND";
    return "MIDDLE";
  }
  function buildCtx(v, k, level, rng, opts) {
    const prof = profile(v.hand);
    const phase = phaseOf(v, k);
    const me = v.tileCounts[v.seat];
    const pc = v.tileCounts[k.partner];
    const partnerAhead = pc < me;
    const meAhead = me < pc;
    const nSamples = level === "high" || level === "expert" ? opts.samples ?? 48 : 0;
    const samples = [];
    for (let i = 0; i < nSamples; i++) samples.push(sampleDeal(k, rng));
    const myPlayed = v.events.filter((e) => e.kind === "play" && e.seat === v.seat).map((e) => e.tile);
    const profInit = profile([...v.hand, ...myPlayed]);
    let ownWeight = profInit.strategy === "favorOwn" ? 1.3 : profInit.strategy === "supportPartner" ? 0.75 : 1;
    let partnerWeight = profInit.strategy === "supportPartner" ? 1.4 : profInit.strategy === "favorOwn" ? 0.85 : 1;
    if (profInit.doubles.length > 3 && profInit.fallos.length > 2) {
      partnerWeight *= 1.1;
      ownWeight *= 0.9;
    }
    if (profInit.fallos.length >= 2) partnerWeight *= 1.1;
    const weak = profInit.klass !== "GOOD" && (profInit.doubles.length >= 3 || profInit.fallos.length >= 2 || profInit.fallas.length >= 4);
    if (weak && k.leaderSeat === k.j4) {
      partnerWeight *= 1.25;
      ownWeight *= 0.85;
    } else if (weak && k.leaderSeat === k.j2) {
      partnerWeight *= 1.12;
      ownWeight *= 0.92;
    }
    if (partnerAhead) {
      partnerWeight *= 1.5;
      ownWeight *= 0.8;
    }
    if (k.passesBy[v.seat] >= 2) partnerWeight *= 1.3;
    const trust = Math.max(0.6, Math.min(1.4, opts.partnerTrust ?? 1));
    partnerWeight *= trust;
    ownWeight *= 1 + (1 - trust) * 0.5;
    const ownPairLed = k.leaderSeat != null && pairOf(k.leaderSeat) === pairOf(v.seat) && k.leadTile != null;
    const lt = k.leadTile ? T(k.leadTile) : null;
    const partnerPassedLead = !!(ownPairLed && lt && (k.voids[k.partner][lt.hi] || k.voids[k.partner][lt.lo]) && (phase === "FIRST" || phase === "SECOND"));
    if (partnerPassedLead) partnerWeight *= 0.6;
    return { v, k, prof, phase, partnerAhead, meAhead, level, samples, ownWeight, partnerWeight, partnerPassedLead };
  }
  function whoOwns(k, seat) {
    if (seat == null) return null;
    if (seat === k.seat) return "me";
    if (seat === k.partner) return "partner";
    if (seat === k.j2) return "j2";
    return "j4";
  }
  var numberOwner = (k, n, end) => whoOwns(k, k.numberOwner[n] ?? end?.owner ?? null);
  var isOpp = (w) => w === "j2" || w === "j4";
  var pairDoubled = (k, n) => {
    const d = idOf(n, n);
    const by = k.playedBy.get(d);
    return by != null && pairOf(by) === pairOf(k.seat);
  };
  function takeoverCheck(k, n, phase, ownerCovered, leftAfter) {
    const held = k.myCount[n];
    const strong = opponentStrong(k).includes(n);
    if (held < 3 || !strong && held < 4) return { ok: false, bonus: 0 };
    if (k.voids[k.partner][n]) return { ok: false, bonus: 0, why: "the partner passed on it" };
    if (ownerCovered === "partner") return { ok: false, bonus: 0, why: "it would cover the partner's number (E-3.69)" };
    const ev = k.events;
    for (let i = 0; i < ev.length; i++) {
      const a = ev[i];
      if (a.kind !== "play" || a.seat !== k.seat || a.exposed !== n || a.side == null) continue;
      for (let j = i + 1; j < ev.length; j++) {
        const b = ev[j];
        if (b.kind === "play" && b.side === a.side) {
          if (b.seat === k.j4 && b.matched === n) return { ok: false, bonus: 0, why: "J4 already killed it once" };
          break;
        }
      }
    }
    if (phase === "ENDING" && leftAfter < 2) return { ok: false, bonus: 0, why: "not enough backing left for the ending (E-6.18)" };
    let bonus = 4 + 2 * Math.min(3, held - 3);
    if (held >= 5) bonus += 3;
    return { ok: true, bonus };
  }
  function noPartnerSupport(k, end, turnNow) {
    if (turnNow - end.turn < 4) return false;
    let partnerPlays = 0;
    for (const e of k.events) {
      if (e.kind !== "play" || e.seat !== k.partner || e.turn <= end.turn) continue;
      partnerPlays++;
      if (e.matched === end.value || e.exposed === end.value) return false;
    }
    return partnerPlays >= 1;
  }
  function throwHarm(k, z) {
    const ow = whoOwns(k, k.numberOwner[z]);
    const ours = ow === "me" || ow === "partner";
    if (ours && !k.voids[k.partner][z]) return 0;
    const pJ3 = k.voids[k.partner][z] ? 0 : pHasAny(k, k.partner, [z]);
    let h = 12 * (1 - pJ3);
    if (isOpp(ow)) h += 4;
    if (opponentStrong(k).includes(z)) h += 3;
    return h;
  }
  function pHoldsTile(k, seat, id, gone = /* @__PURE__ */ new Set()) {
    if (seat === k.seat) return k.hand.includes(id) && !gone.has(id) ? 1 : 0;
    if (k.played.has(id) || k.hand.includes(id) || gone.has(id)) return 0;
    const t = T(id);
    if (k.voids[seat][t.hi] || k.voids[seat][t.lo] || k.counts[seat] === 0) return 0;
    let cap = 15;
    for (let s = 0; s < 4; s++) if (s !== k.seat && !k.voids[s][t.hi] && !k.voids[s][t.lo]) cap += k.counts[s];
    let q = k.counts[seat] / Math.max(1, cap);
    q *= Math.min(1.6, k.likelihood[seat][t.hi]) * (t.double ? 1 : Math.min(1.6, k.likelihood[seat][t.lo])) * (k.tileL[seat].get(id) ?? 1);
    return Math.min(1, q);
  }
  function pairShare(k, n, mineCount, gone = /* @__PURE__ */ new Set()) {
    let part = 0, opp = 0;
    for (const id of TILES_WITH[n]) {
      if (k.played.has(id) || k.hand.includes(id) || gone.has(id)) continue;
      part += pHoldsTile(k, k.partner, id, gone);
      opp += pHoldsTile(k, k.j2, id, gone) + pHoldsTile(k, k.j4, id, gone);
    }
    if (k.exposedBy[k.partner].has(n) && !k.voids[k.partner][n]) part += 0.75;
    if (k.leaderSeat === k.partner && k.leadTile && T(k.leadTile).double && T(k.leadTile).hi === n && !k.voids[k.partner][n]) part += 2;
    const tot = mineCount + part + opp;
    return tot <= 0 ? 0 : (mineCount + part) / tot;
  }
  function matchUtility(pts, v) {
    const target = v.config.targetPoints;
    const mp = pairOf(v.seat);
    const myNeed = Math.max(1, target - v.scores[mp]);
    const opNeed = Math.max(1, target - v.scores[1 - mp]);
    if (pts > 0) return pts >= myNeed ? myNeed + 40 : pts;
    if (pts < 0) return -pts >= opNeed ? -(opNeed + 40) : pts;
    return 0;
  }
  function opponentStrong(k) {
    const out = /* @__PURE__ */ new Set();
    if (k.leadTile && k.leaderSeat != null && pairOf(k.leaderSeat) !== pairOf(k.seat)) {
      out.add(T(k.leadTile).hi);
      out.add(T(k.leadTile).lo);
    }
    const f = k.firstNumber[k.j2];
    if (f != null) out.add(f);
    return [...out];
  }
  var W = {
    heavy: { LEAD: 1, FIRST: 0.9, SECOND: 0.8, MIDDLE: 0.7, ENDING: 0.25 },
    falloNew: { LEAD: 0, FIRST: 7, SECOND: 6, MIDDLE: 4, ENDING: 1.5 },
    stuck: { LEAD: 0, FIRST: 16, SECOND: 16, MIDDLE: 18, ENDING: 24 },
    passJ2: { LEAD: 0, FIRST: 7, SECOND: 8, MIDDLE: 10, ENDING: 16 },
    data: 2.5,
    partnerNum: 7,
    throwWithPartner: 6,
    oppGive: 12,
    kill: 7,
    killPartner: 8
  };
  function scoreMove(ctx, m) {
    const { v, k, prof, phase } = ctx;
    const R = [];
    const add = (criterion, delta) => {
      if (Math.abs(delta) >= 0.05) R.push({ criterion, delta: Math.round(delta * 10) / 10 });
    };
    const ends = v.ends;
    const side = m.side;
    const X = ends[side];
    const Y = ends[side === "L" ? "R" : "L"];
    const t = T(m.tile);
    const x = X.value, y = Y.value;
    const e = other(m.tile, x);
    const isD = t.double;
    const handAfter = v.hand.filter((h) => h !== m.tile);
    const cntAfter = k.myCount.map((c, n) => c - (has(m.tile, n) ? 1 : 0));
    if (handAfter.length === 0) {
      add("domino: go out (pegarse)", 1e3);
      return finalize(m, R);
    }
    const ownerX = numberOwner(k, x, X);
    let heavy = W.heavy[phase] * t.pips;
    if (isOpp(ownerX) && !isD) heavy *= 1.3;
    if (k.counts[k.j2] === 1 && phase === "ENDING") heavy *= 2.5;
    const opNeed = v.config.targetPoints - v.scores[1 - pairOf(v.seat)];
    if (opNeed <= 25) heavy *= 0.6;
    if (ctx.partnerPassedLead) heavy *= 1.15;
    add("heavy tile first (p.42)", heavy);
    const nE = handAfter.filter((h) => has(h, e)).length;
    const nY = handAfter.filter((h) => has(h, y)).length;
    if (nE === 0 && nY === 0) {
      const pOut = k.counts[k.j2] === 1 ? pHasAny(k, k.j2, [e, y]) : 0;
      add("leaves no next play (p.41)", -W.stuck[phase] * (1 - pOut));
    } else if (nE > 0 && nY > 0) add("playable on both ends next turn (p.41)", 4);
    const newFallos = [t.hi, t.lo].filter((n, i, a) => a.indexOf(n) === i && k.myCount[n] > 0 && cntAfter[n] === 0);
    const killingOppLead = k.leaderSeat != null && pairOf(k.leaderSeat) !== pairOf(k.seat) && X.tile === k.leadTile;
    const killingJ4Lead = killingOppLead && k.leaderSeat === k.j4;
    if (newFallos.length && !isD) {
      if (phase === "FIRST" && killingJ4Lead && prof.fallos.length === 0 && !isD && k.myCount[x] < 3) {
        add("kill the opponents' lead with the falla (\xA73.2.1)", 4);
      } else {
        let pen = W.falloNew[phase] * newFallos.length;
        if (prof.fallos.length >= 1) pen *= 1.5;
        if (ctx.partnerPassedLead) pen *= 1.7;
        if (newFallos.includes(0) && (phase === "MIDDLE" || phase === "ENDING")) pen *= 1.3;
        add("creates a new fallo (\xA71.5, p.43)", -pen);
      }
    }
    const isThrowMove = !isD && e === y;
    const isTakeover = !isD && isOpp(numberOwner(k, e)) && k.myCount[e] >= 3;
    if (prof.fallos.length >= 1 && (phase === "FIRST" || phase === "SECOND") && !isD && !isThrowMove && !isTakeover) {
      const fallaNum = [t.hi, t.lo].find((n) => k.myCount[n] === 1);
      if (fallaNum != null && !(killingOppLead && prof.fallos.length === 0)) {
        const otherN = other(m.tile, fallaNum);
        const allowed = (k.voids[k.j2][otherN] || k.voids[k.j4][otherN]) && k.myCount[otherN] >= 2;
        if (!allowed) add("keep your fallas in a hand with fallos de mano (p.43, note 91)", prof.fallos.length >= 2 ? -4 : -2);
      }
      if (ownerX === "j4" && phase === "FIRST") add("let J4's tile pass to J3 (p.43, note 91)", -2);
    }
    const eOwner = numberOwner(k, e);
    const b = cntAfter[e];
    {
      const remaining = Math.max(1, 10 - k.playedCount[e] - (has(m.tile, e) && k.played.has(m.tile) ? 0 : 1));
      const share = Math.min(1, b / remaining);
      let boost = 1 + 0.1 * prof.fallos.length + (k.voids[k.j2][e] || k.voids[k.j4][e] ? 0.3 : 0);
      add("give your own number / play your data (\xA74.1, note 27/71)", ctx.ownWeight * W.data * Math.min(b, 4) * (0.8 + 0.6 * share) * boost);
    }
    if (k.exposedBy[k.seat].has(e) && !isD) add("repeat your own tile (\xA75.1)", 3);
    const ownLead = k.leadTile != null && k.leaderSeat != null && pairOf(k.leaderSeat) === pairOf(k.seat) && has(k.leadTile, e);
    if (ownLead && !isD && (phase === "SECOND" || phase === "FIRST") && !k.voids[k.partner][e]) {
      add("give the own lead again (\xA74.1.5)", 4 + (k.voids[k.j4][e] ? 3 : 0));
    }
    const partnerVoidE = k.voids[k.partner][e];
    if (!partnerVoidE && !isD) {
      if (eOwner === "partner") add("give the partner's number (\xA74.2.5, first sight)", ctx.partnerWeight * W.partnerNum * ((phase === "MIDDLE" || phase === "ENDING") && k.lastExposed[k.partner][e] >= v.turn - 4 ? 1.25 : 1));
      if (e === y && eOwner === "partner") add("throw with J3 (tirar con J3, \xA74.1.1)", ctx.partnerWeight * W.throwWithPartner);
      if (eOwner === "partner" && phase !== "FIRST" && !k.seenBy[k.j2].has(e)) add("J2 sees the partner's number for the first time (p.146, avoid hasta la pata)", 2);
    }
    const takeover = !isD && isOpp(eOwner) ? takeoverCheck(k, e, phase, ownerX, cntAfter[e]) : null;
    if (takeover && takeover.ok) {
      add(`take over the opponents' ${e}: you hold ${k.myCount[e]} (p.42, Ch.5 after E-5.10)`, takeover.bonus);
      if (e === y) add("throw to it: the number becomes yours and the lead can't return (E-4.37, E-4.43)", 4);
    } else if (takeover && takeover.why) {
      add(`can't take over the ${e}: ${takeover.why}`, 0.1);
    }
    if (!isD && isOpp(eOwner) && !(takeover && takeover.ok)) {
      let pen = W.oppGive * (eOwner === "j2" ? 1.2 : 1) * (phase === "ENDING" ? 1.4 : 1);
      if ((phase === "MIDDLE" || phase === "ENDING") && (k.lastExposed[k.j2][e] >= v.turn - 4 || k.lastExposed[k.j4][e] >= v.turn - 4)) pen *= 1.15;
      if (b >= 3) pen *= 0.3;
      else if (pairDoubled(k, e)) pen *= 0.5;
      add(`gives the opponent's number ${e} (\xA75.6)`, -pen);
    }
    if (isD && ownerX === "j4" && (phase === "FIRST" || phase === "SECOND")) add("double on J4's number (\xA73.1.2)", 2);
    if (isD && isOpp(ownerX) && k.myCount[x] >= 4) {
      add(`double on the opponents' ${x}: it's your data (E-3.69, E-4.27)`, k.myCount[x] >= 5 ? 11 : 6);
      const throwLink = x !== y ? idOf(x, y) : null;
      if (throwLink && v.hand.includes(throwLink) && numberOwner(k, y, Y) !== "partner") add("a throw to it is available: play the data at the first chance (E-4.37)", -5);
      if (k.voids[k.j4][x] && k.voids[k.j4][y]) add("the double keeps J4 locked out on both ends (E-4.27)", 4);
    }
    if (!isD) {
      if (isOpp(ownerX)) {
        add("kill the opponent's number", W.kill);
        if (ownerX === "j2") add("kill J2's number before J4's (\xA74.2.1)", 3);
        const rounds = Math.floor((v.turn - X.turn) / 4);
        if (rounds >= 1) add("opponent tile stayed more than a round (\xA75.5)", 3 * Math.min(2, rounds));
        if (k.voids[k.partner][x]) add("kill the number that passed your partner (\xA74.2.3, \xA75.5)", 10);
        if (isOpp(numberOwner(k, y, Y)) && X.turn < Y.turn) add("kill the oldest (p.42)", 2);
        if (killingOppLead && (phase === "FIRST" || phase === "SECOND")) add("cover the opponents' lead", 3);
      } else if (ownerX === "partner") {
        let pen = W.killPartner * (ctx.partnerAhead ? 1.5 : 1);
        add("kills the partner's number (\xA73.1.2)", -pen);
      } else if (ownerX === "me") {
        const fijo = (10 - k.tableTotal[x] === 0 || [k.j2, k.partner, k.j4].every((s2) => pHasAny(k, s2, [x]) < 0.1)) && k.myCount[x] >= 2;
        if (k.myCount[e] >= 3 && k.playedCount[e] > 0 && !isD) add("kill your own number with a strong tile, not a fresca (\xA75.1, note 35)", 3);
        const avgLeft = handAfter.reduce((a2, h) => a2 + T(h).pips, 0) / Math.max(1, handAfter.length);
        if (fijo && phase === "ENDING" && avgLeft > 6) add("open the game rather than block and lose at the count (\xA76.3, note 44)", 8);
        const love = noPartnerSupport(k, X, v.turn);
        const isLeadNum = k.leadTile != null && has(k.leadTile, x);
        if (fijo) add("kills a number you are fijo to (\xA75.2)", -10);
        else if (ctx.partnerPassedLead && isLeadNum) {
          if (k.myCount[x] >= 4) add("keep the own lead: it's good data (\xA74.1.4)", -4);
          else add("kill your own lead to open the game for J3 (\xA74.1.4)", 3);
        } else if (love) {
          let b5 = 5;
          if (pHasAny(k, k.partner, [x]) < 0.35) b5 += 3;
          if (ctx.partnerAhead || k.leaderSeat === k.partner) b5 += 2;
          if (k.myCount[x] >= 4 && pHasAny(k, k.partner, [x]) >= 0.35) b5 -= 3;
          add("don't fall in love with a tile: J3 gives it no support, open his game (\xA75.3)", b5);
        } else if (!k.voids[k.partner][x]) add("kills your own number", -1.5 * cntAfter[x]);
      }
      if (!isOpp(ownerX) && !k.voids[k.partner][x]) {
        const pen = (k.voids[k.j2][x] ? 8 : 0) + (k.voids[k.j4][x] ? 5 : 0);
        if (pen) add("covers our number that passes the opponents (\xA75.2, \xA74.1.7)", -pen);
      }
    }
    const newEnds = [e, y];
    const pJ2 = pHasAny(k, k.j2, newEnds);
    const pJ3 = pHasAny(k, k.partner, newEnds);
    const pJ4 = pHasAny(k, k.j4, newEnds);
    let wJ2 = W.passJ2[phase] * (k.counts[k.j2] <= 2 ? 1.5 : 1);
    add("make J2 pass (\xA76.10)", wJ2 * (1 - pJ2));
    add("keep J4 controlled (\xA73.2.2.5)", 4 * (1 - pJ4));
    let wJ3 = (phase === "ENDING" ? 8 : 5) * ctx.partnerWeight;
    if (k.counts[k.partner] === 1) {
      wJ3 *= 2.5;
      if (!isD && k.exposedBy[k.seat].has(e)) add("repeat a tile so J2 kills it with a fresca or passes (\xA76.7)", 3);
      if (!k.seenBy[k.j2].has(e) && !k.seenBy[k.j2].has(y)) add("two frescas for J2: he kills one, the other reaches J3 (\xA76.7)", 3);
    }
    add("partner can play (\xA76.6-6.7)", wJ3 * pJ3);
    for (const s of opponentStrong(k)) {
      let entries = 0;
      for (const end of newEnds) {
        const id = idOf(s, end);
        if (end === s ? TILES_WITH[s].some((u) => !k.played.has(u) && u !== m.tile && !handAfter.includes(u)) : !k.played.has(id) && id !== m.tile && !handAfter.includes(id)) entries++;
      }
      if (entries === 2) add(`opponents' strong ${s} can enter on both ends (\xA74.2.4)`, -5);
      if (entries === 0 && k.leadTile && has(k.leadTile, s) && k.unknown.some((u) => has(u, s))) add(`opponents' lead ${s} can't re-enter next turn (E-4.43)`, 4);
    }
    const gone = /* @__PURE__ */ new Set([m.tile]);
    if (!k.voids[k.partner][e] || b > 0) {
      const share = pairShare(k, e, b, gone);
      if (share > 0.6 && (b > 0 || k.exposedBy[k.partner].has(e))) add(`our pair holds most of the ${e}s (~${Math.round(share * 100)}%, \xA78.1, E-4.45)`, 10 * (share - 0.6) / 0.4);
    }
    if (!isD && (ownerX === "me" || ownerX === "partner") && !k.voids[k.partner][x]) {
      const shareX = pairShare(k, x, cntAfter[x], gone);
      if (shareX > 0.65) add(`covers a number our pair dominates (~${Math.round(shareX * 100)}%)`, -6 * (shareX - 0.65) / 0.35);
    }
    if (e !== y) {
      const link = idOf(e, y);
      const q = pHoldsTile(k, k.j2, link, gone);
      if (q > 0) {
        const harm = Math.max(throwHarm(k, e), throwHarm(k, y));
        if (harm > 0) add(`J2 could throw with the linking tile ${link} (\xA74.1.3, E-4.35)`, -q * harm);
      } else if (handAfter.includes(link) && Math.max(throwHarm(k, e), throwHarm(k, y)) > 0) {
        add(`you hold the linking tile ${link}: J2 can't throw (E-4.35)`, 2);
      }
    }
    const escape = (n) => (k.voids[k.j4][n] || k.likelihood[k.j4][n] < 0.45) && cntAfter[n] >= 1;
    if ([e, y].some(escape)) add("keeps your escape route open: a number J4 lacks (\xA73.2.2.5)", 3);
    else if (!isD && escape(x) && x !== y) add("closes your escape route against J4 (\xA73.2.2.5)", -4);
    for (const sd of ["L", "R"]) {
      const En = ends[sd];
      const isJ2Lead = k.leaderSeat === k.j2 && k.leadTile != null && has(k.leadTile, En.value) && numberOwner(k, En.value, En) === "j2";
      if (isJ2Lead && k.voids[k.partner][En.value] && v.turn - En.turn >= 4 && sd !== side) add("ducking J2's lead after J3 passed on it (Ch.5, E-5.10)", -6);
    }
    if (!isD && ownerX === "j2" && k.declinedLead[k.partner] && k.events.some((ev) => ev.kind === "play" && ev.seat === k.partner && T(ev.tile).double && ev.thinkMs != null && ev.thinkMs <= 1e3)) add("J3 declined the lead and doubled instantly: kill J2's number (note 17)", 4);
    for (let yy = 0; yy <= 9; yy++) if (k.playedNum[k.j4][yy] >= 3 && cntAfter[yy] === 0 && k.myCount[yy] > 0) add(`leaves you fallo to J4's data number ${yy} (note 73)`, -2);
    if (isD) {
      add("play a double", 2);
      if (ctx.partnerPassedLead) add("\xA74.1.4 priority 2: double", 4);
      if (phase === "MIDDLE" && k.playedCount[x] <= 1 && prof.doubles.length <= 3) add("don't double on a fresh number in the middle game (Ch.4 E-4.19)", -3);
      const nD = prof.doubles.length + v.events.filter((ev) => ev.kind === "play" && ev.seat === k.seat && T(ev.tile).double).length;
      if (nD > 3) add(">3 doubles dealt: unload them (\xA74.1.4, Ch.8)", 9);
      else if (nD === 3) add("3 doubles dealt: raise the priority of shedding them (note 70)", 5 + (t.hi >= 7 ? 2 : 0));
      else if (nD >= 2) add("several doubles in hand", 2);
      if (ownerX === "partner" && k.voids[k.j4][x]) add("double on the partner's number that just passed J4 (Ch.2, \xA74.1.7)", 7);
      const unk = 10 - k.tableTotal[x];
      if (unk <= 2) add("double at risk of being strangled (ahorcar)", 5);
      const lp = k.lastPlay;
      if (lp && v.events.length >= 2) {
        const prev = [...v.events].reverse().find((ev) => ev.kind === "play" && ev.seat === k.partner);
        if (prev && prev.kind === "play" && prev.exposed === x && prev.otherEnd === x) add("partner threw to draw out the double (\xA74.1.9)", 4);
      }
      if (phase === "ENDING" && t.hi >= 7 && !(ownerX === "me" || ownerX === "partner")) add("high double in the ending (Ch.6)", -3);
      if (phase === "ENDING" && (ownerX === "me" || ownerX === "partner") && k.voids[k.j2][x]) add("double on the pair's strong number (\xA76.4)", 6);
      if (x === y && X.seat === k.partner) add("play the double on the end the partner used: tells him there are more (E-6.8)", 1);
    }
    if (phase === "ENDING" && !isD && k.playedCount[e] === 0 && b >= 2) add("starting a data in the ending (Ch.6, note 40)", -3);
    const fresh = k.playedCount[e] === 0 && !isD;
    if (fresh) add(phase === "ENDING" ? "fresca in the ending (Ch.6)" : "fresca (prefer repeating, \xA75.1)", phase === "ENDING" ? -5 : phase === "MIDDLE" ? -2 : 0);
    if (k.pausedOn.some((p) => p.seat === k.partner && p.number === e && v.turn - p.turn <= 8)) add("partner paused on this number: he holds more (E-6.16)", 6);
    if (phase === "FIRST" && k.leaderSeat != null && k.leadTile) {
      const lead = T(k.leadTile);
      const holdsDouble = (n) => v.hand.includes(idOf(n, n));
      const bestData = Math.max(...k.myCount);
      const heaviestAlt = Math.max(...v.hand.filter((h) => has(h, x) || has(h, y)).map((h) => T(h).pips));
      if (k.leaderSeat === k.partner) {
        const j4Played = k.events.some((ev) => ev.kind === "play" && ev.seat === k.j4);
        if (!j4Played) {
          if (!isD) add("partner led, J4 passed: cover with a low number, keep the high ones (\xA73.1.2)", 0.6 * (9 - e));
          if (!isD && k.myCount[e] === 1 && t.pips < 13) add("don't play the falla on the partner's lead (\xA73.1.2)", -3);
        } else if (isD && ownerX === "partner" && !lead.double) {
          add("partner led a capic\xFAa: double on his end (\xA73.1.2)", 9);
        } else if (!isD && !lead.double && [ends.L, ends.R].some((En) => En.owner === k.partner && holdsDouble(En.value))) {
          add("partner led a capic\xFAa: the double on his end comes before the throw (\xA73.1.2 order)", -9);
        } else if (isD && ownerX === "j4") {
          const farLighter = t.pips + 8 < heaviestAlt;
          const lowNotData = x < 4 && k.myCount[x] < 3;
          const thinBetterData = k.myCount[x] - 1 <= 1 && bestData >= 4 && bestData > k.myCount[x];
          if (!farLighter && !lowNotData && !thinBetterData) add("partner led: double on J4's number (\xA73.1.2)", 8);
        }
        if (!isD && lead.double && ownerX === "partner" && k.myCount[x] !== 2) add("respect the partner's lead: kill it only exceptionally (\xA73.1.2)", -3);
      } else if (k.leaderSeat === k.j4) {
        if (lead.double) {
          if (!isD && holdsDouble(e) && e !== x) add("don't play the number you hold the double of; seek its link (\xA73.2)", -5);
        } else {
          if (isD) {
            const otherD = x === lead.hi ? lead.lo : lead.hi;
            const better = holdsDouble(otherD) && (k.myCount[otherD] > k.myCount[x] + 1 || Math.abs(k.myCount[otherD] - k.myCount[x]) <= 1 && otherD > x);
            if (!better) add("J4 led a capic\xFAa: double on your data's double (\xA73.2)", 7);
          } else if (x === Math.min(lead.hi, lead.lo) && !v.hand.some((h) => T(h).double && (T(h).hi === lead.hi || T(h).hi === lead.lo))) {
            add("J4 led a capic\xFAa: kill the lower number, let the higher one through for J3 (\xA73.2)", 3);
          }
        }
      } else if (k.leaderSeat === k.j2) {
        const leadNum = lead.hi;
        const coversLead = !isD && x === leadNum && ownerX === "j2";
        const linkThrow = idOf(e, y);
        const j2CouldThrow = lead.double && !v.hand.includes(linkThrow) && pHoldsTile(k, k.j2, linkThrow, gone) > 0;
        const j3Passed = k.voids[k.partner][leadNum];
        if (coversLead && (leadNum > 5 && k.myCount[leadNum] >= 2 && k.myCount[leadNum] <= 4 || j3Passed)) add("kill J2's lead (\xA73.2: number >5 with 2\u20134 held, or J3 passed)", 5);
        if (isD && ownerX === "j4" && x >= 4) {
          const killers = v.hand.filter((h) => h !== m.tile && has(h, leadNum));
          const killingHurts = killers.length > 0 && killers.every((h) => k.myCount[other(h, leadNum)] === 1 || k.myCount[leadNum] === 1);
          if (killingHurts || killers.length === 0) add("double on J4's number instead of killing J2's lead with a falla (\xA73.2)", 6);
        }
        if (coversLead && [t.hi, t.lo].some((n) => k.myCount[n] === 1) && v.hand.some((h) => T(h).double && ends[side === "L" ? "R" : "L"].owner === k.j4 && T(h).hi === y && y >= 4)) {
          add("the lead-killer is a falla and you hold J4's double: double instead (\xA73.2)", -20);
        }
        const onlyJ2End = v.ends && !v.hand.some((h) => [ends.L, ends.R].some((En) => En.owner !== k.j2 && has(h, En.value)));
        if (onlyJ2End && !isD && [t.hi, t.lo].some((n) => k.myCount[n] === 1)) add("only J2's end is playable: never the falla (\xA73.2)", -6);
      }
    }
    const newEndsArr = [e, y];
    const unknownWith = (n) => k.unknown.filter((u) => has(u, n) && u !== m.tile);
    if (phase === "ENDING" || v.hand.length <= 3) {
      if (handAfter.length === 1) {
        const last = T(handAfter[0]);
        const sure = newEndsArr.some((z) => (last.hi === z || last.lo === z) && unknownWith(z).length === 0);
        if (sure) add("domino guaranteed next turn: don't block (\xA76.1, E-6.1)", 25);
      }
      if (isD && v.hand.some((h) => h !== m.tile && has(h, x)) && [k.j2, k.partner, k.j4].every((s2) => pHasAny(k, s2, newEndsArr) < 0.05)) {
        add("the whole table passes on the double: play it first to gain a tempo (E-6.9)", 8);
      }
      const strongX = (ownerX === "me" || ownerX === "partner") && (unknownWith(x).length === 0 || k.myCount[x] >= 2);
      if (!isD && strongX) {
        const alts = v.hand.filter((h) => h !== m.tile && has(h, x) && !T(h).double && k.playedCount[other(h, x)] === 0);
        if (v.hand.length > 2 && alts.length) {
          const maxP = Math.max(t.pips, ...alts.map((h) => T(h).pips));
          if (maxP > t.pips) add("open off your strong number with the lightest tile, keep the other to close (\xA76.5)", 0.7 * (maxP - t.pips));
        }
        const avgAfter = handAfter.reduce((a, h) => a + T(h).pips, 0) / Math.max(1, handAfter.length);
        if (k.myCount[e] === 1 && avgAfter > 7) {
          add("open with the falla: many points left, avoid a forced block later (\xA76.5, E-6.13)", 5);
          if (nE === 0 && nY === 0) add("keeping the strong tile to close outweighs the next play here (E-6.13)", 0.75 * W.stuck[phase]);
        }
        if (k.leadTile && pairOf(k.leaderSeat ?? 0) === pairOf(k.seat) && has(k.leadTile, e)) add("open with the own lead number: it has precedence (E-6.11)", 3);
        const leadD = k.leadTile && T(k.leadTile).double ? T(k.leadTile).hi : -1;
        if (e > leadD && handAfter.includes(idOf(e, e))) add("open with the number whose double you hold (higher than the lead double) (\xA76.5)", 3);
      }
      if (handAfter.length >= 2 && [k.j2, k.partner, k.j4].every((s2) => pHasAny(k, s2, newEndsArr) < 0.02)) {
        const opts = handAfter.filter((h) => newEndsArr.some((z) => has(h, z)));
        if (opts.length) {
          let worstOk = true, bestRest = Infinity, allBlock = true;
          for (const o of opts) {
            const z = newEndsArr.find((zz) => has(o, zz));
            const e2 = other(o, z);
            const ends2 = [e2, newEndsArr[0] === z ? newEndsArr[1] : newEndsArr[0]];
            const rest = handAfter.filter((h) => h !== o);
            const blocks = !rest.some((h) => ends2.some((zz) => has(h, zz))) && ends2.every((zz) => unknownWith(zz).filter((u) => u !== o).length === 0);
            if (!blocks) {
              allBlock = false;
              break;
            }
            const pipsRest = rest.reduce((a, h) => a + T(h).pips, 0);
            bestRest = Math.min(bestRest, pipsRest);
            worstOk = worstOk && heuristicBlock(pipsRest, rest.length, [k.counts[k.j2], k.counts[k.j4]]).ok;
          }
          if (allBlock) {
            const hb = heuristicBlock(bestRest, handAfter.length - 1, [k.counts[k.j2], k.counts[k.j4]]);
            add(`forces a block next turn with ${bestRest} in ${handAfter.length - 1} (note 50, E-6.5): ${hb.reason}`, hb.ok ? 6 : -22);
          }
        }
      }
      if (handAfter.length >= 2) {
        let worst = 0, worstWhy = "";
        for (const c of handAfter) {
          const ct = T(c);
          if (ct.double) continue;
          for (const sNum of [ct.hi, ct.lo]) {
            const so = whoOwns(k, k.numberOwner[sNum]);
            const strongS = (so === "me" || so === "partner") && unknownWith(sNum).length <= 2;
            if (!strongS) continue;
            const o = other(c, sNum);
            const escape2 = handAfter.some((h) => h !== c && has(h, o));
            if (escape2) continue;
            const rest = handAfter.filter((h) => h !== c);
            const avg = rest.reduce((a, h) => a + T(h).pips, 0) / rest.length;
            if (avg > 7 && avg - 7 > worst) {
              worst = avg - 7;
              worstWhy = `${c} would force a block at ${sNum} holding ~${avg.toFixed(0)}/tile`;
            }
          }
        }
        const oppLowVoid = [k.j2, k.j4].some((s2) => [0, 1, 2].some((n) => k.voids[s2][n]));
        const myMin = Math.min(...handAfter.map((h) => T(h).pips));
        const lowerGone = !k.unknown.some((u) => T(u).pips < myMin);
        if (worst > 0 && !lowerGone) add(`forced-block risk: ${worstWhy} (note 50, E-6.13)`, -Math.min(10, worst * 1.5) * (oppLowVoid ? 0.5 : 1));
      }
      if (!isD && e === y && (k.voids[k.j4][e] || k.likelihood[k.j4][e] < 0.4)) add("throw to a number J4 lacks: pass him from below (E-6.21)", 6);
      for (const f of newEndsArr) {
        if (f === e) continue;
        const fijoF = unknownWith(f).length === 0 && handAfter.some((h) => has(h, f));
        if (!fijoF) continue;
        for (const closer of handAfter.filter((h) => has(h, f) && !T(h).double)) {
          const mNum = other(closer, f);
          if (mNum === e) continue;
          const wanted = idOf(e, mNum);
          const q = pHoldsTile(k, k.j2, wanted, gone);
          const rest = handAfter.filter((h) => h !== closer);
          const avgRest = rest.reduce((a, h) => a + T(h).pips, 0) / Math.max(1, rest.length);
          if (q > 0 && avgRest <= 4) add(`send for J2's ${wanted} to block at ${f} (\xA76.11, E-6.23/6.24)`, 4 + 10 * Math.min(0.6, q));
        }
      }
      const myAvg = handAfter.reduce((a, h) => a + T(h).pips, 0) / Math.max(1, handAfter.length);
      if (myAvg <= 2 && k.counts[k.j2] >= 3 && e !== y) {
        const link = idOf(e, y);
        const blocksAfter = unknownWith(y).filter((u) => u !== link).length === 0 || unknownWith(e).filter((u) => u !== link).length === 0;
        if (pHoldsTile(k, k.j2, link, gone) > 0 && blocksAfter) add("invite J2 into a block he loses at the count (\xA76.12, E-6.26)", 5);
      }
      if (!isD && !k.seenBy[k.j4].has(e) && k.playedCount[e] > 0 && pHasAny(k, k.j2, [e]) < 0.3 && pHasAny(k, k.partner, [e]) < 0.4 && !k.pausedOn.some((pz) => pz.seat === k.partner && pz.number === e)) {
        add("it would reach J4 for the first time (hasta la pata, E-6.25)", -5);
      }
    }
    if (!isD && k.partnerOpened.includes(x)) add("kill the number the partner opened: he declined a block (E-6.7)", 5);
    if (!isD && k.leadTile && pairOf(k.leaderSeat ?? 0) === pairOf(k.seat) && has(k.leadTile, e)) {
      const j2Kill = k.events.find((ev) => ev.kind === "play" && ev.seat === k.j2 && ev.matched != null && has(k.leadTile, ev.matched) && ev.thinkMs != null);
      if (j2Kill && j2Kill.kind === "play" && j2Kill.thinkMs <= 1e3) add("J2 killed the lead instantly: repeat it (E-4.26)", 4);
      if (j2Kill && j2Kill.kind === "play" && j2Kill.thinkMs >= 4e3) add("J2 paused to kill the lead: he's backed, use the secondary play (E-4.26)", -3);
    }
    blockTerm(ctx, m, e, y, handAfter, add);
    if (phase === "SECOND" && k.leaderSeat != null && pairOf(k.leaderSeat) === pairOf(k.seat)) {
      const rank = [[/heavy tile first|play your data/, 1.2], [/partner's number|own lead|throw with J3/, 1.12], [/gives the opponent's number/, 1.06], [/kill the opponent's number|kill J2's/, 1], [/both ends|can't re-enter/, 0.95], [/new fallo/, 0.9]];
      for (const r of R) for (const [re, f] of rank) if (re.test(r.criterion)) {
        r.delta = Math.round(r.delta * f * 10) / 10;
        break;
      }
    }
    return finalize(m, R);
  }
  function blockTerm(ctx, m, e, y, handAfter, add) {
    const { k, v } = ctx;
    const relevant = /* @__PURE__ */ new Set([...TILES_WITH[e], ...TILES_WITH[y]]);
    const outstanding = [...relevant].filter((id) => !k.played.has(id) && id !== m.tile);
    if (outstanding.some((id) => handAfter.includes(id))) return;
    const certain = outstanding.length === 0;
    if (certain) {
      const mine = handAfter.reduce((a, h) => a + T(h).pips, 0);
      const pool = k.unknown.filter((u) => u !== m.tile).map((u) => T(u).pips).sort((a, b) => a - b);
      const safe = [k.j2, k.partner, k.j4].every((s2) => {
        if (s2 === k.partner) return true;
        const c = k.counts[s2];
        return pool.slice(0, c).reduce((a, b) => a + b, 0) > mine;
      });
      if (safe) add("safe block: every opponent must count more than you (E-6.2)", 45);
    }
    if (ctx.samples.length) {
      let wSum = 0, wBlock = 0, ev = 0;
      for (const s of ctx.samples) {
        wSum += s.weight;
        const blocked = outstanding.every((id) => s.undealt.includes(id));
        if (!blocked) continue;
        wBlock += s.weight;
        const hands = s.hands.map((h, i) => i === k.seat ? handAfter : h);
        ev += s.weight * matchUtility(blockOutcome(hands, k.seat, v.config.scoring), v);
      }
      if (wBlock === 0) return;
      const pBlock = wBlock / wSum;
      const evBlock = ev / wBlock;
      if (pBlock > 0.05) add(`block risk/chance p=${pBlock.toFixed(2)}, EV ${evBlock.toFixed(0)} pts (Ch.2 tranque)`, pBlock * Math.max(-60, Math.min(80, evBlock)) * 0.6);
      return;
    }
    if (certain) {
      const h = heuristicBlock(handAfter.reduce((s, id) => s + T(id).pips, 0), handAfter.length, [k.counts[k.j2], k.counts[k.j4]]);
      const mp = pairOf(v.seat), target = v.config.targetPoints;
      const farBehind = target - v.scores[1 - mp] <= 25 && v.scores[mp] < 20;
      const ok = h.ok || farBehind && h.avg <= 7;
      add(`block by Table 2.1 thresholds: ${h.reason}${farBehind && !h.ok && ok ? " (accepted: far behind)" : ""}`, ok ? 20 : -25);
    }
  }
  function finalize(move, reasons) {
    const score = Math.round(reasons.reduce((s, r) => s + r.delta, 0) * 10) / 10;
    reasons.sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta));
    return { move, score, reasons };
  }
  function dedupe(moves, ends) {
    if (!ends) return moves;
    const seen = /* @__PURE__ */ new Set();
    return moves.filter((m) => {
      const end = ends[m.side];
      const key = `${m.tile}|${end.value}|${end.owner}|${end.turn}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
  function suggestDelay(ctx, scored) {
    const { k } = ctx;
    if (scored.length < 2) return 0;
    if (k.counts[k.partner] <= 1) return 0;
    const best = scored[0];
    const similar = scored[1].score > best.score - 3;
    const end = ctx.v.ends[best.move.side];
    const killed = end.value;
    if (k.voids[k.partner][killed]) return 0;
    const backing = k.myCount[killed] - (has(best.move.tile, killed) ? 1 : 0);
    const ownerKilled = numberOwner(k, killed, end);
    if (backing > 3) return 6500;
    if (best.reasons.some((r) => /double on the pair's strong number|double on the B that passed/.test(r.criterion))) return 6500;
    if (similar && scored[1].move.side !== best.move.side && numberOwner(k, ctx.v.ends[scored[1].move.side].value) === "partner") return 6500;
    if (isOpp(ownerKilled) && backing >= 2) return 3e3;
    if (similar) return 3e3;
    return 0;
  }
  var ROLLOUT_WEIGHT = 0.4;
  function rolloutRank(ctx, scored, rng, n) {
    const top = scored.slice(0, Math.min(4, scored.length));
    const deals = [];
    for (let i = 0; i < n; i++) deals.push(sampleDeal(ctx.k, rng));
    for (const cand of top) {
      let tot = 0, wsum = 0;
      for (let i = 0; i < deals.length; i++) {
        const st = stateFromSample(ctx.v, deals[i]);
        applyHandMut(st, { type: "play", seat: ctx.v.seat, tile: cand.move.tile, side: cand.move.side ?? void 0 }, ctx.v.config);
        const r = matchUtility(playout(st, ctx.v, new Rng(rng.int(2 ** 31))), ctx.v);
        tot += deals[i].weight * r;
        wsum += deals[i].weight;
      }
      cand.rollout = tot / Math.max(1e-9, wsum);
      cand.reasons = [{ criterion: `Monte Carlo rollouts: mean ${cand.rollout.toFixed(1)} pts`, delta: cand.rollout }, ...cand.reasons];
    }
    top.sort((a, b) => b.score + ROLLOUT_WEIGHT * b.rollout - (a.score + ROLLOUT_WEIGHT * a.rollout));
    return [...top, ...scored.slice(top.length)];
  }
  function stateFromSample(v, s) {
    return {
      handNo: v.handNo,
      dealt: s.hands.map((h) => [...h]),
      hands: s.hands.map((h) => [...h]),
      undealt: [...s.undealt],
      leadingPair: v.leadingPair,
      firstSpeaker: v.firstSpeaker,
      leaderSeat: v.leaderSeat,
      phase: "playing",
      toAct: v.toAct,
      turn: v.turn,
      ends: structuredClone(v.ends),
      events: structuredClone(v.events),
      result: null,
      redeals: 0
    };
  }
  function playout(st, me, rng) {
    let guard = 0;
    while (st.phase === "playing" && guard++ < 200) {
      const seat = st.toAct;
      const pv = viewOfHandState(st, seat, me.config, me.scores);
      const moves = legalMoves(pv.hand, pv.ends);
      if (moves.length === 0) {
        applyHandMut(st, { type: "pass", seat }, me.config);
        continue;
      }
      let mv;
      if (moves.length === 1) mv = moves[0];
      else {
        const k = analyze(pv);
        const c = buildCtx(pv, k, "medium", rng, { samples: 0 });
        const sc = dedupe(moves, pv.ends).map((m) => scoreMove(c, m));
        sc.sort((a, b) => b.score - a.score);
        mv = sc[0].move;
      }
      applyHandMut(st, { type: "play", seat, tile: mv.tile, side: mv.side ?? void 0 }, me.config);
    }
    const r = st.result;
    if (r.winnerPair == null) return 0;
    return r.winnerPair === pairOf(me.seat) ? r.points : -r.points;
  }
  function forgetPasses(v) {
    return { ...v, events: v.events.filter((e) => e.kind !== "pass" || v.turn - e.turn <= 4) };
  }
  function hashView(v) {
    let h = 2166136261 ^ v.seat;
    for (const e of v.events) {
      const s = e.kind === "play" ? e.tile + (e.side ?? "") : e.kind;
      for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
    }
    for (const t of v.hand) for (let i = 0; i < t.length; i++) h = Math.imul(h ^ t.charCodeAt(i), 16777619);
    return h >>> 0;
  }

  // src/sim.ts
  function botStep(m, levels, rng, bot = {}) {
    if (m.hand.phase === "over") return applyMut(m, { type: "nextHand" });
    const seat = m.hand.toAct;
    const d = decide(viewOf(m, seat), { ...bot, level: levels[seat], seed: rng.int(2 ** 31) });
    return applyMut(m, d.action);
  }
  function playMatch(opts = {}) {
    const levels = opts.levels ?? ["high", "high", "high", "high"];
    const m = newMatch(opts);
    const rng = new Rng((opts.seed ?? 1) ^ 2654435769);
    let guard = 0;
    while (m.status === "playing" && guard++ < 1e5) {
      if (opts.singleHand && m.hand.phase === "over") break;
      botStep(m, levels, rng, opts.bot);
    }
    return m;
  }

  // src/stats.ts
  function pairStats(records, pair) {
    const s = { matches: 0, won: 0, lost: 0, differential: 0, handsWon: 0, handsLost: 0, zeroPointHands: 0, pollonasWon: 0, pollonasLost: 0, viajerasWon: 0, viajerasLost: 0, pointsFor: 0, pointsAgainst: 0, effectiveness: 0 };
    for (const { state: m } of records) {
      if (m.status !== "over") continue;
      s.matches++;
      const won = m.winnerPair === pair;
      if (won) s.won++;
      else s.lost++;
      s.differential += m.scores[pair] - m.scores[1 - pair];
      s.pointsFor += m.scores[pair];
      s.pointsAgainst += m.scores[1 - pair];
      if (m.pollona) won ? s.pollonasWon++ : s.pollonasLost++;
      if (m.viajera) won ? s.viajerasWon++ : s.viajerasLost++;
      for (const h of m.history) {
        if (h.winnerPair == null || h.points === 0) s.zeroPointHands++;
        if (h.winnerPair === pair) s.handsWon++;
        else if (h.winnerPair != null) s.handsLost++;
      }
    }
    s.effectiveness = s.matches ? s.won / s.matches : 0;
    return s;
  }
  function statsByDate(records, pair) {
    const by = {};
    for (const r of records) (by[(r.date ?? "undated").slice(0, 10)] ||= []).push(r);
    return Object.fromEntries(Object.entries(by).map(([d, rs]) => [d, pairStats(rs, pair)]));
  }

  // src/protocol.ts
  var PROTOCOL_VERSION = 1;
  function handle(req) {
    const id = req.id;
    try {
      const out = dispatch2(req);
      return { ...id !== void 0 ? { id } : {}, ok: true, ...out };
    } catch (e) {
      const err = e;
      return { ...id !== void 0 ? { id } : {}, ok: false, error: { code: err.code ?? (e instanceof RuleError ? e.code : "ERROR"), message: err.message } };
    }
  }
  function viewFrom(req) {
    if (req.view) return req.view;
    if (req.scenario) return scenarioView(req.scenario);
    const m = req.state;
    if (!m) throw Object.assign(new Error("state, view or scenario required"), { code: "BAD_REQUEST" });
    return viewOf(m, req.seat ?? m.hand.toAct ?? 0);
  }
  function dispatch2(req) {
    switch (req.cmd) {
      case "version":
        return { protocol: PROTOCOL_VERSION, engine: "cuban-domino-engine 0.1.0" };
      case "newMatch":
        return { state: newMatch(req) };
      case "apply": {
        const before = req.state.hand.events.length;
        const state = apply(req.state, req.action);
        const newEvents = state.hand.handNo === req.state.hand.handNo ? state.hand.events.slice(before) : state.hand.events;
        return { state, newEvents, result: state.hand.result };
      }
      case "view":
        return { view: viewOf(req.state, req.seat) };
      case "legalMoves": {
        const m = req.state;
        const seat = req.seat ?? m.hand.toAct;
        return { seat, moves: m.hand.phase === "playing" && seat === m.hand.toAct ? legalMoves(m.hand.hands[seat], m.hand.ends) : [] };
      }
      case "botMove": {
        const v = viewFrom(req);
        const d = decide(v, { level: req.level ?? "high", seed: req.seed, tempo: req.tempo, samples: req.samples, rollouts: req.rollouts });
        return { ...d, candidates: req.verbose ? d.candidates : d.candidates.slice(0, 5) };
      }
      case "botStep": {
        const m = req.state;
        if (m.hand.phase === "over") return { action: { type: "nextHand" }, state: apply(m, { type: "nextHand" }) };
        const seat = m.hand.toAct;
        const levels = req.levels ?? ["high", "high", "high", "high"];
        const d = decide(viewOf(m, seat), { level: levels[seat], seed: req.seed, tempo: req.tempo });
        return { action: d.action, reasons: d.reasons, suggestedDelayMs: d.suggestedDelayMs, state: apply(m, d.action) };
      }
      case "analyze": {
        const v = viewFrom(req);
        const k = analyze(v);
        const others = [0, 1, 2, 3].filter((s) => s !== v.seat);
        return {
          profile: profile(v.hand),
          voids: k.voids.map((row) => NUMBERS.filter((n) => row[n])),
          numberOwner: k.numberOwner,
          tableTotal: k.tableTotal,
          pHasNumber: Object.fromEntries(others.map((s) => [s, NUMBERS.map((n) => Math.round(pHasAny(k, s, [n]) * 1e3) / 1e3)]))
        };
      }
      case "leadOptions":
        return { options: leadOptions(req.hand) };
      case "probabilities":
        return {
          table81: table81().map((r) => ({ ...r, hands: r.hands.toString() })),
          book: BOOK_TABLE_81
        };
      case "block":
        return { tableMinMax: [1, 2, 3, 4, 5].map((n) => ({ n, ...tableMinMax(n) })), heuristic: req.myPips != null ? heuristicBlock(req.myPips, req.myTiles, req.oppTiles) : void 0 };
      case "stats":
        return { stats: pairStats(req.records, req.pair ?? 0), byDate: statsByDate(req.records, req.pair ?? 0) };
      case "scenario":
        return { view: scenarioView(req.scenario) };
      case "parsePlays":
        return { plays: parsePlays(req.text) };
      case "formatHand":
        return { text: formatHand(req.state.hand, req.observer ?? 0) };
      default:
        throw Object.assign(new Error(`Unknown cmd "${req.cmd}"`), { code: "UNKNOWN_CMD" });
    }
  }

  // src/synthetic.ts
  function syntheticView(spec) {
    const me = 0;
    const seatOf = (rel) => absSeat(me, rel);
    const hand = spec.hand.map((t) => T(t).id);
    const counts = [hand.length, ...spec.counts];
    const need = counts.map((c) => 10 - c);
    const used = new Set(hand);
    const out = new Set((spec.out ?? []).map((t) => T(t).id));
    const playedTiles = [];
    const take = (seat, tile) => {
      if (used.has(tile) || out.has(tile)) throw new Error(`synthetic: ${tile} can't be played`);
      used.add(tile);
      playedTiles.push({ seat, tile });
      need[seat]--;
    };
    const recent = (spec.recent ?? []).map((r) => {
      const m = r.trim().match(/^(J[1-4])\s+([0-9B])-([0-9B])$/i);
      const num = (c) => c.toUpperCase() === "B" ? 0 : Number(c);
      return { seat: seatOf(m[1]), matched: num(m[2]), exposed: num(m[3]), tile: T(`${m[2]}-${m[3]}`).id };
    });
    for (const r of recent) {
      used.add(r.tile);
      need[r.seat]--;
    }
    for (const p of spec.playedBy ?? []) take(seatOf(p.rel), T(p.tile).id);
    const pickSeat = () => {
      let best = -1;
      for (let s = 0; s < 4; s++) if (need[s] > 0 && (best < 0 || need[s] > need[best])) best = s;
      return best;
    };
    const fixed = { ...spec.playedOf ?? {} };
    for (const f of spec.fijo ?? []) fixed[f] = 10 - hand.filter((h) => has(h, f)).length;
    const onTable = (n) => [...used].filter((t) => !hand.includes(t) && has(t, n)).length;
    for (const [nStr, cnt] of Object.entries(fixed)) {
      const n = Number(nStr);
      for (const t of TILES_WITH[n]) {
        if (onTable(n) >= cnt) break;
        if (used.has(t) || out.has(t)) continue;
        const o = other(t, n);
        if (o !== n && fixed[o] != null && onTable(o) >= fixed[o]) continue;
        const s = pickSeat();
        if (s < 0) break;
        take(s, t);
      }
    }
    const mentioned = /* @__PURE__ */ new Set([spec.ends[0].value, spec.ends[1].value, ...Object.keys(fixed).map(Number)]);
    for (const h of hand) {
      mentioned.add(T(h).hi);
      mentioned.add(T(h).lo);
    }
    for (const p of spec.passes ?? []) {
      mentioned.add(p.on[0]);
      mentioned.add(p.on[1]);
    }
    for (const o of out) {
      mentioned.add(T(o).hi);
      mentioned.add(T(o).lo);
    }
    const fillOrder = [...ALL_IDS].sort((a, b) => {
      const ma = (mentioned.has(T(a).hi) ? 1 : 0) + (mentioned.has(T(a).lo) ? 1 : 0);
      const mb = (mentioned.has(T(b).hi) ? 1 : 0) + (mentioned.has(T(b).lo) ? 1 : 0);
      return ma - mb || T(b).pips - T(a).pips;
    });
    for (const t of fillOrder) {
      if (need.every((x) => x <= 0)) break;
      if (used.has(t) || out.has(t)) continue;
      if ([T(t).hi, T(t).lo].some((n) => fixed[n] != null && onTable(n) >= fixed[n])) continue;
      const s = pickSeat();
      if (s < 0) break;
      take(s, t);
    }
    if (need.some((x) => x !== 0)) throw new Error("synthetic: could not fill the table consistently");
    const owners = {};
    for (const [n, rel] of Object.entries(spec.owners ?? {})) owners[Number(n)] = seatOf(rel);
    for (const i of [0, 1]) if (owners[spec.ends[i].value] == null) owners[spec.ends[i].value] = seatOf(spec.ends[i].by);
    const events = [];
    let turn = 0;
    if (spec.leader) {
      const ls = seatOf(spec.leader);
      const li = playedTiles.findIndex((p) => p.seat === ls);
      if (li >= 0) {
        const lead = playedTiles.splice(li, 1)[0];
        events.push({ kind: "play", seat: ls, tile: lead.tile, side: null, matched: null, exposed: T(lead.tile).hi, otherEnd: null, turn: turn++ });
      }
    }
    const firstFor = /* @__PURE__ */ new Map();
    for (const [nStr, seat] of Object.entries(owners)) {
      const n = Number(nStr);
      let idx = playedTiles.findIndex((p, i) => p.seat === seat && has(p.tile, n) && ![...firstFor.values()].includes(i));
      if (idx < 0) {
        const j = playedTiles.findIndex((p, i) => has(p.tile, n) && ![...firstFor.values()].includes(i));
        const k2 = playedTiles.findIndex((p, i) => p.seat === seat && ![...firstFor.values()].includes(i));
        if (j >= 0 && k2 >= 0) {
          const sj = playedTiles[j].seat;
          playedTiles[j].seat = seat;
          playedTiles[k2].seat = sj;
          idx = j;
        }
      }
      if (idx >= 0) firstFor.set(n, idx);
    }
    for (const [n, idx] of firstFor) {
      const p = playedTiles[idx];
      events.push({ kind: "play", seat: p.seat, tile: p.tile, side: "L", matched: other(p.tile, n), exposed: n, otherEnd: null, turn: turn++ });
    }
    const usedIdx = new Set(firstFor.values());
    playedTiles.forEach((p, i) => {
      if (usedIdx.has(i)) return;
      const t = T(p.tile);
      events.push({ kind: "play", seat: p.seat, tile: p.tile, side: "L", matched: t.hi, exposed: t.lo, otherEnd: null, turn: turn++ });
    });
    for (const ps of spec.passes ?? []) events.push({ kind: "pass", seat: seatOf(ps.rel), ends: ps.on, turn: turn++ });
    const endOwner = (i) => seatOf(spec.ends[i].by);
    const ends = {
      L: { value: spec.ends[0].value, seat: endOwner(0), owner: endOwner(0), turn, tile: "" },
      R: { value: spec.ends[1].value, seat: endOwner(1), owner: endOwner(1), turn, tile: "" }
    };
    const sides = [];
    const cur = { L: spec.ends[0].value, R: spec.ends[1].value };
    const curBy = { L: seatOf(spec.ends[0].by), R: seatOf(spec.ends[1].by) };
    for (let i = recent.length - 1; i >= 0; i--) {
      const r = recent[i];
      const cand = ["L", "R"].filter((sd) => cur[sd] === r.exposed);
      const side = cand.find((sd) => curBy[sd] === r.seat) ?? cand[0] ?? "R";
      sides[i] = side;
      cur[side] = r.matched;
      curBy[side] = -1;
    }
    ends.L = { ...ends.L, value: cur.L };
    ends.R = { ...ends.R, value: cur.R };
    recent.forEach((r, i) => {
      const side = sides[i];
      const otherEnd = side === "L" ? ends.R.value : ends.L.value;
      events.push({ kind: "play", seat: r.seat, tile: r.tile, side, matched: r.matched, exposed: r.exposed, otherEnd, turn, ...spec.thinkMs?.[`${r.seat}`] != null ? { thinkMs: spec.thinkMs[`${r.seat}`] } : {} });
      ends[side] = { value: r.exposed, seat: r.seat, owner: T(r.tile).double ? ends[side].owner : r.seat, turn, tile: r.tile };
      turn++;
    });
    for (const i of [0, 1]) {
      const sd = i === 0 ? "L" : "R";
      ends[sd].owner = seatOf(spec.ends[i].by);
    }
    for (const ps of spec.passesAfter ?? []) events.push({ kind: "pass", seat: seatOf(ps.rel), ends: ps.on, turn: turn++ });
    const leaderSeat = spec.leader ? seatOf(spec.leader) : playedTiles.length ? playedTiles[0].seat : 0;
    return {
      seat: me,
      hand,
      config: withDefaults(spec.config),
      scores: spec.scores ?? [0, 0],
      handNo: 1,
      leadingPair: pairOf(leaderSeat),
      firstSpeaker: leaderSeat,
      leaderSeat,
      phase: "playing",
      toAct: me,
      turn,
      ends,
      events,
      tileCounts: counts
    };
  }
  return __toCommonJS(index_exports);
})();

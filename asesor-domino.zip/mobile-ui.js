// mobile-ui.js — the advisor on a phone (Firefox for Android, Ludoteka's site held sideways).
// A floating square button by the hand shows the recommended tile and the end it goes on; a small AUTO switch sits
// next to it; a tap on the button slides in a details card. Everything lives in one Shadow DOM so Ludoteka's styles and
// ours cannot touch each other. content.js sends the advice (CDA_MOBILE.update); this file only draws it.
// Loaded before content.js in the same content-script world. The Chrome build never turns it on (CDA_BUILD).
(function () {
  "use strict";

  const BUILD = window.CDA_BUILD || "chrome";
  const ACCENT = "#F2B544", BG = "#1C1F24", TABLE = "#2E6B3F";
  // One block (the user's choice, 2026-10-09): the advice on the left, the AUTO switch joined to its right side,
  // inside one gold border. BTN = block height and the advice part's width, TOG = the AUTO part's width.
  const BTN = 74, TOG = 40, EDGE = 4;
  const WRAP_W = BTN + TOG + 2;
  const onGamePage = /\/partida/.test(location.pathname);
  // the lobby (www.ludoteka.com/jugar): the advisor shows there too, faded (the user's choice, 2026-10-09); while the
  // device is not activated the padlock shows there at full strength, so a new player can activate before a table
  const onLobby = /^\/jugar\/?$/.test(location.pathname);

  // ── Texts (the panel is in Spanish) ─────────────────────────────────────
  const T = {
    end: (n) => `en el ${n}`,
    either: "cualquier punta",
    lead: "salida",
    pass: "paso",
    thinking: "…",
    free: "juega",
    playEnd: (t, n) => `Juega ${t} en el ${n}`,
    playEither: (t) => `Juega ${t} en cualquier punta`,
    playLead: (t) => `Sal con ${t}`,
    playFree: (t) => `Juega ${t}`,
    ariaEnd: (t, n) => `Asesor de dominó: juega ${t} en la punta del ${n}. Toca para ver detalles.`,
    ariaEither: (t, n) => `Asesor de dominó: juega ${t} en cualquier punta; las dos muestran el ${n}. Toca para ver detalles.`,
    ariaLead: (t) => `Asesor de dominó: sal con ${t}. La salida la juegas tú. Toca para ver detalles.`,
    ariaFree: (t) => `Asesor de dominó: juega ${t}. Toca para ver detalles.`,
    ariaPass: "Asesor de dominó: no tienes ficha para jugar, pasas.",
    ariaThinking: "Asesor de dominó: pensando la jugada.",
    ariaWait: (last) => `Asesor de dominó: no es tu turno.${last ? " Último consejo: " + last + "." : ""} Toca para ver detalles.`,
    ariaIdle: "Asesor de dominó: esperando la mano. Toca para ver detalles.",
    autoOn: "El piloto automático está encendido. Toca para apagarlo.",
    autoOff: "El piloto automático está apagado. Toca para encenderlo.",
    recommended: "RECOMENDADA",
    lastAdvice: "ÚLTIMO CONSEJO",
    thinkingHead: "PENSANDO…",
    passHead: "PASO",
    passText: "No tienes ficha para jugar",
    waitText: "Esperando tu turno",
    why: "POR QUÉ",
    nextBest: "Siguiente mejor",
    onlyMove: "No hay otra jugada",
    fallback: "Respaldo: la ficha más pesada que se puede jugar",
    leadNote: "La salida nunca se juega sola: tócala tú.",
    autoBtn: (on) => `Piloto automático: ${on ? "Sí" : "No"}`,
    close: "Cerrar",
    engine: (e) => `Motor en juego: ${ENGINE_NAMES[e] || e || "—"}`,
    engineHead: "MOTOR",
    recommendedEngine: "Recomendado",
    engineNext: "La Parejita empieza en la próxima mano.",
    engineNow: "Cambia desde esta jugada.",
    rotate: "Gira el teléfono para ver el asesor",
    autoFailed: "Falló el juego automático: juega a mano",
    on: "SÍ", off: "NO",
    lockLabel: "activar",
    ariaLocked: "Asesor de dominó bloqueado en este dispositivo. Toca para activarlo.",
    actHead: "ACTIVACIÓN",
    actTitle: "Activa el asesor en este dispositivo",
    actText: "Envía este código a quien te dio el asesor. Te mandará una clave: pégala aquí.",
    copy: "Copiar código",
    copied: "Código copiado",
    keyPlaceholder: "Pega aquí la clave (empieza por CDA1.)",
    activate: "Activar",
    badKey: "Esa clave no es para este dispositivo. Revisa que esté completa.",
    activated: "Asesor activado",
    revokedTitle: "Este dispositivo fue desactivado",
    revokedText: "Habla con quien te dio el asesor. Si te vuelve a activar, se desbloquea solo al abrir Ludoteka.",
  };

  // ── When the mobile UI is on ────────────────────────────────────────────
  // The engine settings (storage "cdaEngineMode", read by content.js), La Parejita first: the default.
  const ENGINE_NAMES = { "v0.5": "El Clásico", "v0.5s": "El Trancador", "v0.9": "El Anticuado" };
  const ENGINE_MODES = [["alternate-5s", "La Parejita"], ["v0.5s", "El Trancador"], ["v0.5", "El Clásico"], ["v0.9", "El Anticuado"]];

  const coarse = () => { try { return matchMedia("(pointer: coarse)").matches; } catch (e) { return false; } };
  const isActive = () => BUILD === "firefox" && (coarse() || window.innerWidth < 900);
  let active = isActive();

  // AUTO is off at every page load (the user turns it on by tapping it). Issued before content.js reads the switch.
  if (active && onGamePage) {
    try { chrome.storage.local.set({ botEnabled: false, botOffReason: { why: "page loaded (mobile)", at: Date.now() } }); } catch (e) {}
  }

  // ── Tile drawing: pips, no numbers, lying sideways; t[0] is the left half ──
  // Same look as the Chrome panel (panel.js PIP_COLORS / PIP_CELLS): white tile, a dot colour per number (1 yellow,
  // 2 black, 3 blue, 4 red, 5 green, 6 cyan, 7 reddish brown, 8 orange, 9 purple), 6 and 7 laid out like the game's
  // horizontal tiles (two rows of three, the 7 with a centre dot), and a shadow inside each dot so it looks like a hole.
  const PIP_COLORS = [null, "#e8b00c", "#1a1a1a", "#3a6cc6", "#d22b2b", "#1f6b2c", "#1aa6b5", "#7a2418", "#e8742a", "#6a2fb4"];
  const PIPS = { 0: [], 1: [4], 2: [0, 8], 3: [0, 4, 8], 4: [0, 2, 6, 8], 5: [0, 2, 4, 6, 8],
    6: [0, 1, 2, 6, 7, 8], 7: [0, 1, 2, 4, 6, 7, 8], 8: [0, 1, 2, 3, 5, 6, 7, 8], 9: [0, 1, 2, 3, 4, 5, 6, 7, 8] };
  let svgSeq = 0;
  function tileSVG(t, s) {
    const w = 54 * s, h = 27 * s, hole = "cdaHole" + ++svgSeq;
    let dots = "";
    if (t) {
      [t[0], t[1]].forEach((n, half) => {
        for (const c of PIPS[n] || []) {
          const cx = half * 27 * s + (6.5 + 7 * (c % 3)) * s, cy = (6.5 + 7 * Math.floor(c / 3)) * s, r = 2.5 * s;
          dots += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${PIP_COLORS[n]}"/><circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#${hole})"/>`;
        }
      });
    }
    return `<svg class="tile" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" aria-hidden="true">` +
      `<defs><linearGradient id="${hole}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity=".55"/>` +
      `<stop offset=".5" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#fff" stop-opacity=".25"/></linearGradient></defs>` +
      `<rect x=".5" y=".5" width="${w - 1}" height="${h - 1}" rx="${3 * s}" fill="#fbfbf9" stroke="#c9c9c4"/>` +
      `<rect x="${27 * s - 0.5}" y="${2 * s}" width="1" height="${h - 4 * s}" fill="#8a8a86"/>${dots}</svg>`;
  }

  // the padlock shown on the button while the device is not activated
  const LOCK_SVG = `<svg class="tile" width="54" height="27" viewBox="0 0 54 27" aria-hidden="true">
    <path d="M21 12 V8.5 a6 6 0 0 1 12 0 V12" fill="none" stroke="${ACCENT}" stroke-width="2.4"/>
    <rect x="18" y="11.5" width="18" height="14" rx="2.5" fill="${ACCENT}"/><circle cx="27" cy="17.5" r="2" fill="${BG}"/>
    <rect x="26.2" y="18" width="1.6" height="4.2" fill="${BG}"/></svg>`;

  // ── DOM ─────────────────────────────────────────────────────────────────
  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    .hidden { display: none !important; }
    .wrap { position: fixed; left: 0; top: 0; width: ${WRAP_W}px; height: ${BTN}px; pointer-events: none; }
    .unit { position: absolute; inset: 0; display: flex; border-radius: 10px; background: ${BG}; border: 2px solid ${ACCENT};
      box-shadow: 0 6px 16px rgba(0,0,0,.5); pointer-events: auto; touch-action: none; user-select: none; -webkit-user-select: none;
      cursor: grab; -webkit-tap-highlight-color: transparent; }
    .unit.auto { animation: pulse 2.4s ease-in-out infinite; }
    @keyframes pulse { 0%,100% { box-shadow: 0 6px 16px rgba(0,0,0,.5), 0 0 0 0 rgba(242,181,68,0); }
                       50% { box-shadow: 0 6px 16px rgba(0,0,0,.5), 0 0 0 5px rgba(242,181,68,.35); } }
    .btn { width: ${BTN - 2}px; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center;
      gap: 7px; padding: 4px 3px; outline: none; transition: opacity .15s; border-radius: 8px 0 0 8px; }
    .btn:focus-visible, .tog:focus-visible { box-shadow: inset 0 0 0 2px #fff; }
    .btn.off-turn { opacity: .6; }
    .unit.dormant { opacity: .45; }                 /* lobby, or no game started yet at the table */
    .unit.dormant .btn.off-turn { opacity: 1; }
    .btn .tile { display: block; flex: none; }
    .btn .tile.dim { opacity: .4; }
    .lbl { color: ${ACCENT}; font-size: 12px; font-weight: 700; line-height: 1.05; text-align: center; max-width: 100%; }
    .dot { position: absolute; top: -7px; right: -7px; width: 12px; height: 12px; border-radius: 50%;
      background: ${ACCENT}; border: 2px solid ${TABLE}; box-sizing: content-box; pointer-events: none; }
    .tog { width: ${TOG}px; height: 100%; border-left: 1px solid #3A3F46; outline: none; border-radius: 0 8px 8px 0;
      display: flex; align-items: center; justify-content: center; }
    /* AUTO is a toggle switch (the user's choice, 2026-10-09): chrome hex nut, short chrome lever with a plastic cap.
       Off = lever down, red cap and ring; on = lever up, green cap and glowing ring. No text. */
    .lever { transform-origin: 20px 35px; transform: scaleY(-1); transition: transform .14s cubic-bezier(.5,1.6,.5,1); }
    .tog.on .lever { transform: scaleY(1); }
    .ring { fill: none; stroke: #E0402F; stroke-width: 2.2; transition: stroke .12s; }
    .tog.on .ring { stroke: #2DB862; filter: drop-shadow(0 0 2px rgba(46,204,113,.9)); }
    .capc { fill: url(#cdaCapR); }
    .tog.on .capc { fill: url(#cdaCapG); }
    .scrim { position: fixed; inset: 0; pointer-events: auto; background: transparent; }
    .card { position: fixed; top: 8px; right: 0; width: 260px; height: auto; max-height: calc(100% - 16px); background: ${BG}; color: #EDEFF2;
      border-radius: 14px 0 0 14px; box-shadow: -6px 0 18px rgba(0,0,0,.45); pointer-events: auto;
      transform: translateX(105%); transition: transform .22s ease-out; display: flex; flex-direction: column;
      padding: 14px 14px 12px; gap: 10px; overflow-y: auto; touch-action: pan-y; }
    .card.open { transform: translateX(0); }
    .head { display: flex; align-items: center; gap: 12px; }
    .ring { border-radius: 6px; outline: 2px solid ${ACCENT}; outline-offset: 3px; line-height: 0; flex: none; }
    .ring.empty { outline-color: #5A5F67; }
    .kicker { font-size: 10px; letter-spacing: .12em; color: ${ACCENT}; font-weight: 700; }
    .title { font-size: 16px; font-weight: 700; line-height: 1.2; margin-top: 2px; }
    .ctx { font-size: 12px; color: #C9CDD3; line-height: 1.3; }
    .sec { font-size: 10px; letter-spacing: .12em; color: #8A9099; font-weight: 700; margin-top: 2px; }
    ol { margin: 0; padding: 0 0 0 18px; display: flex; flex-direction: column; gap: 6px; }
    li { font-size: 13px; line-height: 1.3; }
    li .ref { display: block; font-size: 11px; color: #8A9099; }
    .next { display: flex; align-items: center; gap: 8px; font-size: 13px; padding: 8px; border-radius: 8px; background: #252930; }
    .next .gap { margin-left: auto; color: #8A9099; font-variant-numeric: tabular-nums; }
    .next.muted { color: #8A9099; }
    .eng { font-size: 11px; color: #8A9099; }
    .cbtn { height: 44px; border-radius: 8px; border: 1px solid #5A5F67; background: #252930; color: #EDEFF2;
      font-size: 14px; font-weight: 600; width: 100%; cursor: pointer; touch-action: manipulation; }
    .cbtn.on { border-color: ${ACCENT}; color: ${ACCENT}; }
    /* the card's Autopilot: the Chrome panel's button (#toggle): "Piloto automático: Sí / No", red and raised = off,
       green and pressed in = on, lit from above, sinks when pressed */
    .cbtn.auto { border: none; border-radius: 6px; background-color: #c0392b; color: #fff; font-weight: 700;
      background-image: linear-gradient(to bottom, rgba(255,255,255,.16), rgba(255,255,255,0) 55%, rgba(0,0,0,.18));
      box-shadow: 0 3px 0 rgba(0,0,0,.45), 0 4px 6px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.18);
      transition: transform .06s, box-shadow .06s, background-color .2s; }
    .cbtn.auto:active { transform: translateY(2px);
      box-shadow: 0 1px 0 rgba(0,0,0,.45), 0 1px 2px rgba(0,0,0,.3), inset 0 1px 2px rgba(0,0,0,.25); }
    .cbtn.auto.on { background-color: #27ae60; color: #fff; transform: translateY(2px);
      background-image: linear-gradient(to bottom, rgba(0,0,0,.22), rgba(0,0,0,0) 45%, rgba(255,255,255,.06));
      box-shadow: 0 1px 0 rgba(0,0,0,.45), inset 0 3px 5px rgba(0,0,0,.45), inset 0 -1px 0 rgba(255,255,255,.08); }
    .cbtn.auto.on:active { transform: translateY(3px); }
    .engines { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; }
    .eng-opt { height: 32px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1px; line-height: 1.1; border-radius: 6px; border: 1px solid #5A5F67; background: #252930; color: #C9CDD3;
      font-size: 12px; font-weight: 600; cursor: pointer; touch-action: manipulation; padding: 0 4px; }
    .eng-sub { font-size: 9px; font-weight: 500; color: #8A9099; }
    .eng-opt.sel .eng-sub { color: ${ACCENT}; opacity: .8; }
    .eng-opt.sel { border: 2px solid ${ACCENT}; color: ${ACCENT}; background: #2B2A22; }
    .eng-note { font-size: 11px; color: #8A9099; min-height: 0; }
    .handring { position: fixed; border: 3px solid ${ACCENT}; border-radius: 6px; pointer-events: none;
      box-shadow: 0 0 0 2px rgba(0,0,0,.35), 0 0 12px rgba(242,181,68,.6); }
    .banner { position: fixed; top: 8px; left: 50%; transform: translateX(-50%); background: ${BG}; color: ${ACCENT};
      border: 1px solid ${ACCENT}; border-radius: 8px; padding: 6px 12px; font-size: 13px; font-weight: 600;
      pointer-events: none; white-space: nowrap; box-shadow: 0 4px 12px rgba(0,0,0,.4); }
    .hidden2 { display: none !important; }
    .unit.locked .tog { opacity: .35; }
    .code { font: 700 22px/1.2 ui-monospace, "Roboto Mono", monospace; letter-spacing: .08em; color: ${ACCENT}; text-align: center;
      padding: 8px; border: 1px dashed #5A5F67; border-radius: 8px; user-select: all; -webkit-user-select: all; }
    .keyin { width: 100%; min-height: 64px; resize: vertical; border-radius: 8px; border: 1px solid #5A5F67; background: #252930;
      color: #EDEFF2; font: 12px/1.3 ui-monospace, monospace; padding: 8px; word-break: break-all; }
    .keyin:focus { outline: 2px solid ${ACCENT}; outline-offset: 1px; }
    .err { font-size: 12px; color: #FF8A7A; line-height: 1.3; }
    .toast.ok { background: #1E8A47; }
    .toast { position: fixed; bottom: 16px; left: 50%; transform: translateX(-50%); background: #B3261E; color: #fff;
      border-radius: 8px; padding: 8px 14px; font-size: 13px; font-weight: 600; pointer-events: none;
      box-shadow: 0 4px 12px rgba(0,0,0,.4); max-width: calc(100% - 32px); text-align: center; }
  `;

  let host = null, root = null, el = {};
  function build() {
    host = document.createElement("div");
    host.id = "cda-mobile-advisor";
    host.style.cssText = "position:fixed;inset:0;z-index:2147483000;pointer-events:none;";
    root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `<style>${CSS}</style>
      <div class="handring hidden"></div>
      <div class="scrim hidden"></div>
      <div class="wrap">
        <div class="unit">
          <div class="btn off-turn" role="button" tabindex="0"><div class="face"></div><span class="lbl"></span></div>
          <div class="tog" role="button" tabindex="0"><svg width="40" height="70" viewBox="0 0 40 70" aria-hidden="true"><defs>
            <linearGradient id="cdaChr" x1="0" x2="1"><stop offset="0" stop-color="#7d838b"/><stop offset=".35" stop-color="#f4f6f8"/><stop offset=".6" stop-color="#b9bec4"/><stop offset="1" stop-color="#5d636b"/></linearGradient>
            <radialGradient id="cdaNut" cx=".4" cy=".35" r=".7"><stop offset="0" stop-color="#f2f4f6"/><stop offset=".55" stop-color="#9aa0a7"/><stop offset="1" stop-color="#4b5057"/></radialGradient>
            <linearGradient id="cdaCapR" x1="0" x2="1"><stop offset="0" stop-color="#7A1A12"/><stop offset=".32" stop-color="#FF7A68"/><stop offset=".55" stop-color="#D93A2B"/><stop offset="1" stop-color="#6B160F"/></linearGradient>
            <linearGradient id="cdaCapG" x1="0" x2="1"><stop offset="0" stop-color="#0E5A2B"/><stop offset=".32" stop-color="#8CF5B2"/><stop offset=".55" stop-color="#2DB862"/><stop offset="1" stop-color="#0C4F26"/></linearGradient></defs>
            <circle class="ring" cx="20" cy="35" r="13"/>
            <polygon points="20,24.5 29.1,29.75 29.1,40.25 20,45.5 10.9,40.25 10.9,29.75" fill="url(#cdaNut)" stroke="#3f444a" stroke-width=".6"/>
            <circle cx="20" cy="35" r="6" fill="#2b2f34"/><circle cx="20" cy="35" r="4.6" fill="url(#cdaNut)"/>
            <g class="lever"><path d="M17.8 35 L17.1 24 L22.9 24 L22.2 35 Z" fill="url(#cdaChr)" stroke="#4b5057" stroke-width=".5"/>
            <path class="capc" d="M16.3 26 L16.0 17.5 Q16.0 13.6 20 13.6 Q24 13.6 24 17.5 L23.7 26 Q20 27.2 16.3 26 Z" stroke="rgba(0,0,0,.45)" stroke-width=".5"/>
            <path d="M17.4 18 Q17.6 15.2 19.6 14.8" fill="none" stroke="rgba(255,255,255,.65)" stroke-width=".9" stroke-linecap="round"/></g></svg></div>
          <span class="dot hidden"></span>
        </div>
      </div>
      <aside class="card" aria-hidden="true">
        <div class="act" style="display:flex;flex-direction:column;gap:10px">
          <div class="kicker">${T.actHead}</div>
          <div class="title">${T.actTitle}</div>
          <div class="ctx">${T.actText}</div>
          <div class="code"></div>
          <button class="cbtn copy" type="button">${T.copy}</button>
          <textarea class="keyin" rows="3" spellcheck="false" autocapitalize="off" autocomplete="off" placeholder="${T.keyPlaceholder}"></textarea>
          <div class="err hidden"></div>
          <button class="cbtn on activate" type="button">${T.activate}</button>
        </div>
        <div class="adv" style="display:flex;flex-direction:column;gap:10px">
        <div class="head"><div class="ring"></div><div><div class="kicker"></div><div class="title"></div></div></div>
        <div class="ctx"></div>
        <div class="sec">${T.why}</div>
        <ol class="why"></ol>
        <div class="sec">${T.nextBest.toUpperCase()}</div>
        <div class="next"></div>
        <div class="sec">${T.engineHead}</div>
        <div class="engines">${ENGINE_MODES.map(([v, n]) => `<button class="eng-opt" type="button" data-mode="${v}"><span>${n}</span>${v === "alternate-5s" ? `<span class="eng-sub">${T.recommendedEngine}</span>` : ""}</button>`).join("")}</div>
        <div class="eng"></div>
        <div class="eng-note hidden"></div>
        <button class="cbtn auto" type="button" role="switch"></button>
        </div>
        <button class="cbtn close" type="button">${T.close}</button>
      </aside>
      <div class="banner hidden">${T.rotate}</div>
      <div class="toast hidden" role="status"></div>`;
    const q = (s) => root.querySelector(s);
    el = { wrap: q(".wrap"), unit: q(".unit"), btn: q(".btn"), face: q(".face"), lbl: q(".lbl"), dot: q(".dot"), tog: q(".tog"),
      card: q(".card"), scrim: q(".scrim"), ring: q(".ring"), kicker: q(".kicker"), title: q(".title"), ctx: q(".ctx"), why: q(".why"),
      next: q(".next"), eng: q(".eng"), cAuto: q(".cbtn.auto"), cClose: q(".cbtn.close"), handring: q(".handring"),
      banner: q(".banner"), toast: q(".toast"), act: q(".act"), adv: q(".adv"), code: q(".code"), copy: q(".cbtn.copy"),
      keyin: q(".keyin"), err: q(".err"), activate: q(".cbtn.activate"), engNote: q(".eng-note"),
      engOpts: Array.from(root.querySelectorAll(".eng-opt")) };
    // Nothing done on our controls may reach Ludoteka (a drag of the button must never be a tap on a tile underneath).
    for (const ev of ["pointerdown", "pointerup", "pointermove", "pointercancel", "touchstart", "touchmove", "touchend",
                      "mousedown", "mouseup", "click", "dblclick", "contextmenu", "wheel",
                      "keydown", "keyup", "keypress", "input", "beforeinput", "paste", "copy", "focusin", "focusout"]) {
      host.addEventListener(ev, (e) => e.stopPropagation());
    }
    (document.body || document.documentElement).appendChild(host);
    wireDrag();
    el.tog.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggleAuto(); } });
    el.cAuto.addEventListener("click", toggleAuto);
    el.cClose.addEventListener("click", () => closeCard());
    el.scrim.addEventListener("click", () => closeCard());
    el.btn.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openCard(); } });
    wireSwipe();
    for (const b of el.engOpts) b.addEventListener("click", () => setEngineMode(b.dataset.mode));
    el.copy.addEventListener("click", copyCode);
    el.activate.addEventListener("click", tryActivate);
    el.keyin.addEventListener("input", () => el.err.classList.add("hidden"));
  }

  // ── Engine setting: one tap; content.js applies it (a fixed engine at once, La Parejita from the next hand) ──
  let engineMode = "alternate-5s";
  function setEngineMode(v) {
    if (!ENGINE_MODES.some(([m]) => m === v) || v === engineMode) return;
    engineMode = v;
    try { chrome.storage.local.set({ cdaEngineMode: v }); } catch (e) {}
    el.engNote.textContent = v === "alternate-5s" ? T.engineNext : T.engineNow;
    el.engNote.classList.remove("hidden");
    renderCard();
  }

  // ── Activation (license.js): until this device has its key the advisor is locked ──
  const lic = () => window.CDA_LICENSE;
  const locked = () => { const L = lic(); return !!(L && L.required && !L.ok); };
  function copyCode() {
    const code = lic() ? lic().code() : "";
    try { navigator.clipboard.writeText(code).then(() => toast("copied", true), () => selectCode()); } catch (e) { selectCode(); }
  }
  function selectCode() {   // no clipboard access: select the code so a long press copies it
    try {
      const r = document.createRange();
      r.selectNodeContents(el.code);
      const sel = root.getSelection ? root.getSelection() : window.getSelection();
      sel.removeAllRanges();
      sel.addRange(r);
    } catch (e) {}
  }
  async function tryActivate() {
    const L = lic();
    if (!L) return;
    el.activate.disabled = true;
    const good = await L.activate(el.keyin.value);
    el.activate.disabled = false;
    if (!good) { el.err.textContent = T.badKey; el.err.classList.remove("hidden"); return; }
    el.keyin.value = "";
    toast("activated", true);
    closeCard();
    render();
  }

  // ── State ───────────────────────────────────────────────────────────────
  let model = { phase: "idle", myTurn: false };
  let last = null;            // the last advice shown (kept, dimmed, between turns)
  let auto = false;
  let pos = null;             // saved position, as fractions of the screen {fx, fy}
  let placedByHand = false;   // default position taken from the hand's tiles (only until the user drags)
  let cardOpen = false;
  let toastTimer = null;

  function render() {
    if (!host) return;
    const show = active && (onGamePage || onLobby);
    host.style.display = show ? "" : "none";
    if (!show) return;
    el.banner.classList.toggle("hidden", !(window.innerHeight > window.innerWidth));
    el.unit.classList.toggle("locked", locked());
    if (locked()) {
      el.face.innerHTML = LOCK_SVG;
      el.face.classList.remove("hidden");
      el.lbl.textContent = T.lockLabel;
      el.btn.setAttribute("aria-label", T.ariaLocked);
      el.btn.classList.remove("off-turn");
      el.unit.classList.remove("dormant");   // the padlock is always at full strength
      el.dot.classList.add("hidden");
      el.unit.classList.remove("auto");
      el.tog.classList.remove("on");
      renderCard();
      return;
    }
    const m = model;
    const adv = m.phase === "play" ? m : null;
    if (adv) last = adv;
    let tileHTML = "", label = "", aria = "";
    if (m.phase === "play") {
      tileHTML = tileSVG(m.tile, 1);
      label = m.kind === "end" ? T.end(m.endNum) : m.kind === "either" ? T.either : m.kind === "lead" ? T.lead : T.free;
      aria = ariaOf(m);
    } else if (m.phase === "thinking") {
      tileHTML = tileSVG(null, 1).replace('class="tile"', 'class="tile dim"');
      label = T.thinking; aria = T.ariaThinking;
    } else if (m.phase === "pass") {
      label = T.pass; aria = T.ariaPass;
    } else if (m.phase === "wait" && last) {
      tileHTML = tileSVG(last.tile, 1);
      label = last.kind === "end" ? T.end(last.endNum) : last.kind === "either" ? T.either : last.kind === "lead" ? T.lead : T.free;
      aria = T.ariaWait(adviceText(last));
    } else {
      aria = m.phase === "wait" ? T.ariaWait("") : T.ariaIdle;
    }
    el.face.innerHTML = tileHTML;
    el.face.classList.toggle("hidden", !tileHTML);
    el.lbl.textContent = label;
    el.btn.setAttribute("aria-label", aria);
    el.btn.classList.toggle("off-turn", !m.myTurn);
    el.unit.classList.toggle("dormant", !onGamePage || m.phase === "idle");
    el.dot.classList.toggle("hidden", !m.myTurn);
    el.unit.classList.toggle("auto", auto);
    el.tog.classList.toggle("on", auto);
    el.tog.setAttribute("aria-label", auto ? T.autoOn : T.autoOff);
    el.tog.setAttribute("aria-pressed", String(auto));
    renderCard();
  }
  function ariaOf(m) {
    return m.kind === "end" ? T.ariaEnd(m.tileStr, m.endNum) : m.kind === "either" ? T.ariaEither(m.tileStr, m.endNum)
      : m.kind === "lead" ? T.ariaLead(m.tileStr) : T.ariaFree(m.tileStr);
  }
  function adviceText(m) {
    return m.kind === "end" ? T.playEnd(m.tileStr, m.endNum) : m.kind === "either" ? T.playEither(m.tileStr)
      : m.kind === "lead" ? T.playLead(m.tileStr) : T.playFree(m.tileStr);
  }

  function renderCard() {
    const lk = locked();
    el.act.classList.toggle("hidden2", !lk);
    el.adv.classList.toggle("hidden2", lk);
    if (lk) {
      const rv = !!lic().revoked && !!lic().keyOk;   // a valid key, but switched off by the owner
      el.code.textContent = lic().code() || "…";
      el.act.querySelector(".title").textContent = rv ? T.revokedTitle : T.actTitle;
      el.act.querySelector(".ctx").textContent = rv ? T.revokedText : T.actText;
      for (const x of [el.copy, el.keyin, el.activate]) x.classList.toggle("hidden2", rv);
      return;
    }
    for (const b of el.engOpts) {
      const sel = b.dataset.mode === engineMode;
      b.classList.toggle("sel", sel);
      b.setAttribute("aria-pressed", String(sel));
    }
    el.cAuto.textContent = T.autoBtn(auto);
    el.cAuto.classList.toggle("on", auto);
    el.cAuto.setAttribute("aria-checked", String(auto));
    el.cAuto.setAttribute("aria-label", auto ? T.autoOn : T.autoOff);
    el.eng.textContent = T.engine(model.engine || (last && last.engine));
    if (!cardOpen) return;
    const m = model;
    const a = m.phase === "play" ? m : m.phase === "wait" ? last : null;
    el.ring.classList.toggle("empty", !a);
    el.ring.innerHTML = tileSVG(a ? a.tile : null, 1.6);
    if (m.phase === "thinking") { el.kicker.textContent = T.thinkingHead; el.title.textContent = ""; }
    else if (m.phase === "pass") { el.kicker.textContent = T.passHead; el.title.textContent = T.passText; }
    else if (a) { el.kicker.textContent = m.phase === "play" ? T.recommended : T.lastAdvice; el.title.textContent = adviceText(a); }
    else { el.kicker.textContent = ""; el.title.textContent = T.waitText; }
    const why = a ? a.why || [] : [];
    el.ctx.textContent = a ? (a.fallback ? T.fallback : a.kind === "lead" ? T.leadNote : why[0] ? cap(why[0].why) : "") : "";
    el.why.innerHTML = "";
    for (const r of why.slice(0, 3)) {
      const li = document.createElement("li");
      li.textContent = cap(r.why);
      if (r.ref) { const s = document.createElement("span"); s.className = "ref"; s.textContent = r.ref; li.appendChild(s); }
      el.why.appendChild(li);
    }
    const b = a && a.planB;
    el.next.classList.toggle("muted", !b);
    if (b) {
      const where = b.kind === "end" ? T.end(b.endNum) : b.kind === "either" ? T.either : b.kind === "lead" ? T.lead : "";
      el.next.innerHTML = `${tileSVG(b.tile, 0.8)}<span></span><span class="gap"></span>`;
      el.next.children[1].textContent = `${b.tileStr}${where ? " " + where : ""}`;
      el.next.children[2].textContent = "−" + Math.abs(b.behind).toFixed(1);
    } else {
      el.next.textContent = a ? T.onlyMove : "—";
    }
  }
  const cap = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);

  // ── Card ────────────────────────────────────────────────────────────────
  let ringTimer = null;
  function openCard() {
    cardOpen = true;
    el.card.classList.add("open");
    el.card.setAttribute("aria-hidden", "false");
    el.scrim.classList.remove("hidden");
    renderCard();
    requestHand();
    if (!ringTimer) ringTimer = setInterval(requestHand, 1000);
  }
  function closeCard() {
    if (!cardOpen) return;
    cardOpen = false;
    el.card.classList.remove("open");
    el.card.setAttribute("aria-hidden", "true");
    el.scrim.classList.add("hidden");
    el.handring.classList.add("hidden");
    if (ringTimer) { clearInterval(ringTimer); ringTimer = null; }
  }
  function wireSwipe() {
    let sx = null, sy = 0;
    el.card.addEventListener("pointerdown", (e) => { if (e.target === el.keyin) return; sx = e.clientX; sy = e.clientY; el.card.style.transition = "none"; });
    el.card.addEventListener("pointermove", (e) => {
      if (sx === null) return;
      const dx = e.clientX - sx;
      if (dx > 0 && Math.abs(dx) > Math.abs(e.clientY - sy)) el.card.style.transform = `translateX(${dx}px)`;
    });
    const end = (e) => {
      if (sx === null) return;
      const dx = e.clientX - sx;
      sx = null;
      el.card.style.transition = "";
      el.card.style.transform = "";
      if (dx > 60) closeCard();
    };
    el.card.addEventListener("pointerup", end);
    el.card.addEventListener("pointercancel", end);
  }

  // ── Where the hand is (ring around the recommended tile, default button spot) ──
  function requestHand() {
    if (!host || !onGamePage) return;
    window.postMessage({ source: "LUDO_ADVISOR_CMD", type: "LOCATE_HAND" }, "*");
  }
  let handRects = null;
  window.addEventListener("message", (evt) => {
    const d = evt.data;
    if (!host || !d || d.source !== "LUDO_ADVISOR" || d.type !== "HAND_RECTS") return;   // (no evt.source check: Firefox wraps window)
    handRects = d.rects || null;
    drawHandRing();
    if (!pos && !placedByHand && handRects) { placedByHand = true; place(defaultSpot()); }
  });
  function drawHandRing() {
    const a = model.phase === "play" ? model : null;
    const r = a && cardOpen && handRects ? Object.values(handRects).find((x) => x.tile && sameTile(x.tile, a.tile)) : null;
    el.handring.classList.toggle("hidden", !r);
    if (r) Object.assign(el.handring.style, { left: r.x - 4 + "px", top: r.y - 4 + "px", width: r.w + 8 + "px", height: r.h + 8 + "px" });
  }
  const sameTile = (a, b) => (a[0] === b[0] && a[1] === b[1]) || (a[0] === b[1] && a[1] === b[0]);

  // ── Position and dragging ───────────────────────────────────────────────
  let cur = { x: 0, y: 0 };
  function clamp(p) {
    const vw = window.innerWidth, vh = window.innerHeight;
    return { x: Math.max(EDGE, Math.min(vw - WRAP_W - EDGE, p.x)), y: Math.max(EDGE + 6, Math.min(vh - BTN - EDGE, p.y)) };
  }
  function place(p) {
    cur = clamp(p);
    el.wrap.style.transform = `translate(${Math.round(cur.x)}px, ${Math.round(cur.y)}px)`;
  }
  function defaultSpot() {
    const vw = window.innerWidth, vh = window.innerHeight;
    const rs = handRects ? Object.values(handRects) : [];
    if (rs.length) {
      const right = Math.max(...rs.map((r) => r.x + r.w)), top = Math.min(...rs.map((r) => r.y)), bottom = Math.max(...rs.map((r) => r.y + r.h));
      const beside = { x: right + 10, y: (top + bottom) / 2 - BTN / 2 };
      if (beside.x + WRAP_W + EDGE <= vw) return beside;           // to the right of the hand's last tile
      return { x: vw - WRAP_W - EDGE, y: top - BTN - 10 };          // no room: just above the hand, at the right
    }
    return { x: vw - WRAP_W - 12, y: vh / 2 - BTN / 2 };
  }
  function restore() {
    if (pos) place({ x: pos.fx * window.innerWidth, y: pos.fy * window.innerHeight });
    else place(defaultSpot());
  }
  function wireDrag() {
    let start = null, moved = false;
    el.unit.addEventListener("pointerdown", (e) => {
      if (e.button !== undefined && e.button !== 0) return;
      start = { px: e.clientX, py: e.clientY, x: cur.x, y: cur.y, id: e.pointerId, onTog: el.tog.contains(e.target) };
      moved = false;
      try { el.unit.setPointerCapture(e.pointerId); } catch (x) {}
    });
    el.unit.addEventListener("pointermove", (e) => {
      if (!start || e.pointerId !== start.id) return;
      const dx = e.clientX - start.px, dy = e.clientY - start.py;
      if (!moved && Math.hypot(dx, dy) < 8) return;
      moved = true;
      el.unit.style.cursor = "grabbing";
      place({ x: start.x + dx, y: start.y + dy });
    });
    const up = (e) => {
      if (!start || e.pointerId !== start.id) return;
      const onTog = start.onTog;
      start = null;
      el.unit.style.cursor = "";
      if (moved) {                         // a drag: save the spot, never a tap
        pos = { fx: cur.x / window.innerWidth, fy: cur.y / window.innerHeight };
        try { chrome.storage.local.set({ cdaMobilePos: pos }); } catch (x) {}
        return;
      }
      if (e.type !== "pointerup") return;
      if (onTog) toggleAuto();
      else cardOpen ? closeCard() : openCard();
    };
    el.unit.addEventListener("pointerup", up);
    el.unit.addEventListener("pointercancel", up);
  }

  // ── AUTO ────────────────────────────────────────────────────────────────
  function toggleAuto() {
    if (locked()) { openCard(); return; }
    try { chrome.storage.local.set({ botEnabled: !auto }); } catch (e) {}
    // the storage change comes back through onChanged and redraws (the stored switch is the source of truth)
  }

  function toast(kind, ok) {
    if (!host) return;
    el.toast.classList.toggle("ok", !!ok);
    el.toast.textContent = T[kind] || String(kind);
    el.toast.classList.remove("hidden");
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.toast.classList.add("hidden"), 4000);
  }

  // ── API for content.js ──────────────────────────────────────────────────
  window.CDA_MOBILE = {
    active: () => active,
    update(m) {
      if (!m) return;
      const prev = model;
      if (!host) { model = m; return; }   // the mobile UI is off (Chrome build, or a wide desktop window)
      model = m;
      // the user (or the bot) played: the card closes by itself
      if (cardOpen && !locked() && prev.myTurn && (!m.myTurn || (m.historyLen !== undefined && m.historyLen > prev.historyLen))) closeCard();
      if (m.phase === "idle") last = null;
      render();
      if (cardOpen) drawHandRing();
      if (!pos && !placedByHand && m.myTurn) requestHand();
    },
    toast,
    // for the replay harness (dev/replay.mjs --mobile): what the button shows right now
    _debug: () => (host ? { label: el.lbl.textContent, aria: el.btn.getAttribute("aria-label") || "",
      dot: !el.dot.classList.contains("hidden"), dim: el.btn.classList.contains("off-turn"), auto, locked: locked() } : null),
  };

  // ── Start ───────────────────────────────────────────────────────────────
  function start() {
    if (BUILD !== "firefox" || host || !active) return;   // built only when the mobile UI is on (also later, on resize)
    build();
    if (lic()) lic().onChange(() => render());
    try {
      chrome.storage.local.get(["botEnabled", "cdaMobilePos", "cdaEngineMode"], (r) => {
        auto = !!r.botEnabled;
        if (ENGINE_MODES.some(([m]) => m === r.cdaEngineMode)) engineMode = r.cdaEngineMode;
        if (r.cdaMobilePos && typeof r.cdaMobilePos.fx === "number") pos = r.cdaMobilePos;
        restore();
        render();
      });
      chrome.storage.onChanged.addListener((chg) => {
        if (chg.botEnabled) { auto = !!chg.botEnabled.newValue; render(); }
        if (chg.cdaEngineMode && ENGINE_MODES.some(([m]) => m === chg.cdaEngineMode.newValue)) { engineMode = chg.cdaEngineMode.newValue; render(); }
      });
    } catch (e) {}
    restore();
    render();
  }
  if (BUILD === "firefox") {
    window.addEventListener("resize", () => {
      active = isActive();
      if (!host) { if (active && document.body) start(); return; }
      restore();
      render();
      if (cardOpen) requestHand();
    });
    if (document.body) start();
    else document.addEventListener("DOMContentLoaded", start);
  }
})();

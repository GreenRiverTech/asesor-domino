// i18n-es.js — Spanish for the panel (display only). The engine, content.js and the saved log stay in English, because
// the test and review tools read the log; the panel translates what it shows. Unknown phrases are shown as they are.
(function () {
  // whole texts that content.js sends to the panel
  const EXACT = {
    "No game": "Sin partida",
    "Game over": "Fin de la partida",
    "Hand finished": "Mano terminada",
    "No game in progress — open a table to start.": "No hay partida: abre una mesa para empezar.",
    "Waiting for new hand...": "Esperando la nueva mano...",
    "Waiting for your turn...": "Esperando tu turno...",
    "Waiting your turn...": "Esperando tu turno...",
    "Game active — waiting for your turn...": "Partida en curso: esperando tu turno...",
    "Hand finished — waiting for the next deal...": "Mano terminada: esperando el próximo reparto...",
    "Waiting for game...": "Esperando partida...",
    "Opponents playing...": "Juegan los demás...",
    "Your turn detected, but tile values are unknown (joined mid-hand). Refresh the page and wait for the next deal.":
      "Es tu turno, pero no se conocen tus fichas (entraste a media mano). Recarga la página y espera el próximo reparto.",
  };

  // the engine's reasons (one phrase each, between "; ")
  const N = "(\\d)", T = "([\\dB]-[\\dB])", J = "(J\\d)", NUM = "(-?[\\d.]+)";
  const R = (re, out) => [new RegExp("^" + re + "$"), out];
  const REASONS = [
    R("heavy tile first", "botar la gorda primero"),
    R("partner can play", "la pareja puede jugar"),
    R("give your own number / play your data", "da tu número / juega tu data"),
    R("creates a new fallo", "crea un fallo nuevo"),
    R("kill the opponent's number", "mata el número del contrario"),
    R("playable on both ends next turn", "jugable por las dos puntas en tu próximo turno"),
    R("opponents' strong " + N + " can enter on both ends", "el $1 fuerte de los contrarios entra por las dos puntas"),
    R(J + " could throw with the linking tile " + T, "$1 podría tirar con la ficha de enlace $2"),
    R("our pair holds most of the " + N + "s", "nuestra pareja tiene la mayoría de los $1"),
    R("kills the partner's number", "mata el número de la pareja"),
    R("gives the opponent's number " + N, "le da al contrario su número $1"),
    R("repeat your own tile", "repite tu ficha"),
    R("kill " + J + "'s number before " + J + "'s", "mata el número de $1 antes que el de $2"),
    R("covers a number our pair dominates", "tapa un número que domina nuestra pareja"),
    R("leaves no next play", "te deja sin próxima jugada"),
    R("fresca in the ending", "fresca en el final"),
    R("fresca \\(prefer repeating\\)", "fresca (mejor repetir)"),
    R("fresca", "fresca"),
    R("opponents' lead " + N + " can't re-enter next turn", "la salida de los contrarios ($1) no puede volver a entrar"),
    R("give the partner's number", "da el número de la pareja"),
    R("covers our number that passes the opponents", "tapa nuestro número que hace pasar a los contrarios"),
    R("kill the oldest", "mata el más viejo"),
    R("kills your own number", "mata tu propio número"),
    R("play a double", "juega un doble"),
    R("you hold the linking tile " + T + ": " + J + " can't throw", "tienes la ficha de enlace $1: $2 no puede tirar"),
    R("several doubles in hand", "varios dobles en la mano"),
    R("kill the number that passed your partner", "mata el número que hizo pasar a tu pareja"),
    R("cover the opponents' lead", "tapa la salida de los contrarios"),
    R("opponent tile stayed more than a round", "ficha contraria lleva más de una vuelta"),
    R("strong number: covers the only " + N + " end while you hold the " + T, "número fuerte: tapa la única punta del $1 teniendo el $2"),
    R("strong number: play the " + T + " while its end is open", "número fuerte: juega el $1 mientras su punta está abierta"),
    R("strong number: open your " + N + "s", "número fuerte: abre tus $1"),
    R("strong number: the " + N + " is yours now", "número fuerte: el $1 ya es tuyo"),
    R("throw with " + J, "tira con $1"),
    R(">(\\d+) doubles dealt: unload them", "más de $1 dobles: descárgalos"),
    R("(\\d+) doubles dealt: raise the priority of shedding them", "$1 dobles: suéltalos antes"),
    R("double on " + J + "'s number", "doble sobre el número de $1"),
    R("block risk/chance p=" + NUM + ", EV " + NUM + " pts", "riesgo de tranque p=$1, valor $2 pts"),
    R("block math: p=" + NUM + ", EV " + NUM + " pts", "cálculo de tranque p=$1, valor $2 pts"),
    R("other terms count x" + NUM, "el resto cuenta x$1"),
    R("keeps your escape route open: a number " + J + " lacks", "mantiene tu salida: un número que le falta a $1"),
    R("closes your escape route against " + J, "cierra tu salida contra $1"),
    R("double at risk of being strangled", "doble en peligro de ahorcarse"),
    R("give the own lead again", "repite tu salida"),
    R("domino: go out", "dominó: te pegas"),
    R("big double: play the " + T + " while it can go", "doble grande: juega el $1 mientras pueda"),
    R("endgame: (\\d+) playouts, mean " + NUM + " pts", "final: $1 simulaciones, media $2 pts"),
    R("make " + J + " pass", "haz pasar a $1"),
    R("keep " + J + " controlled", "mantén controlado a $1"),
    R("partner threw to draw out the double", "la pareja tiró para sacar el doble"),
    R("double on the pair's strong number", "doble sobre el número fuerte de la pareja"),
    R("double on the partner's number that just passed " + J, "doble sobre el número de la pareja que acaba de hacer pasar a $1"),
    R("high double in the ending", "doble alto en el final"),
    R("don't double on a fresh number in the middle game", "no dobles sobre un número fresco a media partida"),
    R("partner paused on this number: he holds more", "la pareja dudó en este número: tiene más"),
    R("kill " + J + "'s lead", "mata la salida de $1"),
    R("kill the opponents' lead with the falla", "mata la salida de los contrarios con la falla"),
    R("let " + J + "'s tile pass to " + J, "deja pasar la ficha de $1 a $2"),
    R("respect the partner's lead: kill it only exceptionally", "respeta la salida de la pareja: mátala solo en caso extremo"),
    R("domino", "dominó"),
  ];
  function reason(r) {
    const s = r.trim();
    for (const [re, out] of REASONS) if (re.test(s)) return s.replace(re, out);
    return s;
  }

  // a whole text: the move ("7-4 on the 4 end. reasons"), a game message, or a known phrase
  function text(s) {
    if (!s) return s;
    if (EXACT[s]) return EXACT[s];
    let m = /^Board: (\d) \| (\d) — Opponents playing\.\.\.$/.exec(s);
    if (m) return `Mesa: ${m[1]} | ${m[2]} — juegan los demás...`;
    m = /^Game over — you (won|lost) (\d+)–(\d+)\.$/.exec(s);
    if (m) {
      // a match won with the other team on 0 is a "pollona" (and lost on 0, one for them)
      const won = m[1] === "won", pollona = won ? m[3] === "0" : m[2] === "0";
      return `Fin de la partida: ${won ? "ganaste" : "perdiste"} ${m[2]}–${m[3]}.` +
        (pollona ? (won ? " ¡Le dimos pollona al otro equipo!" : " Nos dieron pollona.") : "");
    }
    m = /^Engine cannot decide this turn \((.*)\)\. Play it yourself\.$/.exec(s);
    if (m) return `El motor no puede decidir esta jugada (${m[1]}). Juégala tú.`;
    m = /^([\dB]-[\dB])( on the (\d) end)?\.\s*(.*)$/.exec(s);
    if (m) {
      const head = m[1] + (m[3] !== undefined ? ` en la punta del ${m[3]}` : "") + ".";
      let rest = m[4] || "";
      const fb = /^Fallback: heaviest playable tile \((.*)\)\.$/.exec(rest);
      if (fb) return `${head} Respaldo: la ficha más pesada que se puede jugar (${fb[1]}).`;
      return rest ? `${head} ${rest.split(";").map(reason).join("; ")}` : head;
    }
    return s;
  }
  window.ES = { text, reason };
})();

// The public half of the activation-key pair (tools/license.mjs init). Checks keys; cannot make them.
window.CDA_LICENSE_PUBKEY = {"kty":"EC","crv":"P-256","x":"hhdjqLzvzZOiG6wh54Us98nu0IQwSTRYunr1nLSGZjg","y":"iBPAUSofkVe5tfA8cao8ePtexAEuAneY2yk8bqTFaAI"};
// The owner's list of deactivated devices (tools/license.mjs revocation-setup).
window.CDA_REVOCATION_URL = "https://gist.githubusercontent.com/GreenRiverTech/66244170c553efffcb05b5d01f66779e/raw/cda-revoked.json";

// injected.js - Page-context hook for Cuban Domino Advisor
// Tile IDs are integers: standard double-9 sequence index (0=>[0,0], 1=>[0,1], ... 54=>[9,9])
// t.ups() returns the FULL hand as an array of integers + 'rnd' when it's our turn.
// When it's NOT our turn, t.ups() returns [] or ['rnd'] only.

(function () {
  "use strict";

  // Run once per page: the Firefox build also adds this file as a <script> tag when the MAIN-world content script
  // did not run (inject-fallback.js); whichever copy comes second stops here.
  if (window.__cdaInjected) return;
  window.__cdaInjected = true;
  try { document.documentElement.setAttribute("data-cda-hook", "1"); } catch (e) {}

  // Dead flag — set when extension context is invalidated
  // Stops all broadcasting to prevent crash loops in content.js
  let _dead = false;

  function post(data) {
    if (_dead) return;
    window.postMessage({ source: "LUDO_ADVISOR", ...data }, "*");
  }

  // Listen for stop signal from content.js when context is invalidated
  window.addEventListener("message", (evt) => {
    if (evt.data?.source === "LUDO_ADVISOR_STOP") {
      _dead = true;
      if (broadcastTimer) clearTimeout(broadcastTimer);
      console.log("[CDA] Extension context invalidated — broadcasting stopped.");
    }
  });

  // Convert Ludoteka tile ID → [v1,v2] by reading ht[id].nums directly.
  // IMPORTANT: Ludoteka IDs are deal-order indexes into the ht[] array,
  // NOT pip-sequence indexes. Mathematical conversion is WRONG.
  // ht[] is exposed as window._cdaHt during patch (see patch() below).
  // idToTile: uses _cdaNums map built from inst.event({tell}) hook.
  // _cdaNums[id] = [v1,v2] populated when tiles are dealt.
  function idToTile(id) {
    const nums = window._cdaNums && window._cdaNums[id];
    if (nums) return [nums[0], nums[1]];
    return null;
  }

  function tk(t) {
    return Math.min(t[0],t[1]) + "," + Math.max(t[0],t[1]);
  }

  const G = {
    t:      null,
    inst:   null,
    hand:   [],    // our current hand [[v1,v2],...] — replaced each turn
    played: [],    // board history [[v1,v2],...]
    ends:   [],    // [leftEnd, rightEnd]
    sizes:  { partner: null, opponentLeft: null, opponentRight: null },
    ids:    [],    // raw integer IDs from last t.ups()
    myTurn: false,
    // Track our hand across turns by remembering what we had last turn
    // and removing whatever was played
    lastHandIds: new Set(),
    // Tile counts read from DOM
    domSizesFound: false,
    // ── Exact tracking from the game's own event stream (see handleGameEvent) ──
    myWh:        null,          // my absolute seat index (0-3); fixed for the whole game
    turn:        null,          // absolute seat whose turn it is (from lead chip + puts + passes)
    counts:      [0, 0, 0, 0],  // tiles played per absolute seat this hand
    players:     [],            // absolute seat of each tile in G.played
    endInfo:     null,          // [{id, v, t}, {id, v, t}] tile id + exposed value + the tile itself, of each board end
    myIds:       new Set(),     // ids of my dealt tiles
    initialHand: null,          // my 10 dealt tiles [[a,b],...]
    takes:       {},            // seat -> tile ids dealt to that seat ({take, where} events)
    matched:     [],            // per tile played: the board-end value it attached to (null for the first tile)
    passes:      [],            // real passes this hand: [{ who: absolute seat, ends: [a, b] }]
    evs:         [],            // this hand's turn-advancing events, in order: {k:"put",mine} / {k:"pass",who}
    evAt:        [],            // time (ms) of each event in evs, for the think-time log (logging only)
    names:       null,          // player names by seat, if the game sends them (logging only)
    nameSamples: 0,             // raw events mentioning "name" already logged (to learn the format)
    marks:       new Set(),     // event counts at which ups() listed my playable tiles (so it was my turn)
  };
  window._cdaG = G;

  // ── Game event stream ─────────────────────────────────────────────────────
  // Ludoteka sends: {chas}=new deal, {chip,what:"lead",who}=who opens,
  // {tell:[10 tiles]} (no grp)=my hand, {tell:[1 tile],grp:"putN"}+{chain:N,to,side}=a tile
  // played, {say:{en:"Pass"},who}=a pass.  Plays do not say who played, but turn order is
  // strictly cyclic, so lead + puts + passes pin down every play exactly.
  function isPass(say) {
    return !!say && typeof say === "object" && (say.en === "Pass" || say.es === "Paso");
  }

  function handleGameEvent(d) {
    if (!d || typeof d !== "object") return;

    if (Array.isArray(d.chas)) { resetRound(); return; }

    // Player names (logging only, to learn whether partner profiles are possible). Replays carry who:[{name}];
    // the live format is not known yet, so the first few raw events that mention "name" are logged as samples.
    if (Array.isArray(d.who) && d.who.length === 4 && d.who.every((w) => w && typeof w.name === "string")) {
      const names = d.who.map((w) => w.name);
      if (!G.names || G.names.join("|") !== names.join("|")) { G.names = names; post({ type: "PLAYERS", names }); }
    }
    if (G.nameSamples < 3) {
      let raw = "";
      try { raw = JSON.stringify(d); } catch (e) {}
      if (raw.indexOf('"name"') !== -1) { G.nameSamples++; post({ type: "NAMES_SAMPLE", sample: raw.slice(0, 400) }); }
    }

    // End of hand / game. {ttscr} carries the goal, {score:"team0,team1"} the running totals and
    // {sumscr} arrives once the hand is settled. Seats 0/2 are team 0, seats 1/3 team 1.
    if (d.ttscr && d.ttscr.en) {
      const m = String(d.ttscr.en).match(/(\d+)/);
      if (m) G.goal = Number(m[1]);
    }
    if (typeof d.score === "string") {
      const [a, b] = d.score.split(",").map(Number);
      G.totals = [a, b];          // running match score: [team 0 (seats 0/2), team 1 (seats 1/3)]
      G.gameEnd = null;
      if (G.goal && G.myWh !== null && (a >= G.goal || b >= G.goal)) {
        const mine = G.myWh % 2 === 0 ? a : b, theirs = G.myWh % 2 === 0 ? b : a;
        G.gameEnd = { mine, theirs, won: mine > theirs };
        post({ type: "HAND_END", gameEnd: G.gameEnd, totals: G.totals, thinks: thinkReport() });   // do not wait for {sumscr}: it may never come
      }
    }
    if (Array.isArray(d.sumscr)) {
      post({ type: "HAND_END", gameEnd: G.gameEnd || null, hand: d.sumscr, totals: G.totals || null, thinks: thinkReport() });
      G.gameEnd = null;
    }

    // First hand sends chip:"on", later hands chip:"mv"; both can arrive just before the {chas} deal.
    if ((d.chip === "on" || d.chip === "mv") && d.what === "lead" && typeof d.who === "number") {
      G.turn = d.who;
      G.lastLead = { who: d.who, at: Date.now() };
      console.log("[CDA] lead: seat", d.who);
    }

    // The deal: {take:[ids], where:seat}. My own ten ids tell me which seat I am.
    if (Array.isArray(d.take) && typeof d.where === "number") {
      G.takes[d.where] = d.take;
      resolveMySeat();
    }

    if (Array.isArray(d.tell) && d.tell.length > 0) {
      const isPut = typeof d.grp === "string" && d.grp.indexOf("put") === 0;
      if (isPut && d.tell.length === 1) {
        G.pendingPut = { id: d.tell[0].id, par: d.tell[0].par };
      } else if (!d.grp && !d.show && d.tell.length >= 2 && G.myIds.size === 0) {
        // My dealt hand
        G.myIds = new Set(d.tell.map(e => e.id));
        G.initialHand = d.tell.map(e => [e.par[0], e.par[1]]);
        G.hand = G.initialHand.map(t => [t[0], t[1]]);
        G.lastHandIds = new Set(d.tell.map(e => String(e.id)));
        console.log("[CDA] My hand:", G.hand.map(t => t.join("-")).join(", "));
        resolveMySeat();
      }
    }

    if (typeof d.chain === "number" && G.pendingPut && G.pendingPut.id === d.chain) {
      const p = G.pendingPut;
      G.pendingPut = null;
      recordPut(p.id, p.par, d.to, d.side);
    }

    if (isPass(d.say) && typeof d.who === "number") {
      G.evs.push({ k: "pass", who: d.who });
      G.evAt.push(Date.now());
      if (G.ends.length >= 2) G.passes.push({ who: d.who, ends: [...G.ends] });
      G.turn = (d.who + 1) % 4;
      resolveSeats();
      scheduleBroadcast(30);   // show the new pass at once, without waiting for the next play
    }
  }

  function resolveMySeat() {
    if (G.myIds.size === 0) return;
    for (const seat of Object.keys(G.takes)) {
      const ids = G.takes[seat];
      if (ids.length > 0 && ids.every(i => G.myIds.has(i))) {
        if (G.myWh !== Number(seat)) console.log("[CDA] My seat:", seat);
        G.myWh = Number(seat);
        return;
      }
    }
  }

  // Who played each tile. Puts carry no seat, but turn order is strictly cyclic, so the hand is
  // fully determined by the opener's seat s0: event i belongs to seat (s0 + i) % 4. The opener is
  // not announced reliably (either teammate may open, and the lead event can be missing), so it is
  // solved from what is certain:
  //   - a pass names its seat,
  //   - a tile of mine is mine, any other tile is not,
  //   - ups() lists my playable tiles only on my turn.
  // Once exactly one s0 fits, every play, every hand size and the next seat follow.
  function resolveSeats() {
    if (G.evs.length === 0) return;
    const me = G.myWh;
    const fits = (s0, useMarks) => G.evs.every((e, i) => {
      const seat = (s0 + i) % 4;
      if (e.k === "pass") return seat === e.who;
      if (me === null) return true;
      return e.mine ? seat === me : seat !== me;
    }) && (!useMarks || me === null || [...G.marks].every(m => (s0 + m) % 4 === me));
    let cands = [0, 1, 2, 3].filter(s0 => fits(s0, true));
    if (cands.length === 0) cands = [0, 1, 2, 3].filter(s0 => fits(s0, false));
    G.counts = [0, 0, 0, 0];
    G.players = [];
    if (cands.length !== 1) { G.turn = null; G.openerSeat = null; return; }
    const s0 = cands[0];
    G.evs.forEach((e, i) => {
      if (e.k !== "put") return;
      const seat = (s0 + i) % 4;
      G.counts[seat]++;
      G.players.push(seat);
    });
    G.turn = (s0 + G.evs.length) % 4;
    if (G.openerSeat !== s0) { G.openerSeat = s0; console.log("[CDA] opener: seat", s0); }
  }

  function recordPut(id, par, to, side) {
    const tile = [par[0], par[1]];
    G.evs.push({ k: "put", mine: G.myIds.has(id) });
    G.evAt.push(Date.now());
    G.played.push(tile);
    resolveSeats();
    if (G.myIds.has(id)) {
      const k = tk(tile);
      G.hand = G.hand.filter(t => tk(t) !== k);
      G.lastHandIds.delete(String(id));
    }
    // Board ends
    if (!G.endInfo) {
      G.endInfo = [{ id, v: tile[0], t: tile }, { id, v: tile[1], t: tile }];
      G.matched.push(null);
    } else {
      let matchedVal = null;
      const fits = (e) => e.v === tile[0] || e.v === tile[1];
      let cand = [0, 1].filter(i => G.endInfo[i].id === to && fits(G.endInfo[i]));
      if (cand.length === 0) cand = [0, 1].filter(i => fits(G.endInfo[i]));
      if (cand.length > 0) {
        const i = cand.length > 1 ? (side === "y0" ? 0 : 1) : cand[0];
        const v = G.endInfo[i].v;
        matchedVal = v;
        G.endInfo[i] = { id, v: tile[0] === v ? tile[1] : tile[0], t: tile };
      }
      G.matched.push(matchedVal);
    }
    G.ends = G.endInfo ? [G.endInfo[0].v, G.endInfo[1].v] : [];
    verifySideChoice(tile);
    scheduleBroadcast(60);
  }

  // The hand so far as an exact, ordered record: who played each tile (and which end it went on) and who
  // passed, in sequence. adapter.js uses it instead of guessing the attribution. null while the opener is
  // not yet certain.
  function buildSeq() {
    if (G.openerSeat === null || G.openerSeat === undefined || G.matched.length !== G.played.length) return null;
    const out = [];
    let putIdx = 0;
    G.evs.forEach((e, i) => {
      const seat = (G.openerSeat + i) % 4;
      if (e.k === "pass") out.push({ k: "pass", seat });
      else out.push({ k: "put", seat, matched: G.matched[putIdx++] });
    });
    return out;
  }

  // Think times, LOGGING ONLY (not used by the engine): for every play/pass by another player, the time from the
  // previous play/pass (when it became his turn) to his own. Includes the game's animation, so it is only a
  // measurement to check against real logs. My own seat is never reported. null while seats are not certain.
  function thinkReport() {
    if (G.openerSeat === null || G.openerSeat === undefined || G.myWh === null) return null;
    const out = [];
    for (let i = 1; i < G.evs.length; i++) {
      const seat = (G.openerSeat + i) % 4;
      if (seat === G.myWh) continue;
      out.push({ seat, k: G.evs[i].k, ms: G.evAt[i] - G.evAt[i - 1] });
    }
    return out;
  }

  // Hand sizes per label, exact, once my seat is known. Next to play = "opponentRight".
  function exactSizes() {
    if (G.myWh === null) return null;
    const left = (seat) => 10 - G.counts[seat % 4];
    return {
      opponentRight: left(G.myWh + 1),
      partner:       left(G.myWh + 2),
      opponentLeft:  left(G.myWh + 3),
    };
  }

  // ── Wait for LUDO.CartasDomino ────────────────────────────────────────────
  let attempts = 0;
  (function tryPatch() {
    if (window.LUDO && typeof window.LUDO.CartasDomino === "function") {
      patch();
    } else {
      // Lobby pages (e.g. /jugar) have no game table, so this is not an error: poll fast for the
      // first minute (game page loading), then slowly, without reporting a failure.
      setTimeout(tryPatch, ++attempts < 1200 ? 50 : 2000);
    }
  })();

  function patch() {
    const Orig = window.LUDO.CartasDomino;

    window.LUDO.CartasDomino = function (t, e, o) {
      const keyj = (e && e.keyj) || "";
      const isDomino = keyj.startsWith("domino") || keyj.includes("garrafina");
      const inst = new Orig(t, e, o);
      if (!isDomino) return inst;

      G.t    = t;
      G.inst = inst;
      window._ludoT        = t;
      window._ludoInstance = inst;

      // ── Tile ID → nums map ───────────────────────────────────────────────
      // ht[] is a closure variable — Object.keys(inst) will NEVER find it.
      // Instead we build our own id→nums map by intercepting inst.event,
      // which receives {tell:[{id, par:[v1,v2]},...]} when tiles are dealt.
      window._cdaHt    = null;  // kept for fallback compatibility
      window._cdaNums  = {};    // id → [v1,v2] built from event hook

      post({ type: "HOOK_SUCCESS", gameKey: keyj });
      // Logging only (Android port): the table object's names, to learn where the game keeps its tile elements
      // (for the ring around the recommended tile). See README "First live session".
      try {
        const names = (o) => { try { return Object.getOwnPropertyNames(o).slice(0, 120).join(","); } catch (e) { return "?"; } };
        post({ type: "TABLE_KEYS", t: names(t), proto: names(Object.getPrototypeOf(t)), inst: names(inst) });
      } catch (e) {}

      // ── inst.event — fired for every game event including tile deals ──────
      // When tiles are dealt, event receives { tell: [{id, par:[v1,v2]}, ...] }
      const origEvent = inst.event;
      if (typeof origEvent === "function") {
        inst.event = function (data, cb) {
          try { handleGameEvent(data); } catch (e) { console.warn("[CDA] event parse error:", e); }
          if (data && Array.isArray(data.tell)) {
            for (const entry of data.tell) {
              if (entry && typeof entry.id === "number" &&
                  Array.isArray(entry.par) && entry.par.length === 2) {
                window._cdaNums[entry.id] = [entry.par[0], entry.par[1]];
              }
            }
            scheduleBroadcast(200);
          }
          return origEvent.apply(this, arguments);
        };
      }

      // ── setPlayables — fires every time it's someone's turn ────────────
      const origSP = inst.setPlayables;
      if (typeof origSP === "function") {
        inst.setPlayables = function (...args) {
          const r = origSP.apply(this, args);
          scheduleBroadcast(80);
          return r;
        };
      }

      // ── setAheads — fires when hand counts change ─────────────────────────
      const origSA = inst.setAheads;
      if (typeof origSA === "function") {
        inst.setAheads = function (aheads, ...args) {
          const r = origSA.apply(this, [aheads, ...args]);
          console.log("[CDA] setAheads:", JSON.stringify(aheads));
          parseAheads(aheads);
          scheduleBroadcast(100);
          return r;
        };
      }

      // ── filmObject — fires on tile animation ──────────────────────────────
      const origFilm = inst.filmObject;
      if (typeof origFilm === "function") {
        inst.filmObject = function (film, ...args) {
          const r = origFilm.apply(this, [film, ...args]);
          // (board/hand state now comes from handleGameEvent, not from film heuristics)
          scheduleBroadcast(150);
          return r;
        };
      }

      // ── startPlaying / reset: new round ──────────────────────────────────
      const origStart = inst.startPlaying;
      if (typeof origStart === "function") {
        inst.startPlaying = function (...args) {
          const r = origStart.apply(this, args);
          resetRound();
          // Delay hand capture — give Ludoteka time to fire event.tell
          // with the new deal before we try to read tile nums
          setTimeout(captureInitialHand, 500);
          return r;
        };
      }

      const origReset = inst.reset;
      if (typeof origReset === "function") {
        inst.reset = function (...args) {
          const r = origReset.apply(this, args);
          resetRound();
          setTimeout(captureInitialHand, 500);
          return r;
        };
      }

      // ── Polling: re-read state every 5s as safety net only ───────────────
      // Only fires if something actually changed (checked in doBroadcast).
      // Hooks on inst.* may never fire if the game calls its own closure functions,
      // so poll ups() fast and broadcast immediately when the turn state changes.
      setInterval(() => {
        if (_dead || !G.t) return;
        let ids = [];
        try { ids = G.t.ups() || []; } catch (e) { return; }
        const sig = JSON.stringify(ids);
        if (sig !== G._lastUpsSig) {
          console.log("[CDA] ups() changed:", sig.length > 80 ? "(" + ids.length + " ids)" : sig);
          G._lastUpsSig = sig;
          scheduleBroadcast(30);
        }
      }, 250);
      setInterval(() => scheduleBroadcast(0), 5000);

      captureInitialHand();
      scheduleBroadcast(800);
      return inst;
    };

    Object.assign(window.LUDO.CartasDomino, Orig);
    window.LUDO.CartasDomino.prototype = Orig.prototype;
    post({ type: "PATCH_READY" });
  }

  // ── Throttled broadcast ───────────────────────────────────────────────────
  let broadcastTimer = null;
  function scheduleBroadcast(delay) {
    if (_dead) return;
    if (broadcastTimer) clearTimeout(broadcastTimer);
    broadcastTimer = setTimeout(doBroadcast, delay);
  }

  // ── Hand capture ─────────────────────────────────────────────────────────
  // The hand now arrives via the deal's {tell} event (handleGameEvent). ups() only lists
  // the *playable* tiles on my turn, so it must never be treated as the whole hand.
  function captureInitialHand() { /* intentionally a no-op */ }

  // My seat = whoever's turn it is when ups() lists playable tiles.
  function noteMyTurn(realIds) {
    if (G.myWh === null && G.turn !== null && realIds.length > 0 && realIds.length <= 10) {
      G.myWh = G.turn;
      console.log("[CDA] My seat:", G.myWh);
    }
    // ups() lists my tiles only on my turn: after the first tile that pins down the opener.
    // (Before any tile, both teammates may be offered the opening move, so it proves nothing.)
    if (G.myWh !== null && G.evs.length >= 1 && !G.marks.has(G.evs.length)) {
      G.marks.add(G.evs.length);
      resolveSeats();
    }
  }

  function doBroadcast() {
    broadcastTimer = null;
    if (_dead || !G.t) return;

    let ids = [];
    try { ids = G.t.ups() || []; } catch(e) { return; }

    const realIds = ids.filter(id => id !== "rnd" && id !== "pas");
    // During the tile-taking phase ups() lists the whole 55-tile pile, so cap at 10.
    const myTurn  = realIds.length > 0 && realIds.length <= 10;
    G.ids    = ids;
    G.myTurn = myTurn;
    if (myTurn) noteMyTurn(realIds);

    // Keep tiles and IDs index-aligned (ups() also holds "rnd"/"pas" markers and
    // idToTile can return null).
    const playableTiles = [];
    const playableIds   = [];
    if (myTurn) {
      for (const id of realIds) {
        const tl = idToTile(id);
        if (tl) { playableTiles.push(tl); playableIds.push(id); }
      }
    }

    const exact = exactSizes();
    post({
      type: "STATE_UPDATE",
      state: {
        active:        true,
        playerHand:    [...G.hand],
        initialHand:   G.initialHand ? G.initialHand.map(t => [t[0], t[1]]) : null,
        exact:         !!exact,
        playableTiles: playableTiles,
        playableIds:   playableIds,
        unknownTiles:  myTurn && playableTiles.length === 0,
        // start of a round: the game lists the whole pile plus the "rnd" (take my tiles) button
        canTake:       ids.includes("rnd") && realIds.length > 10,
        // my turn with nothing to play: the game offers only its pass marker (mobile button shows "pass")
        mustPass:      ids.includes("pas") && realIds.length === 0,
        boardEnds:     [...G.ends],
        // the tile at each end, laid out as on the table: left end [exposed, inner], right end [inner, exposed]
        boardEndTiles: G.endInfo ? G.endInfo.map((e, i) => {
                         const inner = e.t[0] === e.v ? e.t[1] : e.t[0];
                         return i === 0 ? [e.v, inner] : [inner, e.v];
                       }) : [],
        playedHistory: [...G.played],
        handSizes:     exact || { ...G.sizes },
        myTurn,
        roundReset:    false,
        seat:          window._cdrO ?? 0,
        mySeat:        G.myWh,
        seq:           buildSeq(),
        goal:          G.goal || null,
        scores:        (G.totals && G.myWh !== null)
                         ? { myTeam: G.totals[G.myWh % 2], opponentTeam: G.totals[1 - (G.myWh % 2)] }
                         : null,
        passes:        G.passes.map(p => ({ who: p.who, ends: [...p.ends] })),
      }
    });
  }


  // ── Extract board info from filmObject data ───────────────────────────────
  // When a tile is played, filmObject receives data about it.
  // We try to detect played tiles and update board ends.
  function extractFromFilm(film) {
    try {
      const items = Array.isArray(film) ? film : [film];
      for (const item of items) {
        if (!item || typeof item !== "object") continue;

        // If item has .nums, it's a tile being animated (played or dealt)
        if (Array.isArray(item.nums) && item.nums.length === 2) {
          const tile = [item.nums[0], item.nums[1]];
          const k = tk(tile);

          // If this tile ID was in our hand and is now being animated,
          // it's likely being played — remove from hand
          for (const key of ["num","id","toki"]) {
            if (item[key] !== undefined) {
              const sid = String(item[key]);
              if (G.lastHandIds.has(sid)) {
                G.hand = G.hand.filter(t => tk(t) !== k);
                G.lastHandIds.delete(sid);
              }
            }
          }

          // Track board history — if this tile appears to be going to the board
          // (heuristic: it has a position/zona property suggesting board placement)
          if (item.zona !== undefined || item.board === true || item.jugado === true) {
            if (!G.played.some(t => tk(t) === k)) {
              G.played.push(tile);
              updateEnds(tile);
            }
          }
        }

        // Recurse into nested arrays
        for (const key of ["tiles","fichas","items","carta"]) {
          if (Array.isArray(item[key])) item[key].forEach(extractFromFilm);
        }
      }
    } catch(e) {}
  }

  // ── Update board ends after a tile is played ──────────────────────────────
  function updateEnds(tile) {
    if (G.ends.length === 0) {
      G.ends = tile[0] === tile[1] ? [tile[0], tile[0]] : [tile[0], tile[1]];
      return;
    }
    const [a, b] = tile;
    const [left, right] = G.ends;
    if (a === left)       G.ends[0] = b;
    else if (b === left)  G.ends[0] = a;
    else if (a === right) G.ends[1] = b;
    else if (b === right) G.ends[1] = a;
  }

  // ── Read hand sizes from DOM ──────────────────────────────────────────────
  // Ludoteka renders the number of tiles per player visually.
  // We search for small numeric text elements near player names.
  function readHandSizesFromDOM() {
    // Try zonabuts — Ludoteka has "zonabuts-i/c/d/r/m" zones per player
    // The score/ahead counters are often in elements with ids like "ah-1", "ah-2"
    // or in canvas siblings. Let's try all short numeric text elements.
    if (G.domSizesFound) return; // once we find them, we trust them

    // Look for elements with id containing "ah", "ahead", "cuenta", "nt"
    const selectors = ["[id^='ah-']","[id^='nt-']","[id*='ahead']","[id*='cuenta']","[id*='nfichas']"];
    for (const sel of selectors) {
      const els = document.querySelectorAll(sel);
      if (els.length >= 3) {
        console.log("[CDA] Found size elements via", sel, ":", [...els].map(e => e.id + "=" + e.textContent.trim()));
        // Map to players — seats 1,2,3 = left,partner,right
        // Try to parse and assign
        parseCountElements([...els]);
        return;
      }
    }

    // Fallback: scan ALL elements with id for ones showing 1-10
    // but log only once
    if (!G._domScanLogged) {
      G._domScanLogged = true;
      const hits = [];
      document.querySelectorAll("[id]").forEach(el => {
        const txt = el.textContent.trim();
        if (/^\d+$/.test(txt) && +txt >= 1 && +txt <= 10 && el.children.length === 0) {
          hits.push(el.id + "=" + txt);
        }
      });
      if (hits.length > 0 && hits.length < 40) {
        console.log("[CDA] Numeric DOM elements (hand count candidates):", hits.join(", "));
      }
    }
  }

  function parseCountElements(els) {
    // Sort by id to get consistent seat order
    els.sort((a, b) => a.id.localeCompare(b.id));
    const counts = els.map(el => parseInt(el.textContent.trim())).filter(n => !isNaN(n) && n >= 0 && n <= 10);
    if (counts.length >= 3) {
      G.sizes.opponentLeft  = counts[0];
      G.sizes.partner       = counts[1];
      G.sizes.opponentRight = counts[2];
      G.domSizesFound = true;
    }
  }

  // ── Parse setAheads ───────────────────────────────────────────────────────
  function parseAheads(a) {
    if (!a || (Array.isArray(a) && a.length === 0)) return;
    try {
      if (Array.isArray(a) && a.length >= 4) {
        G.sizes.opponentLeft  = num(a[1]);
        G.sizes.partner       = num(a[2]);
        G.sizes.opponentRight = num(a[3]);
      } else if (Array.isArray(a) && a.length === 3) {
        G.sizes.opponentLeft  = num(a[0]);
        G.sizes.partner       = num(a[1]);
        G.sizes.opponentRight = num(a[2]);
      } else if (typeof a === "object" && !Array.isArray(a)) {
        const vals = Object.values(a).map(num).filter(n => n !== null);
        if (vals.length >= 3) {
          [G.sizes.opponentLeft, G.sizes.partner, G.sizes.opponentRight] = vals;
        }
      }
    } catch(e) {}
  }

  function num(v) {
    if (typeof v === "number") return v;
    if (v && typeof v === "object") return v.n ?? v.count ?? v.tiles ?? null;
    return null;
  }

  // ── Reset round ───────────────────────────────────────────────────────────
  function resetRound() {
    G.hand   = [];
    G.played = [];
    G.ends   = [];
    G.sizes  = { partner: null, opponentLeft: null, opponentRight: null };
    G.ids    = [];
    G.myTurn = false;
    G.lastHandIds    = new Set();
    G.turn = null; G.counts = [0,0,0,0]; G.players = []; G.endInfo = null;
    G.myIds = new Set(); G.initialHand = null; G.pendingPut = null;  // G.myWh is kept: my seat never changes
    G.takes = {}; G.evs = []; G.evAt = []; G.marks = new Set(); G.openerSeat = null; G.passes = []; G.matched = [];
    // The lead event can arrive just before {chas}; keep it if it is fresh.
    if (G.lastLead && Date.now() - G.lastLead.at < 5000) G.turn = G.lastLead.who;
    G.domSizesFound  = false;
    G._domScanLogged = false;
    // Clear tile num map so stale data from previous round doesn't
    // bleed into the new deal — captureInitialHand will repopulate
    // once the new event.tell fires
    window._cdaNums = {};
    window._cdaRecoveryNeeded = false;
    post({ type: "ROUND_RESET" });
    console.log("[CDA] Round reset — waiting for new deal");
  }

  // ── Which-end prompt ──────────────────────────────────────────────────────
  // When a tile fits both (different) board ends, marking it makes ups() return two options
  // ["<tileId>-<pip>", "<tileId>-<pip>"] and the user must pick one. We answer it with the end the
  // engine chose (`matched` = the board-end value the tile attaches to).
  // Whether <pip> means "the pip that touches the board" or "the pip left showing" is not documented,
  // so the first auto-pick is verified against the board (see recordPut); if it came out reversed we
  // flip the convention and remember it.
  let flipSide = false;
  try { flipSide = localStorage.getItem("cdaFlipSide") === "1"; } catch (e) {}
  let sideCheck = null;
  let playCheck = null;   // the auto-play being verified (watchPlay)

  function answerSidePrompt(tileId, tile, matched) {
    if (matched === null || matched === undefined || !Array.isArray(tile)) return;
    const other = tile[0] === matched ? tile[1] : tile[0];
    let tries = 0;
    (function poll() {
      let ups = [];
      try { ups = G.t.ups() || []; } catch (e) {}
      const isPrompt = ups.length === 2 && ups.every(s => typeof s === "string" && s.indexOf(tileId + "-") === 0);
      if (isPrompt) {
        const wanted = flipSide ? other : matched;
        const opt = ups.find(s => parseInt(s.split("-")[1], 10) === wanted);
        if (!opt) return;
        sideCheck = { tile, matched, other, endsBefore: [...G.ends] };
        console.log("[CDA] End prompt: choosing", opt, "(attach to end " + matched + ")");
        // a short human pause before clicking the end
        const wait = 250 + Math.random() * 350;
        if (playCheck && playCheck.tileId === tileId) playCheck.deadline = Date.now() + wait + 1000;   // the second click restarts the 1 s check
        setTimeout(() => {
          try { G.t.mark(opt); } catch (e) { console.warn("[CDA] end choice failed:", e); }
        }, wait);
        return;
      }
      if (++tries < 25) setTimeout(poll, 100);   // no prompt appears when only one end fits
    })();
  }

  function verifySideChoice(tile) {
    const c = sideCheck;
    if (!c || tk(tile) !== tk(c.tile)) return;
    sideCheck = null;
    const exp = [...c.endsBefore];
    const i = exp.indexOf(c.matched);
    if (i < 0) return;
    exp[i] = c.other;
    const same = exp.slice().sort().join() === [...G.ends].sort().join();
    if (same) return;
    flipSide = !flipSide;
    try { localStorage.setItem("cdaFlipSide", flipSide ? "1" : "0"); } catch (e) {}
    console.warn("[CDA] End choice came out reversed — flipping convention for next time (flip=" + flipSide + ")");
  }

  // ── Did the auto-play land? (Android port) ─────────────────────────────────
  // After the bot's click, the tile must leave the playable list (or reach the board) within 1 s of the last click
  // (the end choice counts as a click). Otherwise content.js switches AUTO off and asks the user to play by hand.
  function watchPlay(tileId, tile) {
    const startLen = G.played.length;
    playCheck = { tileId, deadline: Date.now() + 1000 };
    const me = playCheck;
    (function poll() {
      if (playCheck !== me) return;
      let ups = [];
      try { ups = G.t.ups() || []; } catch (e) {}
      const pending = ups.includes(tileId) || ups.some((s) => typeof s === "string" && s.indexOf(tileId + "-") === 0);
      if (G.played.length > startLen || !pending) { playCheck = null; post({ type: "PLAY_RESULT", ok: true, tile }); return; }
      if (Date.now() > me.deadline) { playCheck = null; post({ type: "PLAY_RESULT", ok: false, tile }); return; }
      setTimeout(poll, 100);
    })();
  }

  // ── Where my tiles are drawn (Android port, best effort) ───────────────────
  // The game keeps its tile objects in closures, so this looks through the table object and the game instance
  // (two levels deep) for a collection indexed by tile id whose entries carry a DOM element. Returns
  // { id: {x, y, w, h} } in viewport pixels for the tiles found, or null. The collection that worked is remembered.
  let handPath = null;
  function domOf(v, depth) {
    if (!v || typeof v !== "object") return null;
    if (v instanceof Element) return v;
    if (v.jquery && v[0] instanceof Element) return v[0];
    if (depth > 0) for (const k of ["el", "div", "dom", "elem", "$el", "obj", "img", "node", "jq"]) {
      const d = domOf(v[k], depth - 1);
      if (d) return d;
    }
    return null;
  }
  function entryFor(coll, id) {
    if (!coll || typeof coll !== "object") return null;
    let e = null;
    try { e = coll[id]; } catch (x) {}
    if (e && typeof e === "object" && (e.id === undefined || e.id === id)) return e;
    if (Array.isArray(coll)) return coll.find((x) => x && typeof x === "object" && x.id === id) || null;
    return null;
  }
  function rectsFrom(coll, ids) {
    const out = {};
    let n = 0;
    for (const id of ids) {
      const el = domOf(entryFor(coll, id), 2);
      if (!el) continue;
      const r = el.getBoundingClientRect();
      if (r.width < 4 || r.height < 4) continue;
      out[id] = { x: r.left, y: r.top, w: r.width, h: r.height, tile: idToTile(id) };
      n++;
    }
    return { out, n };
  }
  function locateHand(ids) {
    if (!ids.length) return null;
    const roots = [["t", G.t], ["inst", G.inst]];
    const get = (path) => path.reduce((o, k) => (o ? o[k] : null), { t: G.t, inst: G.inst });
    if (handPath) {
      const r = rectsFrom(get(handPath), ids);
      if (r.n) return r.out;
    }
    let best = null;
    for (const [rk, root] of roots) {
      if (!root) continue;
      let keys = [];
      try { keys = Object.keys(root); } catch (e) {}
      for (const k of keys) {
        let v = null;
        try { v = root[k]; } catch (e) {}
        if (!v || typeof v !== "object" || v instanceof Element) continue;
        const cands = [[[rk, k], v]];
        try { for (const k2 of Object.keys(v).slice(0, 80)) { const v2 = v[k2]; if (v2 && typeof v2 === "object" && !(v2 instanceof Element)) cands.push([[rk, k, k2], v2]); } } catch (e) {}
        for (const [path, coll] of cands) {
          const r = rectsFrom(coll, ids);
          if (r.n && (!best || r.n > best.n)) best = { path, ...r };
        }
      }
    }
    if (!best || best.n < Math.ceil(ids.length / 2)) return null;
    handPath = best.path;
    console.log("[CDA] hand tiles found at", handPath.join("."));
    return best.out;
  }

  // ── Play tile / recovery commands ────────────────────────────────────────
  window.addEventListener("message", (evt) => {
    if (!evt.data || evt.data.source !== "LUDO_ADVISOR_CMD") return;

    // Primary: play by tile ID
    if (evt.data.type === "PLAY_TILE" && G.t) {
      try {
        console.log("[CDA injected] mark tileId:", evt.data.tileId);
        watchPlay(evt.data.tileId, evt.data.tile);
        G.t.mark(evt.data.tileId);
        answerSidePrompt(evt.data.tileId, evt.data.tile, evt.data.matched);
      } catch(e) {
        console.warn("[CDA injected] mark failed:", e);
      }
    }

    // Where my hand tiles are on screen (Android port: ring around the recommended tile, button placement)
    if (evt.data.type === "LOCATE_HAND" && G.t) {
      let rects = null;
      try { rects = locateHand(evt.data.ids || [...G.lastHandIds].map(Number)); } catch (e) {}
      post({ type: "HAND_RECTS", req: evt.data.req, rects });
    }

    // Start of a round: press the game's "take my tiles" (rnd) button
    if (evt.data.type === "TAKE_TILES" && G.t) {
      try {
        const ups = G.t.ups() || [];
        if (ups.includes("rnd")) {
          console.log("[CDA injected] taking my tiles (rnd)");
          G.t.mark("rnd");
        }
      } catch (e) {
        console.warn("[CDA injected] take tiles failed:", e);
      }
    }

    // Fallback: find tile by pip values
    if (evt.data.type === "FIND_AND_PLAY" && G.t) {
      try {
        const [n0, n1] = evt.data.nums;
        const ht = window._cdaHt;
        if (!ht) return;
        for (let i = 0; i < ht.length; i++) {
          const tile = ht[i];
          if (!tile || !Array.isArray(tile.nums)) continue;
          const [a, b] = tile.nums;
          if ((a === n0 && b === n1) || (a === n1 && b === n0)) {
            const ups = G.t.ups() || [];
            if (ups.includes(i) || ups.includes(tile.id)) {
              console.log("[CDA injected] fallback mark id:", i, "nums:", tile.nums);
              G.t.mark(i);
              break;
            }
          }
        }
      } catch(e) {
        console.warn("[CDA injected] FIND_AND_PLAY failed:", e);
      }
    }

    // Mid-game recovery: content.js has no hand data, try to rebuild it now
    if (evt.data.type === "REQUEST_HAND_RECOVERY") {
      return; // hand now comes from the deal event; nothing to recover
      const nums = window._cdaNums;
      if (!nums || Object.keys(nums).length === 0) return;

      // If hand is already captured, just broadcast current state
      if (G.hand && G.hand.length > 0) {
        scheduleBroadcast(50);
        return;
      }

      // Try to get current hand from ups() — on our turn this returns playable IDs
      // Off our turn it returns [] — but we can try to figure out which IDs are ours
      // by checking which IDs are NOT in the played history
      console.log("[CDA injected] Hand recovery requested, _cdaNums has",
        Object.keys(nums).length, "entries");

      // Attempt: poll ups() every 200ms — will succeed when it becomes our turn
      // Meanwhile broadcast with empty hand so panel shows "active" state
      captureInitialHand();
      scheduleBroadcast(100);
    }
  });

})();

// license.js — the activation lock of the Firefox (Android) build. On first use this device gets a random code
// (storage "cdaDeviceId"); the advisor works only after the activation key made for that code is entered (storage
// "cdaLicense"). The key is an ECDSA P-256 signature checked with the public key in license-pubkey.js; keys are made on
// the owner's PC with tools/license.mjs. Until then content.js gives no advice and never plays. The Chrome build is
// never locked. Uninstalling the add-on (or clearing its data) gives the device a new code, which needs a new key.
(function () {
  "use strict";
  const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";   // no I, O, 0, 1 (easy to read aloud and type)
  const MESSAGE = (id) => "cda-android|v1|" + id;

  const required = window.CDA_BUILD === "firefox";
  const L = { required, ok: !required, deviceId: null, ready: null, listeners: [] };   // ok = valid key and not deactivated
  const notify = () => { for (const f of L.listeners) { try { f(L); } catch (e) {} } };
  L.onChange = (f) => L.listeners.push(f);
  L.code = () => (L.deviceId ? L.deviceId.slice(0, 4) + "-" + L.deviceId.slice(4) : "");

  function newId() {
    const b = crypto.getRandomValues(new Uint8Array(8));
    return Array.from(b, (x) => ALPHABET[x % 32]).join("");
  }
  function b64urlBytes(s) {
    const bin = atob(s.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((s.length + 3) % 4));
    return Uint8Array.from(bin, (c) => c.charCodeAt(0));
  }
  async function verify(id, key) {
    try {
      const k = String(key || "").replace(/\s+/g, "");
      if (!id || !/^CDA1\.[A-Za-z0-9_-]{80,90}$/.test(k) || !window.CDA_LICENSE_PUBKEY) return false;
      const sig = b64urlBytes(k.slice(5));
      if (sig.length !== 64) return false;
      const pub = await crypto.subtle.importKey("jwk", window.CDA_LICENSE_PUBKEY, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
      return await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, pub, sig, new TextEncoder().encode(MESSAGE(id)));
    } catch (e) {
      return false;
    }
  }

  // ── Deactivation: the owner's list of switched-off device codes (a GitHub gist, CDA_REVOCATION_URL in
  // license-pubkey.js), read through background.js when Ludoteka opens and every 30 minutes. A device on the list is
  // locked even with a valid key, and stays locked offline (storage "cdaRevoked") until the owner takes it off the list.
  L.keyOk = false;
  L.revoked = false;
  const recompute = () => { L.ok = !required || (L.keyOk && !L.revoked); };
  function checkRevoked() {
    if (!required || !window.CDA_REVOCATION_URL || !L.deviceId) return;
    try {
      chrome.runtime.sendMessage({ action: "cdaRevoked", url: window.CDA_REVOCATION_URL }, (resp) => {
        try { void chrome.runtime.lastError; } catch (e) {}
        if (!resp || !resp.ok || !Array.isArray(resp.list)) return;   // no answer (offline): keep the last known state
        const now = resp.list.map((c) => String(c).toUpperCase().replace(/[^A-Z0-9]/g, "")).includes(L.deviceId);
        if (now === L.revoked) return;
        L.revoked = now;
        try { chrome.storage.local.set({ cdaRevoked: now }); } catch (e) {}
        recompute();
        notify();
      });
    } catch (e) {}
  }

  // Enter a key: true if it is the key for this device (then it is kept and the advisor unlocks, unless deactivated).
  L.activate = async (key) => {
    const good = await verify(L.deviceId, key);
    if (good) {
      L.keyOk = true;
      recompute();
      try { chrome.storage.local.set({ cdaLicense: String(key).replace(/\s+/g, "") }); } catch (e) {}
      notify();
      checkRevoked();
    }
    return good;
  };

  L.ready = !required ? Promise.resolve(L) : new Promise((resolve) => {
    try {
      chrome.storage.local.get(["cdaDeviceId", "cdaLicense", "cdaRevoked"], (r) => {
        let id = r && typeof r.cdaDeviceId === "string" && r.cdaDeviceId.length === 8 ? r.cdaDeviceId : null;
        if (!id) { id = newId(); try { chrome.storage.local.set({ cdaDeviceId: id }); } catch (e) {} }
        L.deviceId = id;
        L.revoked = !!(r && r.cdaRevoked);
        verify(id, r && r.cdaLicense).then((good) => {
          L.keyOk = good;
          recompute();
          notify();
          resolve(L);
          checkRevoked();
          setInterval(checkRevoked, 30 * 60 * 1000);
        });
      });
    } catch (e) { resolve(L); }
  });

  window.CDA_LICENSE = L;
})();

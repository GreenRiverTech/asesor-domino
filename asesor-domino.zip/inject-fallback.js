// inject-fallback.js — Firefox build only. injected.js normally runs as a MAIN-world content script (Firefox 128+).
// If it did not (the page has no data-cda-hook mark), add it as a <script> tag so it still runs in the page's own
// context before the game is built. injected.js runs only once per page either way.
(function () {
  function check() {
    if (document.documentElement.hasAttribute("data-cda-hook")) return;
    try {
      const s = document.createElement("script");
      s.src = chrome.runtime.getURL("injected.js");
      s.onload = () => s.remove();
      (document.head || document.documentElement).appendChild(s);
      console.log("[CDA] MAIN-world script missing: injected.js added as a <script> tag");
    } catch (e) {
      console.warn("[CDA] could not add injected.js:", e);
    }
  }
  if (document.documentElement.hasAttribute("data-cda-hook")) return;
  setTimeout(check, 0);   // give the MAIN-world copy its turn first
})();

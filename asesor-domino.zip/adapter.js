// adapter.js — bridges the extension's page state to the Cuban domino engine (global CDE).
//
// The old pipeline guessed who played each tile from turn order alone (wrong after any pass) and
// threw away which end each tile went on. This adapter rebuilds the full event list instead:
//   • who played each tile, using per-player hand-size budgets (10 − tiles left) plus legality
//   • passes in between (so turn order and "pasado" inference stay correct)
//   • which end each tile was played on
// then hands the engine a normal player view. This file only converts page data into the engine's input;
// it holds no strategy of its own except the last-resort fallback below.
//
// A turn must never be left without a recommendation (the game's turn clock would play for us), so the
// reconstruction has three layers, tried in this order:
//   1. exactSolution()   — the exact ordered play/pass record kept by injected.js (state.seq)
//   2. solve()           — search-based attribution from hand-size budgets, used if (1) is missing or inconsistent
//   3. fallbackRecommend() — a plain legal-move heuristic (heaviest playable tile), used if the engine cannot decide
//
// Seats are RELATIVE to you: 0 = you, 1 = next to play, 2 = partner, 3 = previous player.
(function () {
  "use strict";

  const key = (t) => Math.min(t[0], t[1]) + "," + Math.max(t[0], t[1]);
  const LABELS = ["partner", "opponentLeft", "opponentRight"];

  // Engines the extension carries (both bundles are loaded; each defines its own global). "v0.9" is the main one;
  // "v0.5" is the earlier engine, rebuilt from its own source under the name CDE05 so the two can be compared live.
  // "v0.5s" = v0.5 + the "strong numbers and doubles" rule (built from the user's hands, 2026-10-06), global CDE05S.
  const ENGINES = { "v0.9": "CDE", "v0.5": "CDE05", "v0.5s": "CDE05S" };

  // The book references inside a criterion's brackets (§4.1.3, p.42, E-4.35, Ch.6), for the mobile details card.
  // The reason text itself is unchanged (the log and the review tools read it).
  const bookRef = (criterion) => (String(criterion).match(/§[\d.\-]+\d|(?<![A-Za-z])(?:p\.\s?\d+|E-\d+(?:\.\d+)*|Ch\.\s?\d+)/g) || []).join(", ");

  const scoresArray = (state) => (state.scores && state.scores.myTeam != null ? [state.scores.myTeam, state.scores.opponentTeam] : null);

  class CdaAdapter {
    constructor() {
      this.orient = "O1"; // O1: next player = "opponentRight" (content.js convention); O2: next = "opponentLeft"
      this.votes = { O1: 0, O2: 0 };
      this.level = "high";
      this.samples = 64;
      this.scoring = "losingPair";   // how Ludoteka scores a finished hand (engine RuleConfig.scoring) - see dev/RESULTS.md
      this.partnerTrust = 1;   // engine v0.5+: how much to rely on the partner (0.6-1.4); 1 = the book's default, nothing sets it yet
      this.engineVersion = "v0.5";   // which engine decides (content.js sets it per match: see "Engine" in the panel)
      this.rollouts = 400;   // "expert" plays the hand out this many times per option (the engine default, 24, is too noisy)
      this.resetHand();
      this.onVote = null;
    }

    resetHand() {
      this.initialHand = null;
      this.prevHistLen = 0;
      this.prevSizes = null;
      this.lastLabel = null;
      this.lastLabelIdx = -2;
      this.prevSol = [];
      this.locks = [];
      this.lastPalo = null;
      this.lastLikely = null;
      this.cache = null;
      this.diag = { ok: true, msg: "" };
    }

    // The bundles declare `var CDE05` / `var CDE05S`. In Chrome those are also window.CDE05, but in a Firefox content
    // script `window` is a wrapper around the page window and does not see them, so they are looked up by name.
    engine() {
      const byName = {
        CDE05: typeof CDE05 !== "undefined" ? CDE05 : window.CDE05,
        CDE05S: typeof CDE05S !== "undefined" ? CDE05S : window.CDE05S,
        CDE: typeof CDE !== "undefined" ? CDE : window.CDE,
      };
      return byName[ENGINES[this.engineVersion]] || byName.CDE05;
    }
    setEngine(v) {
      if (!ENGINES[v] || v === this.engineVersion) return;
      this.engineVersion = v;
      this.cache = null;   // decisions from the other engine must not be reused
    }

    setOrientation(o) { if (o === "O1" || o === "O2") this.orient = o; }
    relOfLabel(label) {
      if (label === "partner") return 2;
      const o1 = this.orient === "O1";
      if (label === "opponentRight") return o1 ? 1 : 3;
      return o1 ? 3 : 1;
    }
    labelOfRel(rel) {
      if (rel === 2) return "partner";
      const o1 = this.orient === "O1";
      if (rel === 1) return o1 ? "opponentRight" : "opponentLeft";
      return o1 ? "opponentLeft" : "opponentRight";
    }

    // ── orientation learning ────────────────────────────────────────────────
    // Two consecutive tiles, each seen alone with exactly one hand size dropping, reveal the turn order:
    // partner→opponentLeft or opponentRight→partner means the cycle is me→Right→Partner→Left (O1);
    // partner→opponentRight or opponentLeft→partner means me→Left→Partner→Right (O2).
    learn(state, histLen, mineSet) {
      const s = state.handSizes || {};
      const p = this.prevSizes;
      if (!p || histLen !== this.prevHistLen + 1) return;
      if (!LABELS.every((l) => typeof s[l] === "number" && typeof p[l] === "number")) return;
      const dropped = LABELS.filter((l) => s[l] < p[l]);
      const t = state.playedHistory[histLen - 1];
      const mine = mineSet && mineSet.has(key(t));
      let label = null;
      if (mine) label = "me";
      else if (dropped.length === 1) label = dropped[0];
      if (!label) { this.lastLabel = null; return; }
      this.locks[histLen - 1] = label; // certain: exactly one hand shrank when this single tile appeared
      if (this.lastLabelIdx === histLen - 2 && this.lastLabel && this.lastLabel !== "me" && label !== "me") {
        const a = this.lastLabel, b = label;
        let v = null;
        if ((a === "partner" && b === "opponentLeft") || (a === "opponentRight" && b === "partner")) v = "O1";
        if ((a === "partner" && b === "opponentRight") || (a === "opponentLeft" && b === "partner")) v = "O2";
        if (v) {
          this.votes[v]++;
          if (this.votes.O2 >= this.votes.O1 + 2) this.orient = "O2";
          else if (this.votes.O1 >= this.votes.O2) this.orient = "O1";
          if (this.onVote) this.onVote(this.votes, this.orient);
        }
      }
      this.lastLabel = label;
      this.lastLabelIdx = histLen - 1;
    }

    // ── main entry ──────────────────────────────────────────────────────────
    // state: { playerHand, boardEnds, playedHistory, handSizes, myTurn }, scores: {myTeam, opponentTeam}
    update(state, scores) {
      const C = this.engine();
      if (!C) { this.diag = { ok: false, msg: "engine not loaded" }; return null; }
      const hist = state.playedHistory || [];
      const hand = state.playerHand && state.playerHand.length ? state.playerHand : state.playableTiles || [];
      if (hist.length < this.prevHistLen) this.resetHand();
      if (!this.initialHand && state.initialHand && state.initialHand.length) this.initialHand = new Set(state.initialHand.map(key));
      if (!this.initialHand && hand.length === 10 && hist.length === 0) this.initialHand = new Set(hand.map(key));
      const mineSet = this.initialHand;

      // exact seats (injected.js tracks the game's own event stream): next to play is always "opponentRight"
      if (state.exact) this.orient = "O1";
      else this.learn(state, hist.length, mineSet);
      const ck = hist.map(key).join("|") + "#" + hand.map(key).join("|") + "#" + (state.myTurn ? 1 : 0) + "#" + this.orient + "#" + this.level + "#" + this.engineVersion;
      this.prevHistLen = hist.length;
      this.prevSizes = { ...(state.handSizes || {}) };
      if (hand.length === 0) return null;
      if (this.cache && this.cache.key === ck) return this.cache.res;

      let res = null;
      try { res = this.recommend(state, hist, hand, mineSet, scores); } catch (e) { this.diag = { ok: false, msg: "adapter error: " + e.message }; }
      if (!res && state.myTurn && hand.length > 0) {
        // layer 3: the engine could not decide - never leave the turn empty
        const why = (this.diag && this.diag.msg) || "no recommendation";
        let fb = null;
        try { fb = this.fallbackRecommend(state, hand, why); } catch (e) { /* nothing legal known */ }
        if (fb) { res = fb; this.diag = { ok: true, msg: "fallback (" + why + ")", fallback: true }; }
      }
      this.cache = { key: ck, res };
      return res;
    }

    // What the engine knows about each hidden player: confirmed passes ("pasado") and, from sampled
    // deals, the numbers they probably do not hold. Runs after every play, not only on my turn.
    insight(view, hist, handIds) {
      const C = this.engine();
      const k = C.analyze(view);
      const voidsOf = (rel) => C.NUMBERS.filter((n) => k.voids[rel][n]);
      const fmt = (rel) => { const v = voidsOf(rel); return v.length ? `Pasado en: ${v.join(", ")}` : "Not pasado in any suit"; };
      const paloSeco = { partner: fmt(2) };
      paloSeco[this.labelOfRel(1)] = fmt(1);
      paloSeco[this.labelOfRel(3)] = fmt(3);

      // Likely fallos: how often a hidden player holds no tile of a number across many sampled deals
      // that respect everything known (confirmed passes, hand sizes, tiles seen, the stock of 15).
      const likely = {};
      try {
        const rng = new C.Rng(hist.length * 104729 + handIds.length * 31 + 17);
        const N = 240;
        const w = [0, 1, 2, 3].map(() => C.NUMBERS.map(() => 0));
        let wTot = 0;
        for (let i = 0; i < N; i++) {
          const dl = C.sampleDeal(k, rng);
          wTot += dl.weight;
          for (const rel of [1, 2, 3]) {
            for (const n of C.NUMBERS) if (!dl.hands[rel].some((id) => C.has(id, n))) w[rel][n] += dl.weight;
          }
        }
        const likelyOf = (rel) => C.NUMBERS
          .filter((n) => !k.voids[rel][n])
          .map((n) => ({ n, p: wTot > 0 ? w[rel][n] / wTot : 0 }))
          .sort((a, b) => b.p - a.p)
          .map((x) => ({ n: x.n, p: Math.round(x.p * 100) }));
        likely.partner = likelyOf(2);
        likely[this.labelOfRel(1)] = likelyOf(1);
        likely[this.labelOfRel(3)] = likelyOf(3);
      } catch (e) { /* the estimate is optional; the recommendation does not depend on it */ }
      this.lastPalo = paloSeco;
      this.lastLikely = likely;
      return { paloSeco, likely };
    }

    recommend(state, hist, hand, mineSet, scores) {
      const C = this.engine();
      const sizes = state.handSizes || {};
      const sizesKnown = LABELS.every((l) => typeof sizes[l] === "number");
      const handIds = hand.map((t) => C.T(t[0] + "-" + t[1]).id);

      let sol = { steps: [], trailing: [], L: null, R: null };
      const exactSol = this.exactSolution(state, hist);
      if (exactSol) {
        sol = exactSol;               // the extension knows every play and pass by seat: no guessing needed
      } else if (hist.length > 0) {
        if (!sizesKnown) { this.diag = { ok: false, msg: "hand sizes unknown" }; return null; }
        const rem = [0, 0, 0, 0];
        rem[0] = mineSet ? hist.filter((t) => mineSet.has(key(t))).length : 10 - hand.length;
        for (const l of LABELS) rem[this.relOfLabel(l)] = 10 - sizes[l];
        const total = rem.reduce((a, b) => a + b, 0);
        if (total !== hist.length || rem.some((x) => x < 0)) {
          this.diag = { ok: false, msg: `size/history mismatch (${total} vs ${hist.length})` };
          return null;
        }
        const obs = state.boardEnds && state.boardEnds.length === 2 ? state.boardEnds : null;
        sol = this.solve(hist, mineSet, rem, obs, true, state.myTurn) || this.solve(hist, mineSet, rem, obs, false, state.myTurn);
        if (!sol) { this.diag = { ok: false, msg: "could not attribute plays consistently" }; return null; }
        this.prevSol = sol.steps.map((s) => ({ p: s.p, side: s.side }));
      }

      // ---- build scenario text in book notation
      const toks = [];
      for (const st of sol.steps) {
        for (const q of st.passes) toks.push(`J${q + 1} pass`);
        const t = C.T(st.tile);
        if (st.matched == null) toks.push(`J${st.p + 1} ${t.id}`);
        else toks.push(`J${st.p + 1} ${C.numLabel(st.matched)}-${C.numLabel(C.other(t.id, st.matched))} @${st.side}`);
      }
      for (const q of sol.trailing) toks.push(`J${q + 1} pass`);
      const leader = sol.steps.length ? sol.steps[0].p : 0;
      const sc = scores && scores.myTeam != null && scores.opponentTeam != null ? [scores.myTeam, scores.opponentTeam] : [0, 0];
      const config = { scoring: this.scoring, targetPoints: state.goal || 100 };
      const view = C.scenarioView({ leader: `J${leader + 1}`, plays: toks.join(", "), hand: handIds, scores: sc, config });
      if (sizesKnown) for (const l of LABELS) view.tileCounts[this.relOfLabel(l)] = sizes[l];
      view.tileCounts[0] = handIds.length;

      // not my turn: only refresh what is known about the other players
      if (!state.myTurn) { this.insight(view, hist, handIds); return null; }

      const d = C.decide(view, { level: this.level, tempo: "uniform", samples: this.samples, rollouts: this.rollouts, partnerTrust: this.partnerTrust, seed: hist.length * 7919 + handIds.length });
      if (d.action.type !== "play") { this.diag = { ok: true, msg: "no legal tile" }; return null; }
      const tile = C.T(d.action.tile);
      const end = view.ends ? view.ends[d.action.side || "L"] : null;
      const matched = view.ends && d.action.side ? end.value : null;
      const { paloSeco } = this.insight(view, hist, handIds);

      const why = d.reasons.filter((r) => r.delta > 0).slice(0, 3).map((r) => r.criterion.replace(/\s*\(.*?\)\s*$/, "")).join("; ");
      let where = "";
      if (matched != null && view.ends.L.value !== view.ends.R.value) where = ` on the ${matched} end`;
      else if (matched != null) where = ` (either end: ${matched})`;
      this.diag = { ok: true, msg: "" };
      return {
        tile: [tile.hi, tile.lo],
        side: d.action.side || null,
        matched,
        explanation: `${tile.hi}-${tile.lo}${where}. ${why}`,
        // the top reasons with their book references (mobile details card)
        why: d.reasons.filter((r) => r.delta > 0).slice(0, 3).map((r) => ({ why: r.criterion.replace(/\s*\(.*?\)\s*$/, ""), ref: bookRef(r.criterion), delta: r.delta })),
        reasons: d.reasons,
        candidates: d.candidates.slice(0, 3).map((c) => ({ tile: c.move.tile, side: c.move.side, score: c.score })),
        paloSeco,
        // every option the engine weighed, with its score and the reasons behind it (for the decision log)
        options: d.candidates.map((c) => ({
          tile: c.move.tile,
          end: view.ends && c.move.side ? view.ends[c.move.side].value : null,
          score: c.score,
          reasons: c.reasons.map((r) => ({ why: r.criterion.replace(/\s*\(.*?\)\s*$/, ""), delta: r.delta, ref: bookRef(r.criterion) })),
        })),
        scores: view.scores || null,
        view,
      };
    }

    // Build the reconstruction straight from the exact record kept by injected.js (state.seq): who played
    // each tile, which end it went on, and who passed in between. Returns null if the record is missing or
    // does not fit the board, and then the search-based solve() below is used instead.
    exactSolution(state, hist) {
      const C = this.engine();
      const seq = state.seq;
      if (!Array.isArray(seq) || state.mySeat === null || state.mySeat === undefined) return null;
      if (seq.filter((e) => e.k === "put").length !== hist.length) return null;
      const rel = (seat) => (seat - state.mySeat + 4) % 4;
      const steps = [];
      let pending = [];
      let L = 0, R = 0, j = 0;
      for (const e of seq) {
        if (e.k === "pass") { pending.push(rel(e.seat)); continue; }
        const t = C.T(hist[j][0] + "-" + hist[j][1]);
        if (j === 0) {
          steps.push({ tile: t.id, p: rel(e.seat), side: null, matched: null, passes: pending });
          L = t.hi; R = t.lo;
        } else {
          const m = e.matched;
          if (m === null || m === undefined || !(t.hi === m || t.lo === m)) return null;
          const side = L === R ? "L" : m === L ? "L" : m === R ? "R" : null;
          if (!side) return null;
          const other = t.hi === m ? t.lo : t.hi;
          if (side === "L") L = other; else R = other;
          steps.push({ tile: t.id, p: rel(e.seat), side, matched: m, passes: pending });
        }
        pending = [];
        j++;
      }
      // the record must agree with what the page shows: same open ends, and the plays attributed to me
      // must be exactly the tiles of my own starting hand. Otherwise treat it as missing (-> solve()).
      const obs = state.boardEnds && state.boardEnds.length === 2 ? state.boardEnds : null;
      if (obs && [L, R].sort().join() !== [obs[0], obs[1]].sort().join()) return null;
      const mineSet = this.initialHand;
      if (mineSet && steps.some((st, i) => (st.p === 0) !== mineSet.has(key(hist[i])))) return null;
      return { steps, trailing: pending, L, R };
    }

    // Layer 3: a simple legal-move heuristic for when the reconstruction or the engine fails. Plays the heaviest
    // playable tile (doubles slightly preferred); on a tile that fits both ends it attaches where the number left
    // showing is the one I hold most of. Only tiles the game itself lists as playable are ever offered.
    fallbackRecommend(state, hand, why) {
      const playable = (state.playableTiles || []).filter((t) => Array.isArray(t));
      if (!playable.length) return null;
      const ends = state.boardEnds && state.boardEnds.length === 2 ? state.boardEnds : null;
      const held = (n, except) => hand.filter((u) => key(u) !== key(except) && (u[0] === n || u[1] === n)).length;
      const options = playable.map((t) => {
        let matched = null, bestHeld = -1;
        if (ends) {
          for (const e of new Set(ends)) {
            if (t[0] !== e && t[1] !== e) continue;
            const left = t[0] === e ? t[1] : t[0];
            const h = held(left, t);
            if (h > bestHeld) { bestHeld = h; matched = e; }
          }
        }
        return { tile: [Math.max(t[0], t[1]), Math.min(t[0], t[1])], matched, score: t[0] + t[1] + (t[0] === t[1] ? 1 : 0) };
      });
      options.sort((a, b) => b.score - a.score);
      const best = options[0];
      const where = best.matched != null && ends && ends[0] !== ends[1] ? ` on the ${best.matched} end` : "";
      return {
        tile: best.tile,
        side: null,
        matched: best.matched,
        explanation: `${best.tile[0]}-${best.tile[1]}${where}. Fallback: heaviest playable tile (${why}).`,
        why: [{ why: "fallback: heaviest playable tile", ref: "", delta: best.score }],
        reasons: [{ criterion: "fallback: heaviest playable tile", delta: best.score }],
        candidates: options.slice(0, 3).map((o) => ({ tile: o.tile.join("-"), side: null, score: o.score })),
        paloSeco: this.lastPalo || null,
        options: options.map((o) => ({ tile: o.tile.join("-"), end: o.matched, score: o.score, reasons: [{ why: "fallback: heaviest tile", delta: o.score }] })),
        scores: scoresArray(state),
        fallback: true,
        view: null,
      };
    }

    // Attribute every tile in `hist` to a player (relative seat), inferring passes in between.
    // Constraints: exact per-player tile budgets, the tile must fit the open ends, tiles from my own starting
    // hand are mine, I never pass while holding a playable tile, and the final ends match the board.
    solve(hist, mineSet, rem0, obsEnds, requireEnds, myTurn) {
      const C = this.engine();
      const n = hist.length;
      const ids = hist.map((t) => C.T(t[0] + "-" + t[1]));
      const mineFlag = ids.map((t, i) => (mineSet ? mineSet.has(key(hist[i])) : null));
      const myTiles = mineSet ? [...mineSet].map((k) => { const [a, b] = k.split(",").map(Number); return C.T(a + "-" + b); }) : null;
      const fits = (t, v) => t.hi === v || t.lo === v;
      const steps = [];
      let nodes = 0;
      const prefer = this.prevSol;
      const locks = this.locks;
      const lockOk = (i, p) => { const l = locks[i]; if (!l) return true; return l === "me" ? p === 0 : p === this.relOfLabel(l); };

      const myCanPlay = (i, L, R) => {
        if (!myTiles) return false; // unknown: allow the pass
        for (const t of myTiles) {
          let playedBefore = false;
          for (let j = 0; j < i; j++) if (mineFlag[j] && ids[j].id === t.id) { playedBefore = true; break; }
          if (!playedBefore && (fits(t, L) || fits(t, R))) return true;
        }
        return false;
      };

      const rec = (i, ptr, L, R, rem) => {
        if (++nodes > 150000) return false;
        if (i === n) {
          if (rem.some((x) => x !== 0)) return false;
          if (requireEnds && obsEnds) {
            const a = [L, R].sort().join(), b = [obsEnds[0], obsEnds[1]].sort().join();
            if (a !== b) return false;
          }
          return true;
        }
        const t = ids[i];
        const order = [];
        if (i === 0) {
          const cands = mineFlag[0] === true ? [0] : mineFlag[0] === false ? [1, 2, 3] : [0, 1, 2, 3];
          const pf = prefer[0] ? prefer[0].p : -1;
          if (cands.includes(pf)) order.push(pf);
          for (const c of cands) if (c !== pf) order.push(c);
          for (const p of order) {
            if (rem[p] <= 0 || !lockOk(0, p)) continue;
            rem[p]--;
            steps[i] = { tile: t.id, p, side: null, matched: null, passes: [] };
            if (rec(1, (p + 1) % 4, t.hi, t.lo, rem)) return true;
            rem[p]++;
          }
          return false;
        }
        for (let k = 0; k < 4; k++) {
          const p = (ptr + k) % 4;
          // players ptr..p-1 passed
          if (k > 0) {
            const q = (ptr + k - 1) % 4;
            if (q === 0 && myCanPlay(i, L, R)) break; // I could not have passed; no later k is possible either
          }
          if (mineFlag[i] != null && (p === 0) !== mineFlag[i]) continue;
          if (rem[p] <= 0 || !lockOk(i, p)) continue;
          const sides = [];
          if (fits(t, L)) sides.push("L");
          if (fits(t, R) && !(L === R)) sides.push("R");
          if (!sides.length) continue;
          const pf = prefer[i];
          if (pf && pf.p === p && sides.includes(pf.side)) { sides.splice(sides.indexOf(pf.side), 1); sides.unshift(pf.side); }
          if (sides.length === 2 && i === n - 1 && obsEnds) {
            // prefer the side whose result matches the observed ends
            const ok = (s) => { const m = s === "L" ? L : R; const e = t.hi === m ? t.lo : t.hi; const nl = s === "L" ? e : L, nr = s === "R" ? e : R; return [nl, nr].sort().join() === [obsEnds[0], obsEnds[1]].sort().join(); };
            sides.sort((a, b) => Number(ok(b)) - Number(ok(a)));
          }
          for (const s of sides) {
            const m = s === "L" ? L : R;
            const e = t.hi === m ? t.lo : t.hi;
            const nl = s === "L" ? e : L, nr = s === "R" ? e : R;
            const passes = []; for (let x = 0; x < k; x++) passes.push((ptr + x) % 4);
            rem[p]--;
            steps[i] = { tile: t.id, p, side: s, matched: m, passes };
            if (rec(i + 1, (p + 1) % 4, nl, nr, rem)) return true;
            rem[p]++;
          }
        }
        return false;
      };

      const ok = rec(0, 0, 0, 0, rem0.slice());
      if (!ok) return null;
      // final ends from replay
      let L = ids[0].hi, R = ids[0].lo;
      for (let i = 1; i < n; i++) {
        const s = steps[i]; const t = ids[i];
        if (s.side === "L") { L = t.hi === L ? t.lo : t.hi; } else { R = t.hi === R ? t.lo : t.hi; }
      }
      // players between the last mover and me passed (it is my turn now)
      const trailing = [];
      if (myTurn) {
        let ptr = (steps[n - 1].p + 1) % 4;
        let guard = 0;
        while (ptr !== 0 && guard++ < 4) { trailing.push(ptr); ptr = (ptr + 1) % 4; }
      }
      return { steps: steps.slice(0, n), trailing, L, R };
    }
  }

  window.CdaAdapter = CdaAdapter;
  window.CDA_ADAPTER = new CdaAdapter();
})();

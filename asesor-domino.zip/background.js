// background.js — service worker (Chrome) / event page (Firefox). Its only job is saving the game log to the Downloads folder
// when content.js asks (a page script cannot use chrome.downloads, and the panel may be closed).
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.action !== "saveLog") return;
  try {
    const url = "data:text/plain;charset=utf-8," + encodeURIComponent(String(msg.text || ""));
    chrome.downloads.download(
      { url, filename: String(msg.filename || "cda-log.txt"), saveAs: false, conflictAction: "uniquify" },
      (id) => {
        const err = chrome.runtime.lastError;
        sendResponse(err || id === undefined ? { ok: false, error: err ? err.message : "no download id" } : { ok: true, id });
      }
    );
  } catch (e) {
    sendResponse({ ok: false, error: String((e && e.message) || e) });
  }
  return true;   // the response is sent asynchronously
});

// One click on the toolbar icon opens the advisor panel (or focuses it if it is already open).
// (The engine-strength selector lives in the panel itself, so the old popup is no longer needed.)
// Firefox for Android has no windows API (no popup windows): there the panel opens in a tab, and the advisor
// itself lives on the game page (mobile-ui.js).
const hasWindows = !!(chrome.windows && chrome.windows.create);
function openAdvisorWindow() {
  if (!hasWindows) { chrome.tabs.create({ url: chrome.runtime.getURL("panel.html") }); return; }
  chrome.windows.getLastFocused((cur) => {
    const opts = { url: chrome.runtime.getURL("panel.html"), type: "popup", width: 400, height: 520, top: 60, focused: true };
    if (cur && typeof cur.left === "number" && typeof cur.width === "number") opts.left = Math.max(0, cur.left + cur.width - 420);
    chrome.windows.create(opts, (win) => {
      if (win) chrome.storage.local.set({ advisorWindowId: win.id });
    });
  });
}
chrome.action.onClicked.addListener(() => {
  chrome.storage.local.get(["advisorWindowId"], (r) => {
    const id = r.advisorWindowId;
    if (!id || !hasWindows) return openAdvisorWindow();
    chrome.windows.get(id, (win) => {
      if (chrome.runtime.lastError || !win) openAdvisorWindow();
      else chrome.windows.update(id, { focused: true });
    });
  });
});

// The bot must never play unnoticed: it is switched OFF whenever the advisor panel window goes away (closed,
// crashed, or Chrome quit), and whenever Chrome starts or the extension is (re)loaded. The panel records its own
// window id as "cdaPanelWindow" when it opens (the key is not removed on unload, so this check cannot miss it).
function botOff(why) {
  chrome.storage.local.get(["botEnabled"], (r) => {
    if (r.botEnabled) chrome.storage.local.set({ botEnabled: false, botOffReason: { why, at: Date.now() } });
  });
}
if (hasWindows) chrome.windows.onRemoved.addListener((windowId) => {
  chrome.storage.local.get(["cdaPanelWindow", "advisorWindowId"], (r) => {
    if (windowId === r.cdaPanelWindow || windowId === r.advisorWindowId) {
      botOff("panel closed");
      chrome.storage.local.remove(["cdaPanelWindow"]);
    }
  });
});
chrome.runtime.onStartup.addListener(() => botOff("browser started"));
chrome.runtime.onInstalled.addListener(() => botOff("extension loaded or updated"));

// Deactivation list (license.js): fetch the owner's list of switched-off device codes. Only a GitHub gist URL is
// fetched (the page's own rules could block it from the content script). Fresh copy each time (the CDN keeps ~5 min).
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.action !== "cdaRevoked") return;
  const url = String(msg.url || "");
  if (!/^https:\/\/gist\.githubusercontent\.com\//.test(url)) { sendResponse({ ok: false }); return; }
  fetch(url + (url.includes("?") ? "&" : "?") + "t=" + Date.now(), { cache: "no-store" })
    .then((r) => (r.ok ? r.json() : Promise.reject(new Error("HTTP " + r.status))))
    .then((j) => sendResponse({ ok: true, list: Array.isArray(j && j.revoked) ? j.revoked : [] }))
    .catch(() => sendResponse({ ok: false }));
  return true;   // answered asynchronously
});

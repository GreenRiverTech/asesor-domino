// panel.js — Runs inside the persistent advisor window (panel.html).
// Polls chrome.storage every 500ms for game state written by content.js.
// This window stays open regardless of clicks outside it.

const POLL_INTERVAL_MS = 500;
let pollTimer = null;
let pip = null;          // the always-on-top (Picture-in-Picture) window, when active

// Elements live in this window, or in the always-on-top window while the panel is moved there.
function byId(id) {
  return document.getElementById(id) || (pip && !pip.closed ? pip.document.getElementById(id) : null);
}

// ─────────────────────────────────────────────
// INIT
// ─────────────────────────────────────────────
["palo-partner", "palo-left", "palo-right"].forEach(id => renderPaloSeco(id, null, null));
renderMine("palo-me", null);

chrome.storage.local.get(["botEnabled", "lastUpdate"], (result) => {
  updateToggleUI(!!result.botEnabled);
  if (result.lastUpdate) renderUpdate(result.lastUpdate);
  startPolling();
});

// ─────────────────────────────────────────────
// GAME LOG — content.js keeps every decision, pass and hand result in chrome.storage ("cdaLog");
// it survives closing the table. "Save log" writes it to a text file in Downloads.
// ─────────────────────────────────────────────
// The button shows how many hands the stored log holds (one "NEW HAND" line per hand).
const handsIn = (entries) => (entries || []).filter(e => e.includes("==== NEW HAND ====")).length;
const handsText = (n) => n + (n === 1 ? " mano" : " manos");
function showLogCount(n) {
  const b = byId("savelog");
  if (b) b.textContent = "💾 Guardar registro" + (n ? " (" + handsText(n) + ")" : "");
}
chrome.storage.local.get(["cdaLog"], (r) => showLogCount(handsIn(r.cdaLog)));
chrome.storage.onChanged.addListener((chg) => { if (chg.cdaLog) showLogCount(handsIn(chg.cdaLog.newValue)); });

byId("savelog").onclick = () => chrome.storage.local.get(["cdaLog"], (r) => {
  const entries = r.cdaLog || [];
  if (entries.length === 0) { setText("status", "El registro está vacío: no hay nada que guardar."); return; }
  const text = "Cuban Domino Advisor log - saved " + new Date().toLocaleString() + "\n\n" + entries.join("\n") + "\n";
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = "cda-log-" + new Date().toISOString().slice(0, 16).replace(/[:T]/g, "-") + ".txt";
  (pip && !pip.closed ? pip.document : document).body.appendChild(a);   // the window the panel is shown in
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 3000);
  setText("status", "Registro guardado (" + handsText(handsIn(entries)) + ") en Descargas.");
});
// Two clicks to erase, confirmed on the button itself: a confirm() box does not show while the panel is in the
// always-on-top window (it would belong to the minimized panel window).
let clearArmed = null;
byId("clearlog").onclick = () => {
  const b = byId("clearlog");
  if (!clearArmed) {
    b.textContent = "⚠ Pulsa otra vez para borrar";
    clearArmed = setTimeout(() => { clearArmed = null; b.textContent = "🗑 Borrar registro"; }, 3000);
    return;
  }
  clearTimeout(clearArmed); clearArmed = null;
  b.textContent = "🗑 Borrar registro";
  chrome.storage.local.set({ cdaLog: [] }, () => setText("status", "Registro borrado."));
};

// ENGINE — which engine decides (content.js reads "cdaEngineMode"); the engine playing now comes with each update.
const engSel = byId("engine");
chrome.storage.local.get(["cdaEngineMode"], (r) => { if (engSel) engSel.value = r.cdaEngineMode && r.cdaEngineMode !== "alternate" ? r.cdaEngineMode : "alternate-5s"; });
if (engSel) engSel.onchange = () => chrome.storage.local.set({ cdaEngineMode: engSel.value });
chrome.storage.onChanged.addListener((chg) => { if (chg.cdaEngineMode && engSel) engSel.value = chg.cdaEngineMode.newValue && chg.cdaEngineMode.newValue !== "alternate" ? chg.cdaEngineMode.newValue : "alternate-5s"; });

// ⇄ — the ends look swapped on the screen: flip them for this seat (remembered; content.js logs it)
if (byId("flipends")) byId("flipends").onclick = () => {
  if (lastSeat === null) { setText("status", "Siéntate primero en una mesa: el cambio se recuerda por asiento."); return; }
  const next = { ...endFlip, [lastSeat]: !endFlip[lastSeat] };
  chrome.storage.local.set({ cdaEndFlip: next });
};

// FICHAS PASADAS can be hidden: click its title (remembered in chrome.storage, key "cdaHidePalo")
function showPalo(hidden) {
  const body = byId("palo-body"), arrow = byId("palo-arrow");
  if (body) body.classList.toggle("hidden", !!hidden);
  if (arrow) arrow.textContent = hidden ? "▸" : "▾";
  scheduleFit();
}
chrome.storage.local.get(["cdaHidePalo"], (r) => showPalo(r.cdaHidePalo));
chrome.storage.onChanged.addListener((chg) => { if (chg.cdaHidePalo) showPalo(chg.cdaHidePalo.newValue); });
if (byId("palo-toggle")) byId("palo-toggle").onclick = () => {
  const body = byId("palo-body");
  chrome.storage.local.set({ cdaHidePalo: !(body && body.classList.contains("hidden")) });
};

// BOT SPEED — 1x normal, 2x 20% faster, 3x 40% faster (content.js reads "cdaSpeed"; applies from the next move).
function showSpeed(v) {
  const g = byId("speed");
  if (g) g.querySelectorAll("button").forEach(b => b.classList.toggle("on", Number(b.dataset.speed) === (Number(v) || 1)));
}
chrome.storage.local.get(["cdaSpeed"], (r) => showSpeed(r.cdaSpeed));
if (byId("speed")) byId("speed").querySelectorAll("button").forEach(b => {
  b.onclick = () => chrome.storage.local.set({ cdaSpeed: Number(b.dataset.speed) });
});
chrome.storage.onChanged.addListener((chg) => { if (chg.cdaSpeed) showSpeed(chg.cdaSpeed.newValue); });

// Auto-save: content.js writes each finished game to Downloads (cda-game-...txt) through background.js.
// Auto-save is a button: "Auto-save: On" (green) / "Auto-save: Off"; a click switches it.
const autoBtn = byId("autosave");
let autoSaveOn = true;
function showAutoSave(on) {
  autoSaveOn = on;
  if (!autoBtn) return;
  autoBtn.textContent = "💾 Autoguardar: " + (on ? "Sí" : "No");
  autoBtn.classList.toggle("on", on);
}
chrome.storage.local.get(["autoSaveLog"], (r) => showAutoSave(r.autoSaveLog !== false));
if (autoBtn) autoBtn.onclick = () => chrome.storage.local.set({ autoSaveLog: !autoSaveOn });
function showLastSave(s) {
  const el = byId("lastsave");
  if (el) el.textContent = s ? "Último autoguardado: " + s.file + " (" + new Date(s.at).toLocaleTimeString() + (s.hands !== undefined ? ", " + handsText(s.hands) : "") + ")" : "";
}
chrome.storage.local.get(["cdaLastSave"], (r) => showLastSave(r.cdaLastSave));
chrome.storage.onChanged.addListener((chg) => {
  if (chg.cdaLastSave) showLastSave(chg.cdaLastSave.newValue);
  if (chg.autoSaveLog) showAutoSave(chg.autoSaveLog.newValue !== false);
});

// Closing the panel switches the bot OFF (it must never play unnoticed). background.js does it when the window is
// removed - the reliable route - and the unload below tries too. The panel's window id is stored for background.js.
try { chrome.windows.getCurrent((w) => { if (w && w.id !== undefined) chrome.storage.local.set({ cdaPanelWindow: w.id }); }); } catch (e) {}
function onPanelUnload() {
  if (pollTimer) clearInterval(pollTimer);
  try {
    // Throws "Extension context invalidated" if the extension was reloaded while this panel was open.
    if (chrome.runtime?.id) {
      chrome.storage.local.set({ botEnabled: false, botOffReason: { why: "panel closed", at: Date.now() } });
      chrome.storage.local.remove("advisorWindowId");
    }
  } catch (e) {}
}
window.addEventListener("unload", onPanelUnload);

// ─────────────────────────────────────────────
// TOGGLE BUTTON
// ─────────────────────────────────────────────
byId("toggle").onclick = () => {
  chrome.storage.local.get(["botEnabled"], (result) => {
    const enabled = !result.botEnabled;
    chrome.storage.local.set({ botEnabled: enabled }, () => {
      updateToggleUI(enabled);
      // Notify the Ludoteka tab
      chrome.tabs.query({}, (tabs) => {
        for (const tab of tabs) {
          if (tab.url && tab.url.includes("ludoteka.com")) {
            chrome.tabs.sendMessage(tab.id, {
              action: "toggle_changed",
              enabled
            }).catch(() => {});
          }
        }
      });
    });
  });
};

// ─────────────────────────────────────────────
// POLLING LOOP
// ─────────────────────────────────────────────
function startPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(() => {
    chrome.storage.local.get(["lastUpdate"], (result) => {
      if (result.lastUpdate) renderUpdate(result.lastUpdate);
    });
  }, POLL_INTERVAL_MS);
}

// ─────────────────────────────────────────────
// RENDER UPDATE
// ─────────────────────────────────────────────
// A horizontal domino tile: two halves with pips on a 3x3 grid (cells numbered 0-8, row by row). 6 and 7 are drawn
// as on Ludoteka's horizontal tiles: two rows of three (and the 7's centre dot).
// Dot colour per number (the user's chart, shades matched to the game): 1 yellow, 2 black, 3 blue, 4 red, 5 green,
// 6 cyan, 7 brown (reddish, as in the game), 8 orange, 9 purple. Every tile in the panel uses it (title, board ends, Plan A, Plan B).
const PIP_COLORS = [null, "#e8b00c", "#1a1a1a", "#3a6cc6", "#d22b2b", "#1f6b2c", "#1aa6b5", "#7a2418", "#e8742a", "#6a2fb4"];   // matched to the game's tiles
const PIP_CELLS = [[], [4], [0, 8], [0, 4, 8], [0, 2, 6, 8], [0, 2, 4, 6, 8], [0, 1, 2, 6, 7, 8], [0, 1, 2, 4, 6, 7, 8], [0, 1, 2, 3, 5, 6, 7, 8], [0, 1, 2, 3, 4, 5, 6, 7, 8]];
// hit = index of the half (0 or 1) that pulses, a list of halves, or -1 for none.
// cross = index of a half to strike through with an X (the inner, already-joined half of an end tile), or -1.
function buildTile(a, b, hit = -1, cross = -1) {
  const tile = document.createElement("div");
  tile.className = "dtile" + (a === b ? " dtile-double" : "");
  [a, b].forEach((n, i) => {
    const half = document.createElement("div");
    half.className = "dhalf" + (i === hit || (Array.isArray(hit) && hit.includes(i)) ? " dhit" : "") + (i === cross ? " dcross" : "");
    for (let c = 0; c < 9; c++) {
      const cell = document.createElement("span");
      cell.className = "dpip" + ((PIP_CELLS[n] || []).includes(c) ? " on" : "");
      if (PIP_COLORS[n]) cell.style.setProperty("--pip", PIP_COLORS[n]);
      half.appendChild(cell);
    }
    tile.appendChild(half);
    if (i === 0) { const bar = document.createElement("div"); bar.className = "dbar"; tile.appendChild(bar); }
  });
  return tile;
}

// A double played after the opening stands upright (crosswise, as on the real board); the opening tile stays flat.
// Only Próxima jugada and Plan B draw it upright (CSS .dtile-up under #strip / #planb).
function upright(tile) { if (tile.classList.contains("dtile-double")) tile.classList.add("dtile-up"); return tile; }

// the small tile in the panel title
{ const tt = byId("title-tile"); if (tt) tt.appendChild(buildTile(6, 3)); }

// The engines' names in the panel (the user's choice); the log and the tools keep the codes.
const ENGINE_NAMES = { "v0.5": "El Clásico", "v0.5s": "El Trancador", "v0.9": "El Anticuado" };
let lastStripKey = "";
let lastAExpl = "", lastBExpl = "";   // the last move descriptions (Plan A, Plan B), kept until my next turn
// Which board end Ludoteka draws on the LEFT of the screen. v12.11 assumed always end 1; live play showed it is not
// always so (it seems to depend on the seat). The default stays end 1; the panel's ⇄ button flips it, remembered per
// seat in chrome.storage ("cdaEndFlip" = {seat: true}).
let endFlip = {};
let lastSeat = null;
chrome.storage.local.get(["cdaEndFlip"], (r) => { endFlip = r.cdaEndFlip || {}; lastStripKey = ""; });
chrome.storage.onChanged.addListener((chg) => {
  if (chg.cdaEndFlip) { endFlip = chg.cdaEndFlip.newValue || {}; lastStripKey = ""; }
});
const leftIndex = (seat) => (seat !== null && seat !== undefined && endFlip[seat] ? 0 : 1);

function renderUpdate(data) {
  const e = data.ends || [];
  // the data end (0 or 1) the recommended tile covers; both when the two ends show the same number
  let cover = [];
  if (data.bestMove && e.length === 2) {
    const t = data.bestMove;
    if (data.bestMatched != null) cover = [0, 1].filter(i => e[i] === data.bestMatched && t.includes(e[i]));
    else {
      const fit = [0, 1].filter(i => t.includes(e[i]));
      if (fit.length === 1 || e[0] === e[1]) cover = fit;
    }
  }
  // rebuilt only when something it shows changed, so the animation runs smoothly between polls
  if (data.mySeat !== null && data.mySeat !== undefined) lastSeat = data.mySeat;
  const key = JSON.stringify([data.bestMove, data.bestMatched, data.endTiles, data.oneTile, e, data.myTurn, data.bestMove ? "" : (data.headline || ""), leftIndex(lastSeat)]);
  if (key + JSON.stringify(data.planB || null) !== lastStripKey) {
    lastStripKey = key + JSON.stringify(data.planB || null);
    renderStrip(data, cover);
    renderPlanB(data.bestMove ? data.planB : null, data);
  }

  if (data.engine) setText("engine-now", "Motor en juego: " + (ENGINE_NAMES[data.engine] || data.engine));
  const explEl = byId("explanation");
  // the description of my move stays on screen until my next turn, so it can be read slowly; between turns the
  // waiting messages are not shown over it (only when there is no game does it clear)
  if (data.bestMove) { lastAExpl = data.explanation || ""; lastBExpl = (data.planB && data.planB.explanation) || ""; }
  else if (data.headline === "No game") { lastAExpl = ""; lastBExpl = ""; }
  explEl.textContent = ES.text(data.bestMove ? (data.explanation || "") : (lastAExpl || data.explanation || ""));

  const likely = data.likely || {};
  if (data.paloSeco) {
    renderPaloSeco("palo-partner", data.paloSeco.partner,       likely.partner);
    renderPaloSeco("palo-left",    data.paloSeco.opponentLeft,  likely.opponentLeft);
    renderPaloSeco("palo-right",   data.paloSeco.opponentRight, likely.opponentRight);
    renderMine("palo-me", data.myVoids);
  }
  scheduleFit();
}

// Next Move strip: one line, like the board seen from above. The board is reduced to its two end tiles as they lie
// on the screen (open number outward, the inner half crossed out). The recommended tile starts big in the middle
// of that line and slides horizontally over the end tile it goes on, shrinking as it moves, until it rests beside
// it at the board tiles' size, turned so its matching number touches that end. Then it fades back and repeats.
// LI = the data end shown on the LEFT (see leftIndex); the other one is shown on the right. Each end tile is laid out
// with its open number outward.
function renderStrip(data, cover) {
  const LI = leftIndex(lastSeat), RI = 1 - LI;
  const rev = (t) => [t[1], t[0]];
  const strip = byId("strip");
  if (!strip) return;
  strip.textContent = "";
  const e = data.ends || [], tiles = data.endTiles;
  const span = (cls, text) => { const x = document.createElement("span"); x.className = cls; if (text) x.textContent = text; return x; };
  const wrap = (tile, big) => { const x = span("end-tile" + (big ? " big" : "")); x.appendChild(tile); return x; };
  // on my move the end the tile goes on is drawn at full size, the same size as the moving tile
  const row = span("strip-row");
  strip.appendChild(row);

  let target = null, side = null;            // the board tile the move goes over and rests beside, and which side
  let centre = null;                         // what sits in the middle of the line when there is no tile to move
  if (tiles && data.oneTile) {
    // only the opening tile: it is both ends (its left half = end LI, right half = the other). It is drawn on the
    // side the move goes to, so the moving tile can start in the middle and travel over it.
    const h = []; if (cover.includes(LI)) h.push(0); if (cover.includes(RI)) h.push(1);
    const shown = LI === 1 ? rev(tiles[0]) : tiles[0];      // tiles[0] = [end 0 value, end 1 value]
    target = buildTile(shown[0], shown[1], h);
    side = cover.includes(LI) ? "left" : cover.includes(RI) ? "right" : null;
    if (data.bestMove && side) {
      // my move: always the same direction - the target half is turned to face left, the tile comes from the left
      const f = side === "right" ? rev(shown) : shown;
      target = buildTile(f[0], f[1], 0);
      row.append(span("strip-spacer"), wrap(target, true), span("strip-gap"), span("strip-endlabel", side === "left" ? "Punta izq." : "Punta der."));
    } else row.append(span("strip-label", "Izq."), span("strip-spacer"), wrap(target), span("strip-spacer"), span("strip-label right", "Der."));
  } else if (tiles) {
    // the data has end 0 as [open, inner] and end 1 as [inner, open]; on screen: L = [open, inner], R = [inner, open]
    const L = LI === 1 ? rev(tiles[1]) : tiles[0], R = LI === 1 ? rev(tiles[0]) : tiles[1];
    // whole tiles (no X on the inner half): the open number is the outer half
    const elL = upright(buildTile(L[0], L[1], cover.includes(LI) ? 0 : -1));
    const elR = upright(buildTile(R[0], R[1], cover.includes(RI) ? 1 : -1));
    if (cover.includes(LI)) { target = elL; side = "left"; } else if (cover.includes(RI)) { target = elR; side = "right"; }
    if (data.bestMove && side) {
      // my move: only the end it goes on, always animated the same way: that end's open number faces left and the
      // tile comes from the left to meet it front to front; the label says which end of the board it is
      const f = side === "left" ? L : rev(R);                 // [open, inner]
      target = upright(buildTile(f[0], f[1], 0));
      row.append(span("strip-spacer"), wrap(target, true), span("strip-gap"), span("strip-endlabel", side === "left" ? "Punta izq." : "Punta der."));
    } else {
      // not my turn (or the end is not known): both ends
      centre = span("strip-mid", data.bestMove ? "" : "• • • •");   // the explanation below says whose turn it is
      row.append(span("strip-label", "Izq."), span("strip-dock"), wrap(elL), centre, wrap(elR), span("strip-dock"), span("strip-label right", "Der."));
    }
  } else {
    row.append(span("strip-mid", data.bestMove ? "" : ES.text(data.headline || "—")));
  }
  if (!data.bestMove) return;

  const t = data.bestMove;
  // the number that touches the board: the open number of the target end
  const m = side ? (side === "left" ? e[LI] : e[RI]) : null;
  let a = t[0], b = t[1];
  if (m !== null && t.includes(m)) {
    const other = t[0] === m ? t[1] : t[0];
    [a, b] = [other, m];                                      // the matching number faces the end (on its right)
  }
  // tile fits both (different) ends: its touching half pulses too, as before
  const both = e.length === 2 && e[0] !== e[1] && t[0] !== t[1] && t.includes(e[0]) && t.includes(e[1]);
  const mover = buildTile(a, b, both && side ? 1 : -1);
  mover.classList.add("mover");
  if (target && side) {
    // no movement: the tile to play on the left, a thick arrow, and the end it goes on (open number facing it);
    // the label says which end of the board it is
    row.textContent = "";
    upright(mover);                                           // it goes on an end, so it is not the opening tile
    const mw = span("end-tile big"); mw.appendChild(mover);
    row.append(span("strip-spacer"), mw, span("strip-arrow"), wrap(target, true),
               span("strip-endlabel", side === "left" ? "Punta izq." : "Punta der."), span("strip-spacer"));
    return;
  }
  // no end to show (opening lead): the tile alone in the middle
  const layer = span("strip-layer");
  layer.appendChild(mover);
  strip.appendChild(layer);
}

// Plan B: the engine's second choice on one line under the strip: label and how far it trails Plan A on the left,
// and the same docking animation at the small tile size on the right (its end tile and the Plan B tile meeting front
// to front). Greyed out when 15+ points behind. Auto mode always plays Plan A.
const PLANB_FAR = 15;
function renderPlanB(b, data) {
  const el = byId("planb");
  if (!el) return;
  el.textContent = "";
  el.classList.remove("far");
  const ex = byId("planb-expl");
  if (ex) {
    ex.textContent = b && b.tile ? ES.text(b.explanation || "") : ES.text(lastBExpl);   // kept until my next turn
    if (b) ex.classList.toggle("far", (b.behind || 0) >= PLANB_FAR);
  }
  if (!b || !b.tile) return;
  const mk = (tag, cls, text) => { const x = document.createElement(tag); if (cls) x.className = cls; if (text) x.textContent = text; return x; };
  const behind = Math.max(0, b.behind || 0);
  const info = mk("span", "planb-info");
  info.append(mk("span", "planb-label", "Plan B"), mk("span", "planb-behind", behind < 0.5 ? "igual que A" : behind.toFixed(behind < 10 ? 1 : 0) + " pts menos"));
  const mini = mk("span", "mini-strip");
  const row = mk("span", "mini-row");
  mini.appendChild(row);
  el.append(info, mini);
  if (behind >= PLANB_FAR) el.classList.add("far");

  // where Plan B goes: the screen side of its end, and that end's tile laid out as on the main strip
  const e = (data && data.ends) || [], tiles = data && data.endTiles;
  const LI = leftIndex(lastSeat), RI = 1 - LI, rev = (t) => [t[1], t[0]];
  // always animated the same way as Plan A: the end's open number faces left and the tile comes from the left
  let side = null, endTile = null;
  if (tiles && b.end !== null && b.end !== undefined) {
    if (data.oneTile) {
      const shown = LI === 1 ? rev(tiles[0]) : tiles[0];
      side = e[LI] === b.end ? "left" : e[RI] === b.end ? "right" : null;
      if (side) endTile = side === "right" ? rev(shown) : shown;
    } else {
      const L = LI === 1 ? rev(tiles[1]) : tiles[0], R = LI === 1 ? rev(tiles[0]) : tiles[1];
      if (e[LI] === b.end) { side = "left"; endTile = L; }
      else if (e[RI] === b.end) { side = "right"; endTile = rev(R); }
    }
  }
  // Plan B tile turned so its matching number faces the end
  let x = b.tile[0], y = b.tile[1];
  if (side && b.tile.includes(b.end)) {
    const o = b.tile[0] === b.end ? b.tile[1] : b.tile[0];
    [x, y] = [o, b.end];
  }
  const mover = buildTile(x, y);
  mover.classList.add("mover", "mini");
  if (!side) { row.appendChild(mover); return; }   // no end to show: the tile alone
  upright(mover);
  const target = buildTile(endTile[0], endTile[1], 0);
  if (!data.oneTile) upright(target);              // the opening tile on the board stays flat
  const tw = mk("span", "end-tile"); tw.appendChild(target);
  // same picture as Plan A, smaller: the tile, a thick arrow, the end it goes on
  row.append(mover, mk("span", "mini-arrow"), tw, mk("span", "mini-endlabel", side === "left" ? "punta izq." : "punta der."));
}

// Work out where the moving tile ends (beside the target end tile, at its size) and start the animation.
// Positions are measured on screen, so this waits until the window is laid out.
function placeMover(mover, target, side, tries) {
  const mr = mover.getBoundingClientRect(), tr = target.getBoundingClientRect();
  if ((!mr.width || !tr.width) && tries < 40) { setTimeout(() => placeMover(mover, target, side, tries + 1), 250); return; }
  const scale = tr.width / mr.width, gap = 1;
  const cx = side === "left" ? tr.left - gap - tr.width / 2 : tr.right + gap + tr.width / 2;
  const z = panelZoom || 1;                              // screen pixels → panel pixels (the panel is scaled)
  mover.style.setProperty("--s", scale.toFixed(3));
  mover.style.setProperty("--dx", Math.round((cx - (mr.left + mr.width / 2)) / z) + "px");
  mover.style.setProperty("--dy", Math.round(((tr.top + tr.height / 2) - (mr.top + mr.height / 2)) / z) + "px");
  mover.classList.add("docking");
}

// One circle per number 0-9 under a player. Green = may still hold it, red = passed on it (certain),
// amber = the engine infers none (hover for the chance).
// text: the confirmed passes ("Pasado en: 3, 6, 8"); likely: [{n, p}] estimated from sampled deals.
function renderPaloSeco(elementId, text, likely) {
  const el = byId(elementId);
  if (!el) return;

  const passed = new Set();
  const m = text && text.match(/Pasado en:\s*(.+)/i);
  if (m) m[1].split(",").map(s => parseInt(s.trim(), 10)).filter(n => !isNaN(n)).forEach(n => passed.add(n));
  const maybe = new Map();
  if (Array.isArray(likely)) likely.forEach(x => maybe.set(x.n, x.p));

  // Weather-radar scale: the engine's chance that the player holds NO tile of the number, in 10% steps,
  // from green (surely holds it) to red. A confirmed pass is solid red.
  let html = "";
  for (let n = 0; n <= 9; n++) {
    if (passed.has(n)) html += `<span class="dot" style="${radar(10)}">${n}</span>`;
    else {
      const p = maybe.has(n) ? maybe.get(n) : 0;
      html += `<span class="dot" style="${radar(Math.round(p / 10))}">${n}</span>`;
    }
  }
  el.innerHTML = html;
}

// step 0 = green ... step 10 = red (hue 120 -> 0)
function radar(step) {
  const s = Math.max(0, Math.min(10, step));
  return `background:hsl(${Math.round(120 * (1 - s / 10))},75%,40%);color:#fff`;
}

// My own row: certain facts from my hand and my passes, never an estimate.
// Red = I passed on it, grey = no tile of it in my hand now, green = I hold it.
function renderMine(elementId, mv) {
  const el = byId(elementId);
  if (!el) return;
  // no game (or my hand not known yet): show the ten numbers like the other players' rows, never a blank row
  if (!mv) { el.innerHTML = Array.from({ length: 10 }, (_, n) => `<span class="dot" style="${radar(0)}">${n}</span>`).join(""); return; }
  const passed = new Set(mv.passed || []), none = new Set(mv.none || []);
  let html = "";
  for (let n = 0; n <= 9; n++) {
    if (passed.has(n))    html += `<span class="dot" style="${radar(10)}">${n}</span>`;
    else if (none.has(n)) html += `<span class="dot out">${n}</span>`;
    else                  html += `<span class="dot" style="${radar(0)}">${n}</span>`;
  }
  el.innerHTML = html;
}

let statusTimer = null;
function setText(id, value) {
  const el = byId(id);
  if (el) el.textContent = value;
  // the status line only shows short messages (log saved, cleared...): they disappear after 5 s
  if (id === "status") {
    if (statusTimer) clearTimeout(statusTimer);
    statusTimer = setTimeout(() => { const s = byId("status"); if (s) s.textContent = ""; scheduleFit(); }, 5000);
    scheduleFit();
  }
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

// ─────────────────────────────────────────────
// TOGGLE UI
// ─────────────────────────────────────────────
function updateToggleUI(enabled) {
  const btn    = byId("toggle");
  if (enabled) {
    btn.textContent = "Piloto automático: Sí";
    btn.classList.add("enabled");
  } else {
    btn.textContent = "Piloto automático: No";
    btn.classList.remove("enabled");
  }
}

// ─────────────────────────────────────────────
// WINDOW SIZE — fit the window to its content (no blank space, no horizontal scroll)
// ─────────────────────────────────────────────
// ── Resizable panel that scales to fit ─────────────────────────────────────
// The panel is laid out at 360 px wide and scaled as a whole (CSS transform) to fill the window: drag the window
// wider or narrower and everything grows or shrinks with it. The window height then follows the content (it changes
// when Fichas Pasadas is hidden or shown), so nothing is cut off and there is no empty space.
const BASE_W = 360;
let panelZoom = 1;
let fitTimer = null;
function inPip() { return !!(pip && !pip.closed); }
function setScale(b, z, x) {
  if (Math.abs(z - panelZoom) > 0.002 || b.dataset.x !== String(Math.round(x)) || !b.style.transform) {
    panelZoom = z;
    b.dataset.x = String(Math.round(x));
    b.style.transformOrigin = "top left";
    b.style.transform = `translate(${Math.round(x)}px, 0) scale(${z.toFixed(3)})`;
  }
}
// Keep on top: a page cannot size that window itself, so the panel scales to whatever size the user drags it to,
// fitting both its width and its height.
function applyZoomPip() {
  const b = pip.document.body;
  const h = b.offsetHeight || 1;
  const z = Math.max(0.4, Math.min(3, Math.min(pip.innerWidth / BASE_W, pip.innerHeight / h)));
  setScale(b, z, Math.max(0, (pip.innerWidth - BASE_W * z) / 2));
}
function applyZoom() {
  if (inPip()) { applyZoomPip(); return; }
  const b = document.body;
  const h = b.offsetHeight || 1;                       // layout height at scale 1 (a transform does not change it)
  // the width decides the scale; only when the screen is too short for that is the scale limited by the height
  const frameH = Math.max(0, window.outerHeight - window.innerHeight);
  const maxH = (window.screen && window.screen.availHeight ? window.screen.availHeight - frameH - 8 : window.innerHeight);
  const z = Math.max(0.6, Math.min(2.5, Math.min(window.innerWidth / BASE_W, maxH / h)));
  setScale(b, z, Math.max(0, (window.innerWidth - BASE_W * z) / 2));
}
function scheduleFit() {
  if (inPip()) { applyZoom(); return; }                // the always-on-top window: just rescale to its size
  if (fitTimer) clearTimeout(fitTimer);
  fitTimer = setTimeout(fitWindow, 120);
}
function fitWindow() {
  try {
    applyZoom();
    const want = Math.ceil(document.body.offsetHeight * panelZoom);
    if (Math.abs(want - window.innerHeight) <= 2) return;     // already fits
    const frameH = window.outerHeight - window.innerHeight;
    chrome.windows.getCurrent((win) => {
      if (chrome.runtime.lastError || !win) return;
      chrome.windows.update(win.id, { height: want + frameH });
    });
  } catch (e) {}
}
window.addEventListener("load", scheduleFit);
window.addEventListener("resize", () => { applyZoom(); scheduleFit(); });

// ─────────────────────────────────────────────
// ALWAYS ON TOP — an ordinary Chrome window cannot stay above other windows, but a Document
// Picture-in-Picture window can. The panel's content is moved into one; the normal window is
// minimised meanwhile and restored when the floating window is closed.
// ─────────────────────────────────────────────
function setOnTopUI(active) {
  const btn = byId("ontop");
  if (!btn) return;
  btn.textContent = active ? "📌 Siempre visible: Sí (pulsa para volver)" : "📌 Siempre visible";
  btn.classList.toggle("active", active);
}

function panelNodes() {
  return [...document.body.children].filter(n => n.tagName !== "SCRIPT");
}

async function toggleOnTop() {
  if (pip && !pip.closed) { pip.close(); return; }
  if (!("documentPictureInPicture" in window)) {
    setText("status", "«Siempre visible» necesita Chrome 116 o más nuevo.");
    return;
  }
  try {
    const width  = 360;
    const height = Math.ceil(document.body.scrollHeight) + 4;
    const win = await window.documentPictureInPicture.requestWindow({ width, height });
    pip = win;
    document.querySelectorAll("style").forEach(st => win.document.head.appendChild(st.cloneNode(true)));
    win.document.title = "Asesor de Dominó Cubano";
    win.document.body.append(...panelNodes());
    win.addEventListener("resize", applyZoom);         // the user drags the floating window: rescale the panel
    applyZoom();
    setOnTopUI(true);
    chrome.windows.getCurrent((w) => { if (w) chrome.windows.update(w.id, { state: "minimized" }); });
    win.addEventListener("pagehide", () => {
      const nodes = [...win.document.body.children];
      document.body.prepend(...nodes);
      pip = null;
      panelZoom = 0;                                   // force the main window to rescale
      setOnTopUI(false);
      chrome.windows.getCurrent((w) => { if (w) chrome.windows.update(w.id, { state: "normal" }); });
      scheduleFit();
    });
  } catch (e) {
    pip = null;
    setText("status", "No se pudo abrir la ventana siempre visible: " + (e && e.message ? e.message : e));
  }
}
byId("ontop").onclick = toggleOnTop;

window.CDA_BUILD = "firefox"; window.CDA_VERSION = "12.17.3";

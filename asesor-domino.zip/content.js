// content.js - Cuban Domino Advisor: Game logic bridge only.
// The UI lives in panel.html (separate always-on-top window).
// This script hooks the game, processes state, and writes to chrome.storage.
// panel.js polls storage and renders everything.
// Decisions come from the decision engine only (cde-engine.js via adapter.js).

// injected.js (page context) is now registered in manifest.json as a MAIN-world
// document_start content script, so it is in place before the game constructs.

// ── State ─────────────────────────────────────────────────────────────────
let botActive   = false;
let adapter     = null;   // decision engine bridge (adapter.js + cde-engine.js)
let lastWarned  = "";     // last "engine cannot decide" reason logged, to avoid repeating it every update
let lastLogged  = "";     // key of the decision already written to the console log
let takeTimer   = null;   // pending automatic "take my tiles" click
let takeTries   = 0;      // clicks sent this round (stops after a few if the game ignores them)
let lastState   = null;   // last game state, so a strength change can re-think the current turn
let finished    = false;  // the hand/game is over: ignore state updates until the next deal
let thoughtKey  = "";     // Android port: the turn the mobile "thinking" state was already shown for
let tableKeysLogged = false;   // Android port: the table object's names are logged once per page

const scores = { myTeam: null, opponentTeam: null };

// ── Which engine decides (live comparison of v0.9 and v0.5) ─────────────────
// Panel setting "cdaEngineMode": "alternate-5s" (default: v0.5 and v0.5s take turns, one whole match each), "v0.9" or
// "v0.5". The engine of the match in progress is remembered ("cdaMatchEngine", "cdaMatchOpen") so a page reload
// mid-match keeps it; a match closes at GAME OVER. Every hand, decision and saved file is labelled with the engine.
// Added 2026-10-06: "v0.5s" (v0.5 + strong-numbers rule) as a fixed choice, and "alternate-5s" (v0.5 / v0.5s each match).
// Android build: the selector is in the mobile details card (added back at the user's request, 2026-10-09).
const FIXED_ENGINES = ["v0.9", "v0.5", "v0.5s"];
// "alternate" (v0.9 / v0.5) was removed on 2026-10-08 at the user's request; a stored "alternate" becomes "alternate-5s".
const ALT_PAIRS = { "alternate-5s": ["v0.5", "v0.5s"] };
const normMode = (m) => (FIXED_ENGINES.includes(m) ? m : "alternate-5s");   // unknown or old "alternate" -> La Parejita
const isFixed = (mode) => FIXED_ENGINES.includes(mode);
const eng = { mode: "alternate-5s", match: null, open: false, lastAlt: null, gameEngine: null, started: false, loaded: false };
let thinksLogged = false;     // the think-time line of this hand is already in the log
function applyEngine(v) {
  if (adapter && v) adapter.setEngine(v);
}
// Called at every new deal: pick the engine for this hand.
function engineForNewHand() {
  eng.started = true;
  const pair = ALT_PAIRS[eng.mode] || ALT_PAIRS["alternate-5s"];
  if (isFixed(eng.mode)) {
    eng.match = eng.mode;
  } else if (!eng.open || !eng.match || !pair.includes(eng.match)) {
    eng.match = eng.lastAlt === pair[0] ? pair[1] : pair[0];   // a new match: the other engine's turn
    eng.lastAlt = eng.match;
  }
  eng.open = true;
  safeStorageSet({ cdaMatchEngine: eng.match, cdaMatchOpen: true, cdaLastAltEngine: eng.lastAlt });
  applyEngine(eng.match);
  return eng.match;
}

const NO_PASO = {
  partner:       "Not pasado in any suit",
  opponentLeft:  "Not pasado in any suit",
  opponentRight: "Not pasado in any suit"
};

// ── Context validity check ───────────────────────────────────────────────
// If the extension is reloaded/updated while the page is running,
// chrome.* APIs throw "Extension context invalidated".
// We detect this and stop all processing to prevent crash loops.
function isContextValid() {
  try {
    // Accessing chrome.runtime.id throws if context is invalidated
    return !!chrome.runtime?.id;
  } catch(e) {
    return false;
  }
}

// Safe chrome.storage.local.set — silently stops if context is gone
function safeStorageSet(data) {
  try {
    if (!isContextValid()) return;
    if (data.lastUpdate) data.lastUpdate.at = Date.now();   // when the panel text was written
    chrome.storage.local.set(data);
  } catch(e) {
    // Context invalidated — stop quietly
  }
}

// ── Persistent game log ─────────────────────────────────────────────────
// Every decision, hand result and bot action is kept in chrome.storage (key "cdaLog"), so it
// survives closing the table or the window. The panel's "Save log" button writes it to a file.
const gameLog = [];
const LOG_MAX = 600;          // entries kept (about a few games)
let logSaveTimer = null;
let gameStart = 0;            // index in gameLog where the current game's entries begin (see autoSaveGame)
let autoSaveOn = true;        // storage key "autoSaveLog" (panel checkbox); on unless switched off
let autoSaveTimer = null;
// Which board end the panel shows on the left, per seat (panel ⇄ button, storage "cdaEndFlip"); used for the
// "Board: x | y" text so it matches the panel.
let endFlip = {};
// Bot speed (panel buttons 1x / 2x / 3x, storage "cdaSpeed" = 1, 2 or 3). The names are labels only: 2x plays
// 20% faster and 3x 40% faster than the normal schedule (the bot's pauses are divided by 1.2 or 1.4).
const SPEED_FACTOR = { 1: 1, 2: 1.2, 3: 1.4 };
let botSpeed = 1;      // the setting (1, 2 or 3)
let speedFactor = 1;   // what the pauses are divided by
function setSpeed(v) { const n = Number(v); botSpeed = SPEED_FACTOR[n] ? n : 1; speedFactor = SPEED_FACTOR[botSpeed]; }
function addLog(text) {
  gameLog.push(new Date().toTimeString().slice(0, 8) + "  " + text);
  if (gameLog.length > LOG_MAX) {
    const drop = gameLog.length - LOG_MAX;
    gameLog.splice(0, drop);
    gameStart = Math.max(0, gameStart - drop);
  }
  if (logSaveTimer) return;
  logSaveTimer = setTimeout(() => { logSaveTimer = null; safeStorageSet({ cdaLog: gameLog.slice() }); }, 400);
}

// A game starts after the last "GAME OVER" line of the log (also after the page was reloaded mid-game).
function findGameStart() {
  for (let i = gameLog.length - 1; i >= 0; i--) if (gameLog[i].indexOf("GAME OVER") !== -1) return i + 1;
  return 0;
}

// When a game ends, write just that game to a text file in Downloads (through background.js).
// The stored log is left alone (the panel's Clear button erases it); the next game starts after this one.
function autoSaveGame(result) {
  autoSaveTimer = null;
  if (!autoSaveOn || !isContextValid()) return;
  const upto = gameLog.length;
  const entries = gameLog.slice(gameStart, upto);
  if (entries.length === 0) return;
  const d = new Date();
  const p2 = (n) => String(n).padStart(2, "0");
  const stamp = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}-${p2(d.getHours())}-${p2(d.getMinutes())}`;
  const res = result ? `${result.won ? "won" : "lost"}-${result.mine}-${result.theirs}` : "game";
  const filename = `cda-game-${stamp}-${eng.gameEngine || (adapter && adapter.engineVersion) || "engine"}-${res}.txt`;
  const text = "Cuban Domino Advisor - game log, saved " + d.toLocaleString() + " - engine " + (eng.gameEngine || (adapter && adapter.engineVersion) || "?") +
    (result ? ` - you ${result.won ? "won" : "lost"} ${result.mine}-${result.theirs}` : "") + "\n\n" + entries.join("\n") + "\n";
  try {
    chrome.runtime.sendMessage({ action: "saveLog", filename, text }, (resp) => {
      let err = null;
      try { err = chrome.runtime.lastError; } catch (e) { err = e; }
      if (err || !resp || !resp.ok) {
        addLog("[CDA] auto-save failed: " + ((err && err.message) || (resp && resp.error) || "no answer") + " (the log is still stored; use Save log)");
        return;
      }
      gameStart = Math.min(gameLog.length, Math.max(gameStart, upto));   // those entries are saved: the next game starts after them
      safeStorageSet({ cdaLastSave: { at: Date.now(), file: filename, entries: entries.length, hands: entries.filter((e) => e.includes("==== NEW HAND ====")).length } });
    });
  } catch (e) { /* extension context gone: nothing to do */ }
}

// ── Init ──────────────────────────────────────────────────────────────────
function initBot() {
  if (window.CDA_ADAPTER) {
    adapter = window.CDA_ADAPTER;
    chrome.storage.local.get(["botEnabled", "cdaSpeed", "cdaEndFlip", "cdaOrient", "cdaVotes", "cdaLevel", "cdaLog", "autoSaveLog", "cdaEngineMode", "cdaMatchEngine", "cdaMatchOpen", "cdaLastAltEngine"], (res) => {
      eng.loaded = true;
      eng.mode = normMode(res.cdaEngineMode);   // default = the user's chosen setting (2026-10-08)
      if (res.cdaEngineMode !== eng.mode) safeStorageSet({ cdaEngineMode: eng.mode });
      if (!eng.started) {   // only if no hand began before the settings arrived (then that hand's choice stands)
        eng.match = res.cdaMatchEngine || null;
        eng.open = !!res.cdaMatchOpen;
        eng.lastAlt = res.cdaLastAltEngine || null;
        if (isFixed(eng.mode)) applyEngine(eng.mode);
        else if (eng.open && eng.match) applyEngine(eng.match);   // reloaded mid-match: keep its engine
      }
      botActive = !!res.botEnabled;
      autoSaveOn = res.autoSaveLog !== false;
      setSpeed(res.cdaSpeed);
      endFlip = res.cdaEndFlip || {};
      if (Array.isArray(res.cdaLog) && gameLog.length === 0) { gameLog.push(...res.cdaLog); gameStart = findGameStart(); }   // keep earlier games
      // the switch was turned on while no table was open (or the page was reloaded): say so, the log must show who plays
      if (botActive && /\/partida/.test(location.pathname)) addLog("[CDA] bot is ON (table page loaded with the bot switched on)");
      if (res.cdaOrient) adapter.setOrientation(res.cdaOrient);
      if (res.cdaVotes)  adapter.votes = res.cdaVotes;
      // The engine always plays at "high": medium is weaker and expert has not been shown to beat high, so the
      // strength choice was removed (v12.11). A level stored by an older version is reset.
      adapter.level = "high";
      if (res.cdaLevel && res.cdaLevel !== "high") safeStorageSet({ cdaLevel: "high" });
      adapter.onVote = (votes, orient) => safeStorageSet({ cdaOrient: orient, cdaVotes: votes });
    });
    chrome.storage.onChanged.addListener((chg) => {
      if (chg.autoSaveLog) autoSaveOn = chg.autoSaveLog.newValue !== false;
      if (chg.cdaEndFlip) {
        const before = endFlip, after = chg.cdaEndFlip.newValue || {};
        endFlip = after;
        for (const seat of new Set([...Object.keys(before), ...Object.keys(after)])) {
          if (!!before[seat] !== !!after[seat]) addLog("[CDA] panel ends flipped for seat " + seat + " (left end now " + (after[seat] ? "end 0" : "end 1") + ")");
        }
      }
      if (chg.cdaSpeed) {
        setSpeed(chg.cdaSpeed.newValue);
        addLog("[CDA] bot speed set to " + botSpeed + "x (pauses / " + speedFactor + ")");
      }
      if (chg.cdaEngineMode && normMode(chg.cdaEngineMode.newValue) !== eng.mode) {
        eng.mode = normMode(chg.cdaEngineMode.newValue);
        if (!isFixed(eng.mode)) addLog("[CDA] engine setting changed to " + eng.mode + " (applies from the next hand)");
        // a fixed engine applies at once; "alternate" keeps the engine of the match in progress
        if (isFixed(eng.mode)) {
          eng.match = eng.mode;
          applyEngine(eng.mode);
          addLog("[CDA] engine set to " + eng.mode + " from the panel");
          safeStorageSet({ cdaMatchEngine: eng.match });
          if (lastState) processState(lastState);
        }
      }
      if (chg.cdaLog && Array.isArray(chg.cdaLog.newValue) && chg.cdaLog.newValue.length === 0) { gameLog.length = 0; gameStart = 0; }   // cleared from the panel
    });
  } else {
    setTimeout(initBot, 100);
  }
}
initBot();

// ── Leaving the table ────────────────────────────────────────────────────
// The panel shows whatever was written last, so tell it when there is no game any more:
// when a game page is closed or left, and when a page without a table (dashboard, lobby) loads.
function showNoGame() {
  safeStorageSet({
    lastUpdate: {
      bestMove:    null,
      headline:    "No game",
      explanation: "No game in progress — open a table to start.",
      myTurn:      false,
      hand:        [],
      ends:        [],
      paloSeco:    NO_PASO
    }
  });
}
const onGamePage = /\/partida/.test(location.pathname);
window.addEventListener("pagehide", () => { if (onGamePage) showNoGame(); });
if (!onGamePage && isContextValid()) {
  // another tab may be the live game: only blank the panel if nothing was written just now
  chrome.storage.local.get(["lastUpdate"], (res) => {
    const at = res.lastUpdate && res.lastUpdate.at;
    if (!at || Date.now() - at > 5000) showNoGame();
  });
}

// Bot on/off. The stored switch "botEnabled" is the source of truth: it changes from the panel's button, and it is
// switched OFF when the panel window closes (background.js). Turning it off cancels anything already scheduled.
function setBotActive(on, why) {
  on = !!on;
  if (on === botActive) return;
  botActive = on;
  if (!on) {
    if (autoTimer) { clearTimeout(autoTimer); autoTimer = null; autoKey = null; }
    if (takeTimer) { clearTimeout(takeTimer); takeTimer = null; }
  }
  addLog("[CDA] bot switched " + (on ? "ON" : "OFF") + (why ? " (" + why + ")" : ""));
}
chrome.runtime.onMessage.addListener((req) => {
  if (req.action === "toggle_changed") setBotActive(req.enabled, "panel button");
});
try {
  chrome.storage.onChanged.addListener((chg) => {
    if (!chg.botEnabled) return;
    let why = "";
    try { const r = chg.botOffReason && chg.botOffReason.newValue; if (r && r.why && chg.botEnabled.newValue === false) why = r.why; } catch (e) {}
    setBotActive(chg.botEnabled.newValue, why || "panel button");
  });
} catch (e) {}

// ── SINGLE message bridge — handles ALL message types in one place ────────
window.addEventListener("message", (evt) => {
  try {
  if (!evt.data || evt.data.source !== "LUDO_ADVISOR") return;
  if (!isContextValid()) {
    window.postMessage({ source: "LUDO_ADVISOR_STOP" }, "*");
    return;
  }
  const msg = evt.data;

  if (msg.type === "HOOK_SUCCESS") {
    try {
      console.log("[CDA] ✅ Hooked:", msg.gameKey);
      if (isContextValid()) safeStorageSet({ hookStatus: "connected", gameKey: msg.gameKey });
    } catch(e) {}
  }

  if (msg.type === "PATCH_READY") {
    try { console.log("[CDA] Constructor patched"); } catch(e) {}
  }

  if (msg.type === "HOOK_FAILED") {
    try {
      console.warn("[CDA] ❌", msg.reason);
      if (isContextValid()) safeStorageSet({ hookStatus: "failed" });
    } catch(e) {}
  }

  if (msg.type === "HAND_END") {
    // think times of the other players this hand (logging only; includes the game's animation time)
    if (!thinksLogged && Array.isArray(msg.thinks) && lastState && lastState.mySeat !== null && lastState.mySeat !== undefined) {
      thinksLogged = true;
      const me = lastState.mySeat;
      const lab = { 1: "R", 2: "P", 3: "L" };
      const per = { R: [], P: [], L: [] };
      for (const x of msg.thinks) {
        const l = lab[(x.seat - me + 4) % 4];
        if (l) per[l].push(String(Math.round(x.ms)) + (x.k === "pass" ? "p" : ""));
      }
      addLog(`      think times ms (p = pass; logging only)  R: ${per.R.join(" ") || "-"} | P: ${per.P.join(" ") || "-"} | L: ${per.L.join(" ") || "-"}`);
    }
    if (msg.gameEnd && eng.open) {
      eng.gameEngine = eng.match;
      eng.open = false;
      safeStorageSet({ cdaMatchOpen: false });
    }
    if (msg.hand || msg.gameEnd) {
      const ge0 = msg.gameEnd;
      addLog(`==== HAND END  points (team0,team1) ${JSON.stringify(msg.hand || null)}  match score (team0,team1) ${JSON.stringify(msg.totals || null)}` +
             (ge0 ? `  GAME OVER - you ${ge0.won ? "won" : "lost"} ${ge0.mine}-${ge0.theirs}` : ""));
    }
    // game over: save this game's log to a file a few seconds later, so the final {sumscr} line is in it too
    if (msg.gameEnd && !autoSaveTimer) autoSaveTimer = setTimeout(() => autoSaveGame(msg.gameEnd), 4000);
    finished = true;
    if (autoTimer) { clearTimeout(autoTimer); autoTimer = null; autoKey = null; }
    toMobile({ phase: "idle", myTurn: false });
    const ge = msg.gameEnd;
    if (isContextValid()) {
      safeStorageSet({
        lastUpdate: {
          bestMove:    null,
          headline:    ge ? "Game over" : "Hand finished",
          explanation: ge
            ? `Game over — you ${ge.won ? "won" : "lost"} ${ge.mine}–${ge.theirs}.`
            : "Hand finished — waiting for the next deal...",
          myTurn:      false,
          hand:        [],
          ends:        [],
          paloSeco:    NO_PASO
        }
      });
    }
  }

  if (msg.type === "ROUND_RESET") {
    thinksLogged = false;
    const usedEngine = engineForNewHand();
    addLog("==== NEW HAND ====  engine " + usedEngine + (!isFixed(eng.mode) ? " (alternating each match)" : ""));
    takeTries = 0;
    if (takeTimer) { clearTimeout(takeTimer); takeTimer = null; }
    finished = false;
    thoughtKey = "";
    toMobile({ phase: "idle", myTurn: false });
    if (adapter) adapter.resetHand(); // forget the previous hand's attribution
    lastWarned = "";
    // Immediately clear panel — don't keep stale recommendation from last round
    if (isContextValid()) {
      safeStorageSet({
        lastUpdate: {
          bestMove:    null,
          explanation: "Waiting for new hand...",
          myTurn:      false,
          hand:        [],
          ends:        [],
          paloSeco:    NO_PASO
        },
        hookStatus: "connected"
      });
    }
  }

  if (msg.type === "STATE_UPDATE" && msg.state) {
    // Running match score, from the game's own {score} events (exact), as seen from my team.
    if (msg.state.scores) {
      scores.myTeam       = msg.state.scores.myTeam;
      scores.opponentTeam = msg.state.scores.opponentTeam;
    }

    lastState = msg.state;
    processState(msg.state);
  }

  // player names (logging only, to learn whether partner profiles are possible)
  if (msg.type === "PLAYERS" && Array.isArray(msg.names)) {
    const me = lastState && lastState.mySeat;
    addLog("      players by seat: " + msg.names.map((n, i) => i + "=" + n).join("  ") + (me !== null && me !== undefined ? "   (me = seat " + me + ")" : ""));
  }
  if (msg.type === "NAMES_SAMPLE" && msg.sample) addLog("      [raw game event with a name, logging only] " + msg.sample);

  // Android port: did the bot's play land? (injected.js watchPlay: within 1 s of the last click)
  if (msg.type === "PLAY_RESULT" && !msg.ok) {
    addLog("[CDA] auto-play of " + (msg.tile || []).join("-") + " did not land within 1 s" + (mobileOn() ? ": AUTO switched off" : ""));
    if (mobileOn()) {
      if (botActive) safeStorageSet({ botEnabled: false, botOffReason: { why: "auto-play failed", at: Date.now() } });
      if (window.CDA_MOBILE) window.CDA_MOBILE.toast("autoFailed");
    }
  }
  // logging only: the table object's property names (to learn where the game keeps its tile elements)
  if (msg.type === "TABLE_KEYS" && !tableKeysLogged) {
    tableKeysLogged = true;
    addLog("      [table object, logging only] t: " + msg.t + " | proto: " + msg.proto + " | inst: " + msg.inst);
  }

  if (msg.type === "EXTRACT_ERROR") {
    try { console.warn("[CDA] Extract error:", msg.error); } catch(e) {}
  }
  } catch(e) {
    // Silently catch any error from invalidated extension context
  }
});

// ── Process game state ────────────────────────────────────────────────────
function processState(state) {
  if (!adapter) return;
  if (!isContextValid()) return;
  if (finished) return;   // hand or game over: keep the "finished" message on the panel
  // Firefox build: no advice and no play until this device is activated (license.js; the mobile button shows the lock)
  if (!licenseOk()) return;

  // Start of a round: with the bot on, press the game's "take my tiles" button for the player,
  // after a short human-like pause. (Tries a few times in case the game ignores a click.)
  if (state.canTake && botActive) {
    if (!takeTimer && takeTries < 4) {
      takeTimer = setTimeout(() => {
        takeTimer = null;
        if (!botActive) return;
        takeTries++;
        addLog("      bot took the tiles");
        window.postMessage({ source: "LUDO_ADVISOR_CMD", type: "TAKE_TILES" }, "*");
      }, (900 + Math.random() * 1300) / speedFactor);
    }
  }

  // The turn is over (e.g. you already played the tile yourself): drop the pending auto-play so
  // it cannot fire late, on someone else's turn.
  if (!state.myTurn && autoTimer) {
    clearTimeout(autoTimer);
    autoTimer = null;
    autoKey   = null;
  }

  const hand    = state.playerHand    || [];
  const ends    = state.boardEnds     || [];
  const history = state.playedHistory || [];

  // ── Get playable tiles and IDs ────────────────────────────────────────
  const playable    = state.playableTiles || [];
  const playableIds = state.playableIds   || [];

  // If we have no hand data yet, try to recover from _cdaNums directly
  // This handles the mid-game join case where captureInitialHand hasn't fired
  if (hand.length === 0 && playable.length === 0) {
    if (state.myTurn) {
      console.warn("[CDA] It is your turn but tile values are unknown (hook missed the deal). Refresh the page before the next hand.");
      safeStorageSet({
        lastUpdate: {
          bestMove: null,
          explanation: "Your turn detected, but tile values are unknown (joined mid-hand). Refresh the page and wait for the next deal.",
          myTurn: true, hand: [], ends,
          paloSeco: NO_PASO
        }
      });
    }
    // Check if _cdaNums has data but hand wasn't captured
    window.postMessage({
      source: "LUDO_ADVISOR_CMD",
      type:   "REQUEST_HAND_RECOVERY"
    }, "*");
    return;
  }

  const effectiveHand = hand.length > 0 ? hand : playable;

  // Android port: on a new turn the mobile button first shows "thinking" (tile dimmed, "…"), then the engine runs
  // after the page has had a moment to draw it.
  if (state.myTurn && mobileOn()) {
    const tk = history.length + "|" + effectiveHand.map((t) => t.join("")).join(",");
    if (tk !== thoughtKey) {
      thoughtKey = tk;
      toMobile({ phase: "thinking", myTurn: true, historyLen: history.length, engine: adapter.engineVersion });
      setTimeout(() => { if (lastState === state && !finished) processState(state); }, 30);
      return;
    }
  }

  // Rebuild who-played-what (incl. passes and board sides) and ask the decision engine.
  // Returns null off-turn, or when the data is inconsistent (then nothing is recommended or played).
  let rec = null;
  try { rec = adapter.update(state, scores); }
  catch (e) { console.warn("[CDA] adapter error:", e && e.message); }

  const cannotDecide = state.myTurn && !(rec && rec.tile);
  let reason = "";
  if (cannotDecide) {
    reason = (adapter.diag && adapter.diag.msg) || "no recommendation";
    if (reason !== lastWarned) {
      console.warn("[CDA] engine cannot decide this turn:", reason);
      addLog("[CDA] engine cannot decide this turn: " + reason);
      lastWarned = reason;
    }
  } else if (state.myTurn && rec && rec.fallback) {
    // the engine could not decide, but the turn still got a (simple) recommendation: say so in the log
    const note = adapter.diag && adapter.diag.msg;
    if (note && note !== lastWarned) {
      console.warn("[CDA] " + note);
      addLog("[CDA] FALLBACK " + note + " -> " + rec.tile.join("-") + " (heaviest playable tile)");
      lastWarned = note;
    }
  } else if (state.myTurn) {
    lastWarned = "";
  }

  if (rec && rec.tile && state.myTurn) logDecision(state, rec, hand, ends, history);

  const recommendation = rec && rec.tile ? rec.tile : null;
  const explanation = rec
    ? rec.explanation
    : cannotDecide ? `Engine cannot decide this turn (${reason}). Play it yourself.` : "";
  const pasadoSummary = withPassedNumbers(adapter.lastPalo || NO_PASO, state);
  if (!pasadoSummary.me) pasadoSummary.me = "Not pasado in any suit";
  // My own row of the Fichas Pasadas table: facts only, never inferred. "passed" = the numbers on the board
  // when the game announced my pass; "none" = numbers with no tile in my full hand right now (the dealt hand
  // minus the tiles I played). Without the full hand (e.g. joined mid-hand) nothing is claimed.
  let myVoids = null;
  if (state.mySeat !== null && state.mySeat !== undefined && hand.length > 0) {
    const passed = new Set();
    for (const p of state.passes || []) if (p.who === state.mySeat) p.ends.forEach((n) => passed.add(n));
    const none = [];
    for (let n = 0; n <= 9; n++) if (!passed.has(n) && !hand.some((t) => t[0] === n || t[1] === n)) none.push(n);
    myVoids = { passed: [...passed].sort((a, b) => a - b), none };
  }

  // ── Write to storage for panel.js ─────────────────────────────────────
  // Show recommendation only on our turn.
  // Between turns: show "Opponents playing..." so the panel looks alive,
  // not frozen on a stale recommendation or "Waiting for game".
  safeStorageSet({
    lastUpdate: {
      bestMove:    state.myTurn ? recommendation : null,
      // the engine's second choice (a different tile, or the same tile on the other end), for the panel's Plan B line
      planB:       state.myTurn && rec && rec.tile ? planBOf(rec) : null,
      // the board-end value the recommended tile attaches to (panel highlights it when the tile fits both ends)
      bestMatched: state.myTurn && rec && rec.tile && rec.matched !== undefined ? rec.matched : null,
      explanation: state.myTurn
        ? explanation
        : ends.length > 0
          ? `Board: ${endFlip[state.mySeat] ? ends[0] + " | " + ends[1] : ends[1] + " | " + ends[0]} — Opponents playing...`
          : "Game active — waiting for your turn...",
      myTurn:  state.myTurn,
      hand:    effectiveHand,
      ends,
      // the tiles at the left and right ends of the board (shown only when they agree with the ends)
      endTiles: (state.boardEndTiles || []).length === 2 && ends.length === 2 &&
                state.boardEndTiles[0][0] === ends[0] && state.boardEndTiles[1][1] === ends[1] ? state.boardEndTiles : null,
      mySeat:   state.mySeat ?? null,         // the panel remembers the left/right flip per seat
      oneTile:  history.length === 1,          // only the opening tile on the board: both ends are that tile
      paloSeco: pasadoSummary,
      engine:   adapter.engineVersion,
      likely:   adapter.lastLikely || null,
      myVoids
    }
  });
  toMobile(mobileModel(state, rec, history, ends));

  // ── Auto-play ─────────────────────────────────────────────────────────
  // The opening move (empty board) is never auto-played: the user picks it, since any
  // player holding a legal opener may start. The advisor still shows its suggestion.
  const isOpeningMove = history.length === 0;
  if (state.myTurn && botActive && recommendation && !isOpeningMove && isContextValid()) {
    // rec.matched = the board-end value the tile attaches to (only matters when it fits both ends).
    scheduleAutoPlay(recommendation, playableIds, playable, rec.matched, history.length + "|" + recommendation);
  }
}

// ── Passes show at once ─────────────────────────────────────────────────
// The engine learns about a pass from the plays that follow it, so the latest pass can be missing
// from its list. injected.js reports every pass the moment it happens (seat + board ends); merge
// those in so the panel colours change immediately.
function withPassedNumbers(palo, state) {
  const passes = state.passes || [];
  if (state.mySeat === null || state.mySeat === undefined || passes.length === 0) return palo;
  const found = { opponentRight: new Set(), partner: new Set(), opponentLeft: new Set(), me: new Set() };
  for (const p of passes) {
    const rel = (p.who - state.mySeat + 4) % 4;   // 0 = me, 1 = right opponent, 2 = partner, 3 = left opponent
    const label = rel === 0 ? "me" : rel === 1 ? "opponentRight" : rel === 2 ? "partner" : rel === 3 ? "opponentLeft" : null;
    if (label) p.ends.forEach(n => found[label].add(n));
  }
  const merged = {};
  for (const label of Object.keys(found)) {
    const known = new Set(found[label]);
    const m = /Pasado en:\s*(.+)/i.exec(palo[label] || "");
    if (m) m[1].split(",").map(x => parseInt(x.trim(), 10)).filter(n => !isNaN(n)).forEach(n => known.add(n));
    merged[label] = known.size ? "Pasado en: " + [...known].sort((a, b) => a - b).join(", ") : "Not pasado in any suit";
  }
  return merged;
}

// ── Decision log ─────────────────────────────────────────────────────────
// One block per decision, written to the page console (F12) as plain text so it can be copied
// whole: the position, what the engine knows about each player, and every option with its score
// and the reasons behind it. Paste it to review a hand.
function logDecision(state, rec, hand, ends, history) {
  const key = history.length + "|" + hand.map(t => t.join("")).join(",") + "|" + adapter.level;
  if (key === lastLogged) return;      // processState runs many times per turn
  lastLogged = key;
  try {
    const f = (n) => (Math.round(n * 10) / 10);
    const sizes = state.handSizes || {};
    const pal = adapter.lastPalo || {};
    const voids = (label) => ((pal[label] || "").replace("Pasado en: ", "") || "-").replace("Not pasado in any suit", "-");
    const passTxt = (state.passes || []).map(p => `seat${p.who}@${p.ends.join("|")}`).join(" ") || "-";
    const lines = [
      `[CDA] DECISION  (${adapter.level}, engine ${adapter.engineVersion}) tiles played ${history.length} | ends ${ends.join(" | ")} | my hand ${hand.map(t => t.join("-")).join(" ")}`,
      `      tiles left  R:${sizes.opponentRight}  P:${sizes.partner}  L:${sizes.opponentLeft}   score me/them: ${rec.scores ? rec.scores.join("/") : "?"}`,
      `      passed on   R:${voids("opponentRight")}  P:${voids("partner")}  L:${voids("opponentLeft")}`,
      `      board (in order) ${history.map(t => t.join("-")).join(" ")}   | my seat ${state.mySeat}; passes (seat@ends): ${passTxt}`
    ];
    // the opening lead has no scored alternatives (the engine just picks its best lead), so log the pick itself
    if (!(rec.options || []).length && rec.tile) lines.push(`      PLAY ${rec.tile.join("-")}${history.length === 0 ? "  (opening lead)" : ""}   ${rec.explanation || ""}`);
    (rec.options || []).forEach((o, i) => {
      const why = o.reasons.map(r => `${r.delta >= 0 ? "+" : ""}${f(r.delta)} ${r.why}`).join("; ");
      lines.push(`      ${i === 0 ? "PLAY" : " alt"} ${o.tile}${o.end != null ? " on the " + o.end + " end" : ""}  = ${f(o.score)}   ${why}`);
    });
    console.log(lines.join("\n"));
    addLog(lines.join("\n"));
  } catch (e) { /* logging must never break play */ }
}

// Plan B: the best-scored option that is not Plan A (rec.tile on the rec.matched end). Options are the engine's
// candidates, best first; tile ids use "B" for the blank. behind = how many score points it trails Plan A.
function planBOf(rec) {
  const opts = rec.options || [];
  if (opts.length < 2) return null;
  const nums = (id) => String(id).split("-").map((x) => (x === "B" ? 0 : Number(x)));
  const same = (a, b) => a[0] + a[1] === b[0] + b[1] && Math.max(...a) === Math.max(...b);
  const aTile = rec.tile, aEnd = rec.matched ?? null;
  const isA = (o) => same(nums(o.tile), aTile) && (aEnd === null || o.end === null || o.end === aEnd);
  const a = opts.find(isA);
  const b = opts.find((o) => !isA(o));
  if (!b) return null;
  const t = nums(b.tile);
  const hi = Math.max(...t), lo = Math.min(...t);
  // its description, built like Plan A's: the move, then its three strongest reasons for
  const why = (b.reasons || []).filter((r) => r.delta > 0).slice(0, 3).map((r) => r.why).join("; ");
  return { tile: [hi, lo], end: b.end ?? null, behind: Math.round(((a ? a.score : opts[0].score) - b.score) * 10) / 10,
           explanation: `${hi}-${lo}${b.end !== null && b.end !== undefined ? " on the " + b.end + " end" : ""}.${why ? " " + why : ""}` };
}

// ── Mobile UI (Android port) ─────────────────────────────────────────────
// mobile-ui.js (loaded before this file, same content-script world) draws the floating button and the details
// card. It gets everything from here; the end it names is rec.matched, the same placement the auto-play uses.
function licenseOk() {
  const L = window.CDA_LICENSE;
  return L ? L.ok : window.CDA_BUILD !== "firefox";
}
try { if (window.CDA_LICENSE) window.CDA_LICENSE.onChange((L) => { if (L.ok && lastState) processState(lastState); }); } catch (e) {}
function mobileOn() { try { return !!(window.CDA_MOBILE && window.CDA_MOBILE.active()); } catch (e) { return false; } }
function toMobile(model) { try { if (window.CDA_MOBILE) window.CDA_MOBILE.update(model); } catch (e) { /* the UI must never break play */ } }
function mobileModel(state, rec, history, ends) {
  const m = { myTurn: !!state.myTurn, historyLen: history.length, engine: adapter.engineVersion };
  if (!state.myTurn) return state.mustPass ? { ...m, myTurn: true, phase: "pass" } : { ...m, phase: "wait" };
  if (!rec || !rec.tile) return { ...m, phase: "none" };
  const tr = (s) => (window.ES ? window.ES.reason(s) : s);
  const orient = (t, end) => (end === null || end === undefined ? [t[0], t[1]] : [end, t[0] === end ? t[1] : t[0]]);
  const sameEnds = ends.length === 2 && ends[0] === ends[1];
  const matched = rec.matched ?? null;
  const kind = history.length === 0 ? "lead" : matched === null ? "free" : sameEnds ? "either" : "end";
  const pb = planBOf(rec);
  return {
    ...m,
    phase: "play",
    tileStr: rec.tile.join("-"),
    tile: orient(rec.tile, kind === "lead" ? null : matched),   // the half that joins the chosen end comes first (left)
    kind,
    endNum: matched,
    why: (rec.why || []).map((r) => ({ why: tr(r.why), ref: r.ref || "" })),
    planB: pb ? { tileStr: pb.tile.join("-"), tile: orient(pb.tile, pb.end), endNum: pb.end, behind: pb.behind,
                  kind: history.length === 0 ? "lead" : pb.end === null ? "free" : sameEnds ? "either" : "end" } : null,
    fallback: !!rec.fallback,
  };
}

// ── Auto-play ─────────────────────────────────────────────────────────────
// Finds the Ludoteka tile ID matching the recommendation and calls t.mark().
// playable:    [[v1,v2], ...] converted tiles (from idToTile)
// playableIds: matching raw integer IDs (same order as playable)
let autoTimer = null;
let autoKey   = null;   // the turn the pending timer belongs to, so state updates do not restart the delay

// Human-like thinking time: a forced move is quick, more options take longer, and now and then
// the "player" hesitates. Stays far below the game's 18 s turn clock.
// Bot speed: see speedFactor near the top (every pause below is divided by it).
function humanDelay(legalCount) {
  const rnd = (a, b) => a + Math.random() * (b - a);
  let ms = legalCount <= 1
    ? rnd(700, 1400)
    : rnd(1000, 2200) + Math.min(legalCount - 2, 4) * 250;
  if (legalCount > 1 && Math.random() < 0.1) ms += rnd(1000, 2000);
  return Math.round(Math.min(ms, 5000) / speedFactor);
}

function scheduleAutoPlay(rec, playableIds, playable, matchedEnd, turnKey) {
  if (autoTimer && autoKey === turnKey) return;   // already waiting to play this exact turn
  if (autoTimer) clearTimeout(autoTimer);
  autoKey = turnKey;
  autoTimer = setTimeout(() => {
    autoTimer = null; autoKey = null;
    try {
    if (!rec || !botActive) return;   // the bot was switched off while "thinking": play nothing

    const idx = playable.findIndex(t =>
      t && (
        (t[0] === rec[0] && t[1] === rec[1]) ||
        (t[0] === rec[1] && t[1] === rec[0])
      )
    );

    if (idx !== -1 && playableIds[idx] !== undefined) {
      const tileId = playableIds[idx];
      console.log(`[CDA] Auto-play: [${rec}] → tileId ${tileId}`);
      addLog(`      bot played ${rec[0]}-${rec[1]}${matchedEnd != null ? " on the " + matchedEnd + " end" : ""}`);
      window.postMessage({
        source: "LUDO_ADVISOR_CMD",
        type:   "PLAY_TILE",
        tileId,
        tile:    [rec[0], rec[1]],
        matched: matchedEnd === undefined ? null : matchedEnd
      }, "*");
    } else {
      tryFallbackAutoPlay(rec, playableIds);
    }

    if (isContextValid()) {
      safeStorageSet({
        lastUpdate: {
          bestMove:    null,
          explanation: "Waiting for your turn...",
          myTurn:      false,
          hand:        [],
          ends:        [],
          paloSeco:    NO_PASO
        }
      });
    }
    } catch(e) {
      // Silently catch context invalidation errors in auto-play timer
    }
  }, humanDelay(playable.length));
}

// Fallback: scan _cdaHt directly to find matching tile ID
function tryFallbackAutoPlay(rec, playableIds) {
  window.postMessage({
    source: "LUDO_ADVISOR_CMD",
    type:   "FIND_AND_PLAY",
    nums:   rec
  }, "*");
}
